import unittest
from typing import Any, NoReturn

import pytest

import reactivex
from reactivex import operators as ops
from reactivex.testing import ReactiveTest, TestScheduler

on_next = ReactiveTest.on_next
on_completed = ReactiveTest.on_completed
on_error = ReactiveTest.on_error
subscribe = ReactiveTest.subscribe
subscribed = ReactiveTest.subscribed
disposed = ReactiveTest.disposed
created = ReactiveTest.created


class RxException(Exception):
    pass


# Helper function for raising exceptions within lambdas
def _raise(ex: Any) -> NoReturn:
    raise RxException(ex)


class TestRetry(unittest.TestCase):
    def test_retry_observable_basic(self):
        scheduler = TestScheduler()
        xs = scheduler.create_cold_observable(
            on_next(100, 1), on_next(150, 2), on_next(200, 3), on_completed(250)
        )
        results = scheduler.start(lambda: xs.pipe(ops.retry()))

        assert results.messages == [
            on_next(300, 1),
            on_next(350, 2),
            on_next(400, 3),
            on_completed(450),
        ]
        assert xs.subscriptions == [subscribe(200, 450)]

    def test_retry_observable_infinite(self):
        scheduler = TestScheduler()
        xs = scheduler.create_cold_observable(
            on_next(100, 1), on_next(150, 2), on_next(200, 3)
        )
        results = scheduler.start(lambda: xs.pipe(ops.retry()))

        assert results.messages == [on_next(300, 1), on_next(350, 2), on_next(400, 3)]
        assert xs.subscriptions == [subscribe(200, 1000)]

    def test_retry_observable_error(self):
        ex = "ex"
        scheduler = TestScheduler()
        xs = scheduler.create_cold_observable(
            on_next(100, 1), on_next(150, 2), on_next(200, 3), on_error(250, ex)
        )
        results = scheduler.start(lambda: xs.pipe(ops.retry()), disposed=1100)
        assert results.messages == [
            on_next(300, 1),
            on_next(350, 2),
            on_next(400, 3),
            on_next(550, 1),
            on_next(600, 2),
            on_next(650, 3),
            on_next(800, 1),
            on_next(850, 2),
            on_next(900, 3),
            on_next(1050, 1),
        ]
        assert xs.subscriptions == [
            subscribe(200, 450),
            subscribe(450, 700),
            subscribe(700, 950),
            subscribe(950, 1100),
        ]

    def test_retry_observable_throws(self):
        scheduler1 = TestScheduler()
        xs = reactivex.return_value(1).pipe(ops.retry())
        xs.subscribe(lambda x: _raise(Exception("ex")), scheduler=scheduler1)

        with pytest.raises(RxException):
            scheduler1.start()

        scheduler2 = TestScheduler()
        ys = reactivex.throw("ex").pipe(ops.retry())
        d = ys.subscribe(
            on_error=lambda ex: _raise(Exception("ex")), scheduler=scheduler2
        )

        scheduler2.schedule_absolute(210, lambda sc, st: d.dispose())
        scheduler2.start()

        scheduler3 = TestScheduler()
        zs = reactivex.return_value(1).pipe(ops.retry())
        zs.subscribe(on_completed=lambda: _raise(Exception("ex")), scheduler=scheduler3)

        with pytest.raises(RxException):
            scheduler3.start()

    def test_retry_observable_retry_count_basic(self):
        scheduler = TestScheduler()
        ex = "ex"
        xs = scheduler.create_cold_observable(
            on_next(5, 1), on_next(10, 2), on_next(15, 3), on_error(20, ex)
        )
        results = scheduler.start(lambda: xs.pipe(ops.retry(3)))

        assert results.messages == [
            on_next(205, 1),
            on_next(210, 2),
            on_next(215, 3),
            on_next(225, 1),
            on_next(230, 2),
            on_next(235, 3),
            on_next(245, 1),
            on_next(250, 2),
            on_next(255, 3),
            on_error(260, ex),
        ]
        assert xs.subscriptions == [
            subscribe(200, 220),
            subscribe(220, 240),
            subscribe(240, 260),
        ]

    def test_retry_observable_retry_count_dispose(self):
        scheduler = TestScheduler()
        ex = "ex"
        xs = scheduler.create_cold_observable(
            on_next(5, 1), on_next(10, 2), on_next(15, 3), on_error(20, ex)
        )
        results = scheduler.start(lambda: xs.pipe(ops.retry(3)), disposed=231)
        assert results.messages == [
            on_next(205, 1),
            on_next(210, 2),
            on_next(215, 3),
            on_next(225, 1),
            on_next(230, 2),
        ]
        assert xs.subscriptions == [subscribe(200, 220), subscribe(220, 231)]

    def test_retry_observable_retry_count_dispose_ii(self):
        scheduler = TestScheduler()
        xs = scheduler.create_cold_observable(
            on_next(100, 1), on_next(150, 2), on_next(200, 3)
        )
        results = scheduler.start(lambda: xs.pipe(ops.retry(3)))

        assert results.messages == [on_next(300, 1), on_next(350, 2), on_next(400, 3)]
        assert xs.subscriptions == [subscribe(200, 1000)]

    def test_retry_observable_retry_count_dispose_iii(self):
        scheduler = TestScheduler()
        xs = scheduler.create_cold_observable(
            on_next(100, 1), on_next(150, 2), on_next(200, 3), on_completed(250)
        )
        results = scheduler.start(lambda: xs.pipe(ops.retry(3)))

        assert results.messages == [
            on_next(300, 1),
            on_next(350, 2),
            on_next(400, 3),
            on_completed(450),
        ]
        assert xs.subscriptions == [subscribe(200, 450)]

    def test_retry_observable_retry_count_throws(self):
        scheduler1 = TestScheduler()
        xs = reactivex.return_value(1).pipe(ops.retry(3))
        xs.subscribe(lambda x: _raise(Exception("ex")), scheduler=scheduler1)

        self.assertRaises(RxException, scheduler1.start)

        scheduler2 = TestScheduler()
        ys = reactivex.throw("ex").pipe(ops.retry(100))
        d = ys.subscribe(
            on_error=lambda ex: _raise(Exception("ex")), scheduler=scheduler2
        )

        def dispose(_, __):
            d.dispose()

        scheduler2.schedule_absolute(0, dispose)
        scheduler2.start()

        scheduler3 = TestScheduler()
        zs = reactivex.return_value(1).pipe(ops.retry(100))
        zs.subscribe(on_completed=lambda: _raise(Exception("ex")), scheduler=scheduler3)

        with pytest.raises(RxException):
            scheduler3.start()

        xss = reactivex.create(lambda o, s: _raise(Exception("ex"))).pipe(
            ops.retry(100)
        )
        with pytest.raises(Exception):
            xss.subscribe()

    def test_retry_with_count_combined_with_repeat(self):
        """retry(n) should reset its budget per subscription so repeat() works correctly.

        Regression test for https://github.com/ReactiveX/RxPY/issues/712.
        """  # noqa: E501
        scheduler = TestScheduler()
        xs = scheduler.create_cold_observable(on_next(90, 42), on_completed(200))

        result = scheduler.start(
            lambda: xs.pipe(ops.retry(2), ops.repeat()),
            disposed=1000,
        )
        assert result.messages == [
            on_next(290, 42),
            on_next(490, 42),
            on_next(690, 42),
            on_next(890, 42),
        ]
        assert xs.subscriptions == [
            subscribe(200, 400),
            subscribe(400, 600),
            subscribe(600, 800),
            subscribe(800, 1000),
        ]


if __name__ == "__main__":
    unittest.main()
