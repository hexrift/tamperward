`latexwalker` — Calling Parsers for LaTeX Code
----------------------------------------------

.. automodule:: pylatexenc.latexwalker
   :no-undoc-members:
   :show-inheritance:

.. contents:: Contents:
   :local:


The main `LatexWalker` class
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pylatexenc.latexwalker.LatexWalker
   :members:


.. autofunction:: pylatexenc.latexwalker.get_default_latex_context_db


Exception Classes
~~~~~~~~~~~~~~~~~

.. py:class:: LatexWalkerError

   Moved to :py:class:`pylatexenc.latexnodes.LatexWalkerError`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes` as
      :py:class:`pylatexenc.latexnodes.LatexWalkerError`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexWalkerParseError

   Moved to :py:class:`pylatexenc.latexnodes.LatexWalkerParseError`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes` as
      :py:class:`pylatexenc.latexnodes.LatexWalkerParseError`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexWalkerEndOfStream

   Moved to :py:class:`pylatexenc.latexnodes.LatexWalkerEndOfStream`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes` as
      :py:class:`pylatexenc.latexnodes.LatexWalkerEndOfStream`.  It is aliased
      in `pylatexenc.latexwalker` for backwards compatibility.


Data Node Classes
~~~~~~~~~~~~~~~~~

.. py:class:: LatexNode

   Moved to :py:class:`pylatexenc.latexnodes.nodes.LatexNode`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes.nodes` as
      :py:class:`pylatexenc.latexnodes.nodes.LatexNode`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexCharsNode

   Moved to :py:class:`pylatexenc.latexnodes.nodes.LatexCharsNode`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes.nodes` as
      :py:class:`pylatexenc.latexnodes.nodes.LatexCharsNode`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexGroupNode

   Moved to :py:class:`pylatexenc.latexnodes.nodes.LatexGroupNode`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes.nodes` as
      :py:class:`pylatexenc.latexnodes.nodes.LatexGroupNode`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexCommentNode

   Moved to :py:class:`pylatexenc.latexnodes.nodes.LatexCommentNode`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes.nodes` as
      :py:class:`pylatexenc.latexnodes.nodes.LatexCommentNode`.  It is aliased
      in `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexMacroNode

   Moved to :py:class:`pylatexenc.latexnodes.nodes.LatexMacroNode`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes.nodes` as
      :py:class:`pylatexenc.latexnodes.nodes.LatexMacroNode`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexEnvironmentNode

   Moved to :py:class:`pylatexenc.latexnodes.nodes.LatexEnvironmentNode`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes.nodes` as
      :py:class:`pylatexenc.latexnodes.nodes.LatexEnvironmentNode`.  It is
      aliased in `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexSpecialsNode

   Moved to :py:class:`pylatexenc.latexnodes.nodes.LatexSpecialsNode`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes.nodes` as
      :py:class:`pylatexenc.latexnodes.nodes.LatexSpecialsNode`.  It is aliased
      in `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexMathNode

   Moved to :py:class:`pylatexenc.latexnodes.nodes.LatexMathNode`.

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes.nodes` as
      :py:class:`pylatexenc.latexnodes.nodes.LatexMathNode`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.


Parsing helpers
~~~~~~~~~~~~~~~

.. py:class:: ParsingState

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.

.. py:class:: LatexToken

   .. deprecated:: 3.0

      Since Pylatexenc 3.0, this class now resides in the new module
      :py:mod:`pylatexenc.latexnodes`.  It is aliased in
      `pylatexenc.latexwalker` for backwards compatibility.



Legacy Macro Definitions (for `pylatexenc 1.x`)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: pylatexenc.latexwalker.MacrosDef

.. autodata:: pylatexenc.latexwalker.default_macro_dict
   :annotation:


