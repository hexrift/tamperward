"""
Ensure tests don't depend on the ambient $HOME being readable/writable by
the user running pytest (e.g. CI running as root against a $HOME owned by
another uid). This must run before any `policy_sentry` module is imported,
since policy_sentry.shared.constants resolves Path.home() at import time.
"""

import os
import tempfile

os.environ["HOME"] = tempfile.mkdtemp(prefix="policy_sentry_test_home_")
