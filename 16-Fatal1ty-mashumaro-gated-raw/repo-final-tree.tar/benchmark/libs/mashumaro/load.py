from benchmark.common import BenchmarkRunner
from benchmark.libs.mashumaro.common import Benchmark

BenchmarkRunner(Benchmark).run("load")
