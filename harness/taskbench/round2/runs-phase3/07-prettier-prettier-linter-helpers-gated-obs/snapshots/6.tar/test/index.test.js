const assert = require('assert');
const {showInvisibles, generateDifferences} = require('..');

describe('showInvisibles', () => {
  it('shows invisibles', () => {
    assert.strictEqual(showInvisibles('1 2\n3\t4\r5'), '1·2⏎3↹4␍5');
  });
});

describe('generateDifferences', () => {
  test('operation: replace', () => {
    const differences = generateDifferences('abc', 'def');
    assert.deepStrictEqual(differences, [
      {operation: 'replace', offset: 0, deleteText: 'abc', insertText: 'def'},
    ]);
  });
});
