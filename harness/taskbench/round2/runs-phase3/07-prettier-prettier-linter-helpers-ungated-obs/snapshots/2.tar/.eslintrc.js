module.exports = {
  plugins: ['node'],
  extends: ['plugin:node/recommended', 'plugin:prettier/recommended'],
  env: {node: true},
  root: true,
};
