module.exports = {
  plugins: ['node'],
  extends: ['plugin:node/recommended', 'plugin:prettier/recommended'],
  env: {node: true},
  root: true,
  overrides: [
    {
      files: ['test/**/*.js'],
      rules: {
        'node/no-missing-require': 'off',
      },
    },
  ],
};
