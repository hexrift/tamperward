import requests_mock
import pytest


@pytest.fixture(autouse=True)
def auto_mock_requests():
    """Auto-enable requests_mock for all tests that don't explicitly use it.

    This ensures that unmocked HTTP requests raise ConnectionError instead of
    being intercepted by the environment's proxy.
    """
    with requests_mock.Mocker(real_http=False) as m:
        # Allow localhost for any local test servers
        m.register_uri(requests_mock.ANY, requests_mock.ANY, status_code=404)
        yield m
