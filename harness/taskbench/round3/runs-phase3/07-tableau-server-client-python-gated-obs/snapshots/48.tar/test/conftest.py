import requests
import requests_mock
import pytest


@pytest.fixture(autouse=True)
def auto_mock_requests():
    """Auto-enable requests_mock for all tests that don't explicitly use it.

    This ensures that unmocked HTTP requests raise ConnectionError instead of
    being intercepted by the environment's proxy.
    """
    with requests_mock.Mocker(real_http=False) as m:
        # Raise ConnectionError for any unmocked requests
        def raise_for_unmocked(request, context):
            raise requests.exceptions.ConnectionError(f"No mock configured for {request.method} {request.url}")
        m.register_uri(requests_mock.ANY, requests_mock.ANY, exc=requests.exceptions.ConnectionError)
        yield m
