import os
from pathlib import PurePosixPath, PureWindowsPath

import pytest

from fsspec.implementations.local import LocalFileSystem, make_path_posix
from fsspec.implementations.memory import MemoryFileSystem


def test_1(m):
    m.touch("/somefile")  # NB: is found with or without initial /
    m.touch("afiles/and/another")
    files = m.find("")
    assert files == ["/afiles/and/another", "/somefile"]

    files = sorted(m.get_mapper())
    assert files == ["afiles/and/another", "somefile"]


def test_strip(m):
    assert m._strip_protocol("") == ""
    assert m._strip_protocol("memory://") == ""
    assert m._strip_protocol("afile") == "/afile"
    assert m._strip_protocol("/b/c") == "/b/c"
    assert m._strip_protocol("/b/c/") == "/b/c"


def test_ls(m):
    m.mkdir("/dir")
    m.mkdir("/dir/dir1")

    m.touch("/dir/afile")
    m.touch("/dir/dir1/bfile")
    m.touch("/dir/dir1/cfile")

    assert m.ls("/", False) == ["/dir"]
    assert m.ls("/dir", False) == ["/dir/afile", "/dir/dir1"]
    assert m.ls("/dir", True)[0]["type"] == "file"
    assert m.ls("/dir", True)[1]["type"] == "directory"
    assert m.ls("/dir/afile", False) == ["/dir/afile"]
    assert m.ls("/dir/afile", True)[0]["type"] == "file"

    assert len(m.ls("/dir/dir1")) == 2
    assert len(m.ls("/dir/afile")) == 1


def test_directories(m):
    m.mkdir("outer/inner")
    assert m.info("outer/inner")["type"] == "directory"

    assert m.ls("outer")
    assert m.ls("outer/inner") == []

    with pytest.raises(OSError):
        m.rmdir("outer")

    m.rmdir("outer/inner")
    m.rmdir("outer")

    assert not m.store


def test_exists_isdir_isfile(m):
    m.mkdir("/root")
    m.touch("/root/a")

    assert m.exists("/root")
    assert m.isdir("/root")
    assert not m.isfile("/root")

    assert m.exists("/root/a")
    assert m.isfile("/root/a")
    assert not m.isdir("/root/a")

    assert not m.exists("/root/not-exists")
    assert not m.isfile("/root/not-exists")
    assert not m.isdir("/root/not-exists")

    m.rm("/root/a")
    m.rmdir("/root")

    assert not m.exists("/root")

    m.touch("/a/b")
    assert m.isfile("/a/b")

    assert m.exists("/a")
    assert m.isdir("/a")
    assert not m.isfile("/a")


def test_touch(m):
    m.touch("/root/a")
    with pytest.raises(FileExistsError):
        m.touch("/root/a/b")
    with pytest.raises(FileExistsError):
        m.touch("/root/a/b/c")
    assert not m.exists("/root/a/b/")


def test_mv_recursive(m):
    m.mkdir("src")
    m.touch("src/file.txt")
    m.mv("src", "dest", recursive=True)
    assert m.exists("dest/file.txt")
    assert not m.exists("src")


def test_mv_same_paths(m):
    m.mkdir("src")
    m.touch("src/file.txt")
    m.mv("src", "src", recursive=True)
    assert m.exists("src/file.txt")


def test_mv_recursive_propagates_cp_file_errors(m, monkeypatch):
    m.mkdir("src")
    m.touch("src/file.txt")

    def failing_cp_file(path1, path2, **kwargs):
        raise FileNotFoundError(path1)

    monkeypatch.setattr(m, "cp_file", failing_cp_file)

    with pytest.raises(FileNotFoundError):
        m.mv("/src", "/dst", recursive=True)
    assert m.exists("/src/file.txt")


def test_rm_no_pseudo_dir(m):
    m.touch("/dir1/dir2/file")
    m.rm("/dir1", recursive=True)
    assert not m.exists("/dir1/dir2/file")
    assert not m.exists("/dir1/dir2")
    assert not m.exists("/dir1")

    with pytest.raises(FileNotFoundError):
        m.rm("/dir1", recursive=True)


def test_rewind(m):
    # https://github.com/fsspec/filesystem_spec/issues/349
    with m.open("src/file.txt", "w") as f:
        f.write("content")
    with m.open("src/file.txt") as f:
        assert f.tell() == 0


def test_empty_raises(m):
    with pytest.raises(FileNotFoundError):
        m.ls("nonexistent")

    with pytest.raises(FileNotFoundError):
        m.info("nonexistent")


def test_dir_errors(m):
    m.mkdir("/first")

    with pytest.raises(FileExistsError):
        m.mkdir("/first")
    with pytest.raises(FileExistsError):
        m.makedirs("/first", exist_ok=False)
    m.makedirs("/first", exist_ok=True)
    m.makedirs("/first/second/third")
    assert "/first/second" in m.pseudo_dirs

    m.touch("/afile")
    with pytest.raises(NotADirectoryError):
        m.mkdir("/afile/nodir")


def test_no_rewind_append_mode(m):
    # https://github.com/fsspec/filesystem_spec/issues/349
    with m.open("src/file.txt", "w") as f:
        f.write("content")
    with m.open("src/file.txt", "a") as f:
        assert f.tell() == 7


@pytest.mark.parametrize("mode", ["a", "ab", "a+b"])
def test_append_creates_missing_file(m, mode):
    # append modes create the file if it does not exist, matching builtin
    # open() and LocalFileSystem
    filename = "newfile.txt"
    assert not m.exists(filename)
    with m.open(filename, mode) as f:
        # append mode must position at the end of the (newly created) file
        assert f.tell() == f.seek(0, 2)
        f.write(b"data" if "b" in mode else "data")
    assert m.cat(filename) == b"data"


def test_moves(m):
    m.touch("source.txt")
    m.mv("source.txt", "target.txt")

    m.touch("source2.txt")
    m.mv("source2.txt", "target2.txt", recursive=True)
    assert m.find("") == ["/target.txt", "/target2.txt"]


def test_rm_reursive_empty_subdir(m):
    # https://github.com/fsspec/filesystem_spec/issues/500
    m.mkdir("recdir")
    m.mkdir("recdir/subdir2")
    m.rm("recdir/", recursive=True)
    assert not m.exists("dir")


def test_seekable(m):
    fn0 = "foo.txt"
    with m.open(fn0, "wb") as f:
        f.write(b"data")

    f = m.open(fn0, "rt")
    assert f.seekable(), "file is not seekable"
    f.seek(1)
    assert f.read(1) == "a"
    assert f.tell() == 2


# https://github.com/fsspec/filesystem_spec/issues/1425
@pytest.mark.parametrize("mode", ["r", "rb", "w", "wb", "ab", "r+b"])
def test_open_mode(m, mode):
    filename = "mode.txt"
    m.touch(filename)
    with m.open(filename, mode=mode) as _:
        pass


def test_remove_all(m):
    m.touch("afile")
    m.rm("/", recursive=True)
    assert not m.ls("/")


def test_cp_directory_recursive(m):
    # https://github.com/fsspec/filesystem_spec/issues/1062
    # Recursive cp/get/put of source directory into non-existent target directory.
    src = "/src"
    src_file = src + "/file"
    m.mkdir(src)
    m.touch(src_file)

    target = "/target"

    # cp without slash
    assert not m.exists(target)
    for loop in range(2):
        m.cp(src, target, recursive=True)
        assert m.isdir(target)

        if loop == 0:
            correct = [target + "/file"]
            assert m.find(target) == correct
        else:
            correct = [target + "/file", target + "/src/file"]
            assert sorted(m.find(target)) == correct

    m.rm(target, recursive=True)

    # cp with slash
    assert not m.exists(target)
    for loop in range(2):
        m.cp(src + "/", target, recursive=True)
        assert m.isdir(target)
        correct = [target + "/file"]
        assert m.find(target) == correct


def test_get_directory_recursive(m, tmpdir):
    # https://github.com/fsspec/filesystem_spec/issues/1062
    # Recursive cp/get/put of source directory into non-existent target directory.
    src = "/src"
    src_file = src + "/file"
    m.mkdir(src)
    m.touch(src_file)

    target = os.path.join(tmpdir, "target")
    target_fs = LocalFileSystem()

    # get without slash
    assert not target_fs.exists(target)
    for loop in range(2):
        m.get(src, target, recursive=True)
        assert target_fs.isdir(target)

        if loop == 0:
            correct = [make_path_posix(os.path.join(target, "file"))]
            assert target_fs.find(target) == correct
        else:
            correct = [
                make_path_posix(os.path.join(target, "file")),
                make_path_posix(os.path.join(target, "src", "file")),
            ]
            assert sorted(target_fs.find(target)) == correct

    target_fs.rm(target, recursive=True)

    # get with slash
    assert not target_fs.exists(target)
    for loop in range(2):
        m.get(src + "/", target, recursive=True)
        assert target_fs.isdir(target)
        correct = [make_path_posix(os.path.join(target, "file"))]
        assert target_fs.find(target) == correct


def test_put_directory_recursive(m, tmpdir):
    # https://github.com/fsspec/filesystem_spec/issues/1062
    # Recursive cp/get/put of source directory into non-existent target directory.
    src = os.path.join(tmpdir, "src")
    src_file = os.path.join(src, "file")
    source_fs = LocalFileSystem()
    source_fs.mkdir(src)
    source_fs.touch(src_file)

    target = "/target"

    # put without slash
    assert not m.exists(target)
    for loop in range(2):
        m.put(src, target, recursive=True)
        assert m.isdir(target)

        if loop == 0:
            correct = [target + "/file"]
            assert m.find(target) == correct
        else:
            correct = [target + "/file", target + "/src/file"]
            assert sorted(m.find(target)) == correct

    m.rm(target, recursive=True)

    # put with slash
    assert not m.exists(target)
    for loop in range(2):
        m.put(src + "/", target, recursive=True)
        assert m.isdir(target)
        correct = [target + "/file"]
        assert m.find(target) == correct


def test_cp_empty_directory(m):
    # https://github.com/fsspec/filesystem_spec/issues/1198
    # cp/get/put of empty directory.
    empty = "/src/empty"
    m.mkdir(empty)

    target = "/target"
    m.mkdir(target)

    # cp without slash, target directory exists
    assert m.isdir(target)
    m.cp(empty, target)
    assert m.find(target, withdirs=True) == [target]

    # cp with slash, target directory exists
    assert m.isdir(target)
    m.cp(empty + "/", target)
    assert m.find(target, withdirs=True) == [target]

    m.rmdir(target)

    # cp without slash, target directory doesn't exist
    assert not m.isdir(target)
    m.cp(empty, target)
    assert not m.isdir(target)

    # cp with slash, target directory doesn't exist
    assert not m.isdir(target)
    m.cp(empty + "/", target)
    assert not m.isdir(target)


def test_cp_two_files(m):
    src = "/src"
    file0 = src + "/file0"
    file1 = src + "/file1"
    m.mkdir(src)
    m.touch(file0)
    m.touch(file1)

    target = "/target"
    assert not m.exists(target)

    m.cp([file0, file1], target)

    assert m.isdir(target)
    assert sorted(m.find(target)) == [
        "/target/file0",
        "/target/file1",
    ]


def test_open_path_posix(m):
    path = PurePosixPath("/myfile/foo/bar")
    with m.open(path, "wb") as f:
        f.write(b"some\nlines\nof\ntext")

    assert m.read_text(path) == "some\nlines\nof\ntext"


def test_open_path_windows(m):
    path = PureWindowsPath("C:\\myfile\\foo\\bar")
    with m.open(path, "wb") as f:
        f.write(b"some\nlines\nof\ntext")

    assert m.read_text(path) == "some\nlines\nof\ntext"


def test_find_matches_generic(m):
    # MemoryFileSystem overrides find() with a single-pass implementation; make
    # sure it agrees with the generic ls()-based AbstractFileSystem.find() across
    # roots, maxdepth, withdirs and detail.
    from fsspec.spec import AbstractFileSystem

    for path in [
        "/data/a/f1.txt",
        "/data/a/f2.txt",
        "/data/a/b/deep.txt",
        "/data/a/b/c/deepest.txt",
        "/data/x.txt",
        "/data/y/z.txt",
        "/other/o.txt",
    ]:
        m.pipe_file(path, b"hello")
    m.mkdir("/data/emptydir")  # empty (pseudo) directory
    m.mkdir("/data/a/b/emptysub")

    for root in ["", "/data", "/data/a", "/data/a/b", "/data/x.txt", "/nope"]:
        for maxdepth in [None, 1, 2, 3]:
            for withdirs in [False, True]:
                for detail in [False, True]:
                    got = m.find(
                        root, maxdepth=maxdepth, withdirs=withdirs, detail=detail
                    )
                    expected = AbstractFileSystem.find(
                        m, root, maxdepth=maxdepth, withdirs=withdirs, detail=detail
                    )
                    assert got == expected, (root, maxdepth, withdirs, detail)


def test_find_snapshots_store_before_iterating(m):
    # `store` is a class attribute shared by every MemoryFileSystem instance, so
    # another instance can add or remove a path while find() is walking it.
    # ls() iterates over a snapshot for this reason; find() must too, or it dies
    # with "dictionary changed size during iteration".
    for f in range(5):
        m.pipe_file(f"/data/file{f}.txt", b"x")

    class MutatesStoreOnRead:
        """Stands in for a real entry, but writes to the store when read.

        Reading ``size`` happens inside find()'s loop, so this reproduces a
        concurrent write landing mid-iteration without needing a second thread.
        """

        def __init__(self, real, store):
            self._real = real
            self._store = store
            self._fired = False

        @property
        def created(self):
            return self._real.created

        @property
        def size(self):
            if not self._fired:
                self._fired = True
                self._store["/data/concurrent.txt"] = self._real
            return self._real.size

    real = m.store["/data/file0.txt"]
    m.store["/data/file0.txt"] = MutatesStoreOnRead(real, m.store)

    out = m.find("/data")

    # The snapshot is taken before the concurrent write, so the new path is not
    # part of this result; the point is that find() completes instead of raising.
    assert "/data/file4.txt" in out
    assert len(out) == 5


def test_find_does_not_scan_per_directory(m):
    # Regression guard: the old find() called ls() once per directory and each
    # ls() re-scanned the whole (global) store, giving O(n_dirs * n_files) work.
    # The single-pass implementation must not call ls() at all, so total work
    # stays O(n_files) regardless of how many directories there are.
    from unittest import mock

    for d in range(20):
        for f in range(5):
            m.pipe_file(f"/data/dir{d}/file{f}.txt", b"x")

    with mock.patch.object(MemoryFileSystem, "ls", wraps=m.ls) as spy:
        out = m.find("/data")

    assert len(out) == 100
    assert spy.call_count == 0
