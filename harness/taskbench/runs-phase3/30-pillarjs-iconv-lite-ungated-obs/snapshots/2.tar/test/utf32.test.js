"use strict"

const assert = require("assert")
const utils = require("./helpers/utils")
const iconv = utils.requireIconv()
const hex = utils.hex

const testStr = "1a\u044F\u4E2D\u6587\u2603\uD83D\uDCA9"
const testStr2 = "\u275DStray high \uD977\uD83D\uDE31 and low\uDDDD\u2614 surrogate values.\u275E"
// Strict UTF-32: the lone surrogates (U+D977 high, U+DDDD low) can't be represented and become U+FFFD;
// the valid pair (\uD83D\uDE31) survives.
const testStr2Fixed = testStr2.replace("\uD977", "\uFFFD").replace("\uDDDD", "\uFFFD")
const utf32leBuf = utils.bytes("31 00 00 00 61 00 00 00 4f 04 00 00 2d 4e 00 00 87 65 00 00 03 26 00 00 a9 f4 01 00")
const utf32beBuf = utils.bytes("00 00 00 31 00 00 00 61 00 00 04 4f 00 00 4e 2d 00 00 65 87 00 00 26 03 00 01 f4 a9")
const utf32leBufWithBOM = utils.concatBufs([utils.bytes("ff fe 00 00"), utf32leBuf])
const utf32beBufWithBOM = utils.concatBufs([utils.bytes("00 00 fe ff"), utf32beBuf])
// 0x12345678 is above the U+10FFFF maximum -> ill-formed.
const utf32leBufWithInvalidChar = utils.concatBufs([utf32leBuf, utils.bytes("12 34 56 78")])
const utf32beBufWithInvalidChar = utils.concatBufs([utf32beBuf, utils.bytes("12 34 56 78")])
const sampleStr = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<\u4FC4\u8BED>\u0434\u0430\u043D\u043D\u044B\u0435</\u4FC4\u8BED>"

describe("UTF-32LE codec #node-web", function () {
  it("encodes basic strings correctly", function () {
    assert.equal(hex(iconv.encode(testStr, "UTF32-LE")), hex(utf32leBuf))
  })

  it("decodes basic buffers correctly", function () {
    assert.equal(iconv.decode(utf32leBuf, "ucs4le"), testStr)
  })

  it("replaces a surrogate code point with U+FFFD when decoding", function () {
    // 0x0000D800 is a (high) surrogate code point: invalid in UTF-32.
    assert.equal(iconv.decode(utils.bytes("00 d8 00 00"), "utf-32le"), "\uFFFD")
  })

  it("replaces lone surrogates with U+FFFD when encoding", function () {
    assert.equal(escape(iconv.decode(iconv.encode(testStr2, "UTF32-LE"), "UTF32-LE")), escape(testStr2Fixed))
  })

  it("replaces a trailing unpaired high surrogate with U+FFFD", function () {
    // 'a' is written, the lone high surrogate is held, then end() flushes it as U+FFFD.
    assert.equal(hex(iconv.encode("a\uD800", "UTF32-LE")), hex(utils.bytes("61 00 00 00 fd ff 00 00")))
  })

  it("decodes correctly when split at every byte boundary", function () {
    for (let at = 1; at < utf32leBuf.length; at++) {
      const decoder = iconv.getDecoder("utf-32le")
      const res = decoder.write(utf32leBuf.slice(0, at)) + decoder.write(utf32leBuf.slice(at)) + (decoder.end() || "")
      assert.equal(res, testStr, "split at byte " + at)
    }
  })

  it("decodes both 4-byte-aligned and unaligned input", function () {
    // The fast path views aligned input as a Uint32Array; unaligned input falls back to byte reads.
    const ab = new ArrayBuffer(utf32leBuf.length + 4)
    const aligned = new Uint8Array(ab, 0, utf32leBuf.length)
    aligned.set(utf32leBuf)
    const unaligned = new Uint8Array(ab.slice(0), 2, utf32leBuf.length) // byteOffset 2 -> not 4-aligned
    unaligned.set(utf32leBuf)
    assert.equal(iconv.decode(aligned, "utf-32le"), testStr)
    assert.equal(iconv.decode(unaligned, "utf-32le"), testStr)
  })
})

describe("UTF-32BE codec #node-web", function () {
  it("encodes basic strings correctly", function () {
    assert.equal(hex(iconv.encode(testStr, "UTF32-BE")), hex(utf32beBuf))
  })

  it("decodes basic buffers correctly", function () {
    assert.equal(iconv.decode(utf32beBuf, "ucs4be"), testStr)
  })

  it("replaces a surrogate code point with U+FFFD when decoding", function () {
    assert.equal(iconv.decode(utils.bytes("00 00 d8 00"), "utf-32be"), "\uFFFD")
  })

  it("replaces lone surrogates with U+FFFD when encoding", function () {
    assert.equal(escape(iconv.decode(iconv.encode(testStr2, "UTF32-BE"), "UTF32-BE")), escape(testStr2Fixed))
  })

  it("replaces a trailing unpaired high surrogate with U+FFFD", function () {
    assert.equal(hex(iconv.encode("a\uD800", "UTF32-BE")), hex(utils.bytes("00 00 00 61 00 00 ff fd")))
  })

  it("decodes a code point split across chunk boundaries", utils.checkDecoderChunks("utf-32be", [
    { inputs: ["00 00", "00 61 00 00 00 62"], outputs: ["", "ab"] }
  ]))

  it("decodes correctly when split at every byte boundary", function () {
    for (let at = 1; at < utf32beBuf.length; at++) {
      const decoder = iconv.getDecoder("utf-32be")
      const res = decoder.write(utf32beBuf.slice(0, at)) + decoder.write(utf32beBuf.slice(at)) + (decoder.end() || "")
      assert.equal(res, testStr, "split at byte " + at)
    }
  })
})

describe("UTF-32 general codec #node-web", function () {

  it("uses the Section 3.10 byte order mark signatures", function () {
    // The BOM (U+FEFF) serializes to FF FE 00 00 (LE) and 00 00 FE FF (BE).
    assert.equal(hex(iconv.encode("\uFEFF", "utf-32le")), hex(utils.bytes("ff fe 00 00")))
    assert.equal(hex(iconv.encode("\uFEFF", "utf-32be")), hex(utils.bytes("00 00 fe ff")))
  })

  it("adds a BOM when encoding, defaulting to UTF-32LE", function () {
    assert.equal(hex(iconv.encode(testStr, "utf-32")), hex(utf32leBufWithBOM))
  })

  it("decodes UTF-32BE using the BOM (keeping it with stripBOM: false)", function () {
    assert.equal(iconv.decode(utf32beBufWithBOM, "utf-32", { stripBOM: false }), "\uFEFF" + testStr)
  })

  it("decodes short input, deciding endianness only at end()", function () {
    // 8 bytes is below the 32-byte detection threshold, so the codec is chosen only at end().
    assert.equal(iconv.decode(iconv.encode("1a", "utf-32le"), "utf-32"), "1a")
  })

  it("flushes a trailing incomplete code unit as U+FFFD when deciding at end()", function () {
    // 5 bytes (< 32): decided at end(), and the chosen decoder's end() yields the trailing U+FFFD.
    assert.equal(iconv.decode(utils.bytes("31 00 00 00 00"), "utf-32"), "1\uFFFD")
  })

  it("falls back to UTF-32LE for ambiguous (all-zero) input", function () {
    assert.equal(iconv.decode(utils.bytes(new Array(32).fill(0)), "utf-32"), "\0\0\0\0\0\0\0\0")
  })

  it("detects endianness from a long heuristic sample (> 100 code units)", function () {
    const longStr = "a".repeat(150)
    assert.equal(iconv.decode(iconv.encode(longStr, "utf-32le"), "utf-32"), longStr)
  })
})

// Node-only: cross-validate every valid code point against the reference C++ iconv when available.
// Not tagged #node-web (uses Buffer + the optional `iconv` binding), which the web/webpack build maps
// to an empty module, so these are skipped there.
describe("UTF-32 full code point round-trip", function () {
  let Iconv
  try { Iconv = require("iconv").Iconv } catch (_e) {}

  let cache
  function buildAll () {
    if (cache) { return cache }
    const Buffer = require("buffer").Buffer
    let str = ""
    const leBuf = Buffer.alloc(0x10F800 * 4)
    const beBuf = Buffer.alloc(0x10F800 * 4)
    let skip = 0
    for (let i = 0; i <= 0x10F7FF; i++) {
      if (i === 0xD800) { skip = 0x800 } // Jump over the surrogate range (not valid scalar values).
      const cp = i + skip
      str += String.fromCodePoint(cp)
      leBuf.writeUInt32LE(cp, i * 4)
      beBuf.writeUInt32BE(cp, i * 4)
    }
    cache = { str, leBuf, beBuf }
    return cache
  }

  it("handles decoding all valid code points (LE)", function () {
    if (!Iconv) { this.skip() }
    const { str, leBuf } = buildAll()
    assert.equal(iconv.decode(leBuf, "utf-32le"), str)
    assert.equal(new Iconv("UTF-32LE", "UTF-8").convert(leBuf).toString("utf8"), str)
  })

})

// Renders a string as \uXXXX escapes so surrogate mismatches are readable in assertion output.
function escape (s) {
  let out = ""
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i)
    if (code >= 32 && code < 127 && code !== 0x5C) {
      out += s.charAt(i)
    } else {
      out += "\\u" + ("000" + code.toString(16).toUpperCase()).slice(-4)
    }
  }
  return out
}
