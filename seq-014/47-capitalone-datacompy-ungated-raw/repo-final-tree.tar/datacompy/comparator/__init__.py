#
# Copyright 2026 Capital One Services, LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Comparator classes."""

from datacompy.comparator.array import (
    PandasArrayLikeComparator,
    PolarsArrayLikeComparator,
    SnowflakeArrayLikeComparator,
    SparkArrayLikeComparator,
)
from datacompy.comparator.numeric import (
    PandasNumericComparator,
    PolarsNumericComparator,
    SnowflakeNumericComparator,
    SparkNumericComparator,
)
from datacompy.comparator.string import (
    PandasStringComparator,
    PolarsStringComparator,
    SnowflakeStringComparator,
    SparkStringComparator,
)

__all__ = [
    "PandasArrayLikeComparator",
    "PandasNumericComparator",
    "PandasStringComparator",
    "PolarsArrayLikeComparator",
    "PolarsNumericComparator",
    "PolarsStringComparator",
    "SnowflakeArrayLikeComparator",
    "SnowflakeNumericComparator",
    "SnowflakeStringComparator",
    "SparkArrayLikeComparator",
    "SparkNumericComparator",
    "SparkStringComparator",
]
