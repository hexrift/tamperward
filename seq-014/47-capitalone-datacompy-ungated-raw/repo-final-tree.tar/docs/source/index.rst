
.. include:: ../../README.md
   :parser: myst_parser.sphinx_

Contents
========

.. toctree::
    :maxdepth: 2

    Installation <install>
    Comparator Framework Usage <comparator_usage>
    Pandas Usage <pandas_usage>
    Spark Usage <spark_usage>
    Snowflake Usage <snowflake_usage>
    Polars Usage <polars_usage>
    Template Guide <template_guide>
    Benchmarks <benchmark>
    Developer Instructions <developer_instructions>

.. toctree::
   :maxdepth: 4
   :caption: API Reference

   api/modules
   Github Repo <https://github.com/capitalone/datacompy>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
