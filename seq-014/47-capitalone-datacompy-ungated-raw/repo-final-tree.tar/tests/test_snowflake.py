#
# Copyright 2026 Capital One Services, LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
Testing out the datacompy functionality
"""

import io
import logging
import os
import re
import tempfile
from datetime import datetime
from decimal import Decimal
from io import StringIO
from unittest import mock

import numpy as np
import pandas as pd
import pytest

pytest.importorskip("snowflake.snowpark")

from datacompy.comparator.base import BaseComparator
from datacompy.comparator.string import SNOWFLAKE_STRING_TYPE
from datacompy.comparator.utility import get_snowflake_column_dtypes
from datacompy.snowflake import (
    SnowflakeCompare,
    _generate_id_within_group,
    calculate_max_diff,
    columns_equal,
    temp_column_name,
)
from pandas.testing import assert_frame_equal, assert_series_equal
from pytest import raises
from snowflake.snowpark.exceptions import SnowparkSQLException
from snowflake.snowpark.functions import col, length, lit, when
from snowflake.snowpark.types import (
    ArrayType,
    DecimalType,
    IntegerType,
    StringType,
    StructField,
    StructType,
)

pd.DataFrame.iteritems = pd.DataFrame.items  # Pandas 2+ compatability
np.bool = np.bool_  # Numpy 1.24.3+ comptability


def test_numeric_columns_equal_abs(snowflake_session):
    data = """A|B|EXPECTED
1|1|True
2|2.1|True
3|4|False
4|NULL|False
NULL|4|False
NULL|NULL|True"""

    df = snowflake_session.createDataFrame(pd.read_csv(StringIO(data), sep="|"))
    actual_out = columns_equal(df, "A", "B", "ACTUAL", abs_tol=0.2).toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_numeric_columns_equal_rel(snowflake_session):
    data = """A|B|EXPECTED
1|1|True
2|2.1|True
3|4|False
4|NULL|False
NULL|4|False
NULL|NULL|True"""
    df = snowflake_session.createDataFrame(pd.read_csv(StringIO(data), sep="|"))
    actual_out = columns_equal(df, "A", "B", "ACTUAL", rel_tol=0.2).toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_string_columns_equal(snowflake_session):
    data = """A|B|EXPECTED
Hi|Hi|True
Yo|Yo|True
Hey|Hey |False
résumé|resume|False
résumé|résumé|True
💩|💩|True
💩|🤔|False
 | |True
  | |False
datacompy|DataComPy|False
something||False
|something|False
||True"""
    df = snowflake_session.createDataFrame(pd.read_csv(StringIO(data), sep="|"))
    actual_out = columns_equal(df, "A", "B", "ACTUAL", rel_tol=0.2).toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_string_columns_equal_with_ignore_spaces(snowflake_session):
    data = """A|B|EXPECTED
Hi|Hi|True
Yo|Yo|True
Hey|Hey |True
résumé|resume|False
résumé|résumé|True
💩|💩|True
💩|🤔|False
 | |True
  |       |True
datacompy|DataComPy|False
something||False
|something|False
||True"""
    df = snowflake_session.createDataFrame(pd.read_csv(StringIO(data), sep="|"))
    actual_out = columns_equal(
        df, "A", "B", "ACTUAL", rel_tol=0.2, ignore_spaces=True
    ).toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_date_columns_equal(snowflake_session):
    data = """A|B|EXPECTED
2017-01-01|2017-01-01|True
2017-01-02|2017-01-02|True
2017-10-01|2017-10-10|False
2017-01-01||False
|2017-01-01|False
||True"""
    pdf = pd.read_csv(io.StringIO(data), sep="|")
    df = snowflake_session.createDataFrame(pdf)
    # First compare just the strings
    actual_out = columns_equal(df, "A", "B", "ACTUAL", rel_tol=0.2).toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)

    # Then compare converted to datetime objects
    pdf["A"] = pd.to_datetime(pdf["A"])
    pdf["B"] = pd.to_datetime(pdf["B"])
    df = snowflake_session.createDataFrame(pdf)
    actual_out = columns_equal(df, "A", "B", "ACTUAL", rel_tol=0.2).toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)
    # and reverse
    actual_out_rev = columns_equal(df, "B", "A", "ACTUAL", rel_tol=0.2).toPandas()[
        "ACTUAL"
    ]
    assert_series_equal(expect_out, actual_out_rev, check_names=False)


def test_date_columns_equal_with_ignore_spaces(snowflake_session):
    data = """A|B|EXPECTED
2017-01-01|2017-01-01   |True
2017-01-02  |2017-01-02|True
2017-10-01  |2017-10-10   |False
2017-01-01||False
|2017-01-01|False
||True"""
    pdf = pd.read_csv(io.StringIO(data), sep="|")
    df = snowflake_session.createDataFrame(pdf)
    # First compare just the strings
    actual_out = columns_equal(
        df, "A", "B", "ACTUAL", rel_tol=0.2, ignore_spaces=True
    ).toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)

    # Then compare converted to datetime objects
    try:  # pandas 2
        pdf["A"] = pd.to_datetime(pdf["A"], format="mixed")
        pdf["B"] = pd.to_datetime(pdf["B"], format="mixed")
    except ValueError:  # pandas 1.5
        pdf["A"] = pd.to_datetime(pdf["A"])
        pdf["B"] = pd.to_datetime(pdf["B"])
    df = snowflake_session.createDataFrame(pdf)
    actual_out = columns_equal(
        df, "A", "B", "ACTUAL", rel_tol=0.2, ignore_spaces=True
    ).toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)
    # and reverse
    actual_out_rev = columns_equal(
        df, "B", "A", "ACTUAL", rel_tol=0.2, ignore_spaces=True
    ).toPandas()["ACTUAL"]
    assert_series_equal(expect_out, actual_out_rev, check_names=False)


def test_columns_equal_same_type_dif_length(snowflake_session):
    schema = StructType(
        [
            StructField("NAME", StringType(length=20)),
            StructField("DECIMAL_VAL", DecimalType(precision=7, scale=5)),
            StructField("NAME_COPY", StringType(is_max_size=True)),
            StructField("DECIMAL_VAL_COPY", DecimalType(precision=20, scale=10)),
        ]
    )
    data = [
        ["Alice", 10.44556, "Alice", 10.44556],
        ["Bob", 2.33445, "Bob", 2.33445],
        ["Charlie", 5.2234, "Charlie", 5.2234],
    ]

    df = snowflake_session.create_dataframe(data, schema=schema)
    assert (
        columns_equal(df, "NAME", "NAME_COPY", "NAME_ACTUAL")
        .toPandas()["NAME_ACTUAL"]
        .all()
    )
    assert (
        columns_equal(df, "DECIMAL_VAL", "DECIMAL_VAL_COPY", "DECIMAL_VAL_ACTUAL")
        .toPandas()["DECIMAL_VAL_ACTUAL"]
        .all()
    )


def test_date_columns_unequal(snowflake_session):
    """I want datetime fields to match with dates stored as strings"""
    data = [{"A": "2017-01-01", "B": "2017-01-02"}, {"A": "2017-01-01"}]
    pdf = pd.DataFrame(data)
    pdf["A_DT"] = pd.to_datetime(pdf["A"])
    pdf["B_DT"] = pd.to_datetime(pdf["B"])
    df = snowflake_session.createDataFrame(pdf)
    assert columns_equal(df, "A", "A_DT", "ACTUAL").toPandas()["ACTUAL"].all()
    assert columns_equal(df, "B", "B_DT", "ACTUAL").toPandas()["ACTUAL"].all()
    assert columns_equal(df, "A_DT", "A", "ACTUAL").toPandas()["ACTUAL"].all()
    assert columns_equal(df, "B_DT", "B", "ACTUAL").toPandas()["ACTUAL"].all()
    assert not columns_equal(df, "B_DT", "A", "ACTUAL").toPandas()["ACTUAL"].any()
    assert not columns_equal(df, "A_DT", "B", "ACTUAL").toPandas()["ACTUAL"].any()
    assert not columns_equal(df, "A", "B_DT", "ACTUAL").toPandas()["ACTUAL"].any()
    assert not columns_equal(df, "B", "A_DT", "ACTUAL").toPandas()["ACTUAL"].any()


def test_bad_date_columns(snowflake_session):
    """If strings can't be coerced into dates then it should be false for the
    whole column.
    """
    data = [
        {"A": "2017-01-01", "B": "2017-01-01"},
        {"A": "2017-01-01", "B": "217-01-01"},
    ]
    pdf = pd.DataFrame(data)
    pdf["A_DT"] = pd.to_datetime(pdf["A"])
    df = snowflake_session.createDataFrame(pdf)
    assert not columns_equal(df, "A_DT", "B", "ACTUAL").toPandas()["ACTUAL"].all()
    assert columns_equal(df, "A_DT", "B", "ACTUAL").toPandas()["ACTUAL"].any()


def test_rounded_date_columns(snowflake_session):
    """If strings can't be coerced into dates then it should be false for the
    whole column.
    """
    data = [
        {"A": "2017-01-01", "B": "2017-01-01 00:00:00.000000", "EXP": True},
        {"A": "2017-01-01", "B": "2017-01-01 00:00:00.123456", "EXP": False},
        {"A": "2017-01-01", "B": "2017-01-01 00:00:01.000000", "EXP": False},
        {"A": "2017-01-01", "B": "2017-01-01 00:00:00", "EXP": True},
    ]
    pdf = pd.DataFrame(data)
    pdf["A_DT"] = pd.to_datetime(pdf["A"])
    df = snowflake_session.createDataFrame(pdf)
    actual = columns_equal(df, "A_DT", "B", "ACTUAL").toPandas()["ACTUAL"]
    expected = df.select("EXP").toPandas()["EXP"]
    assert_series_equal(actual, expected, check_names=False)


def test_decimal_float_columns_equal(snowflake_session):
    data = [
        {"A": Decimal("1"), "B": 1, "EXPECTED": True},
        {"A": Decimal("1.3"), "B": 1.3, "EXPECTED": True},
        {"A": Decimal("1.000003"), "B": 1.000003, "EXPECTED": True},
        {"A": Decimal("1.000000004"), "B": 1.000000003, "EXPECTED": False},
        {"A": Decimal("1.3"), "B": 1.2, "EXPECTED": False},
        {"A": np.nan, "B": np.nan, "EXPECTED": True},
        {"A": np.nan, "B": 1, "EXPECTED": False},
        {"A": Decimal("1"), "B": np.nan, "EXPECTED": False},
    ]
    pdf = pd.DataFrame(data)
    df = snowflake_session.createDataFrame(pdf)
    actual_out = columns_equal(df, "A", "B", "ACTUAL").toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_decimal_float_columns_equal_rel(snowflake_session):
    data = [
        {"A": Decimal("1"), "B": 1, "EXPECTED": True},
        {"A": Decimal("1.3"), "B": 1.3, "EXPECTED": True},
        {"A": Decimal("1.000003"), "B": 1.000003, "EXPECTED": True},
        {"A": Decimal("1.000000004"), "B": 1.000000003, "EXPECTED": True},
        {"A": Decimal("1.3"), "B": 1.2, "EXPECTED": False},
        {"A": np.nan, "B": np.nan, "EXPECTED": True},
        {"A": np.nan, "B": 1, "EXPECTED": False},
        {"A": Decimal("1"), "B": np.nan, "EXPECTED": False},
    ]
    pdf = pd.DataFrame(data)
    df = snowflake_session.createDataFrame(pdf)
    actual_out = columns_equal(df, "A", "B", "ACTUAL", abs_tol=0.001).toPandas()[
        "ACTUAL"
    ]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_decimal_columns_equal(snowflake_session):
    data = [
        {"A": Decimal("1"), "B": Decimal("1"), "EXPECTED": True},
        {"A": Decimal("1.3"), "B": Decimal("1.3"), "EXPECTED": True},
        {"A": Decimal("1.000003"), "B": Decimal("1.000003"), "EXPECTED": True},
        {
            "A": Decimal("1.000000004"),
            "B": Decimal("1.000000003"),
            "EXPECTED": False,
        },
        {"A": Decimal("1.3"), "B": Decimal("1.2"), "EXPECTED": False},
        {"A": np.nan, "B": np.nan, "EXPECTED": True},
        {"A": np.nan, "B": Decimal("1"), "EXPECTED": False},
        {"A": Decimal("1"), "B": np.nan, "EXPECTED": False},
    ]
    pdf = pd.DataFrame(data)
    df = snowflake_session.createDataFrame(pdf)
    actual_out = columns_equal(df, "A", "B", "ACTUAL").toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_decimal_columns_equal_rel(snowflake_session):
    data = [
        {"A": Decimal("1"), "B": Decimal("1"), "EXPECTED": True},
        {"A": Decimal("1.3"), "B": Decimal("1.3"), "EXPECTED": True},
        {"A": Decimal("1.000003"), "B": Decimal("1.000003"), "EXPECTED": True},
        {
            "A": Decimal("1.000000004"),
            "B": Decimal("1.000000003"),
            "EXPECTED": True,
        },
        {"A": Decimal("1.3"), "B": Decimal("1.2"), "EXPECTED": False},
        {"A": np.nan, "B": np.nan, "EXPECTED": True},
        {"A": np.nan, "B": Decimal("1"), "EXPECTED": False},
        {"A": Decimal("1"), "B": np.nan, "EXPECTED": False},
    ]
    pdf = pd.DataFrame(data)
    df = snowflake_session.createDataFrame(pdf)
    actual_out = columns_equal(df, "A", "B", "ACTUAL", abs_tol=0.001).toPandas()[
        "ACTUAL"
    ]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_infinity_and_beyond(snowflake_session):
    # https://spark.apache.org/docs/latest/sql-ref-datatypes.html#positivenegative-infinity-semantics
    # Positive/negative infinity multiplied by 0 returns NaN.
    # Positive infinity sorts lower than NaN and higher than any other values.
    # Negative infinity sorts lower than any other values.
    data = [
        {"A": np.inf, "B": np.inf, "EXPECTED": True},
        {"A": -np.inf, "B": -np.inf, "EXPECTED": True},
        {"A": -np.inf, "B": np.inf, "EXPECTED": True},
        {"A": np.inf, "B": -np.inf, "EXPECTED": True},
        {"A": 1, "B": 1, "EXPECTED": True},
        {"A": 1, "B": 0, "EXPECTED": False},
    ]
    pdf = pd.DataFrame(data)
    df = snowflake_session.createDataFrame(pdf)
    actual_out = columns_equal(df, "A", "B", "ACTUAL").toPandas()["ACTUAL"]
    expect_out = df.select("EXPECTED").toPandas()["EXPECTED"]
    assert_series_equal(expect_out, actual_out, check_names=False)


def test_compare_table_setter_bad(snowflake_session):
    # Invalid table name
    with raises(ValueError, match=r"invalid_table_name_1 is not a valid table name."):
        SnowflakeCompare(
            snowflake_session, "invalid_table_name_1", "invalid_table_name_2", ["A"]
        )
    # Valid table name but table does not exist
    with raises(SnowparkSQLException):
        SnowflakeCompare(
            snowflake_session, "non.existant.table_1", "non.existant.table_2", ["A"]
        )


@mock.patch(
    "datacompy.snowflake.SnowflakeCompare._validate_dataframe", new=mock.MagicMock()
)
@mock.patch("datacompy.snowflake.SnowflakeCompare._compare", new=mock.MagicMock())
def test_compare_table_unique_names(snowflake_session):
    # Assert that two tables with the same name but from a different DB/Schema have unique names
    # Same schema/name, different DB
    compare = SnowflakeCompare(
        snowflake_session,
        "test_db1.test_schema.test_name",
        "test_db2.test_schema.test_name",
        ["A"],
    )
    assert compare.df1_name != compare.df2_name

    # Same db/name, different schema
    compare = SnowflakeCompare(
        snowflake_session,
        "test_db.test_schema1.test_name",
        "test_db.test_schema2.test_name",
        ["A"],
    )
    assert compare.df1_name != compare.df2_name


def test_compare_table_setter_good(snowflake_session):
    data = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
    10000001234,123.4,George Michael Bluth,14530.155,
    10000001235,0.45,Michael Bluth,,
    10000001236,1345,George Bluth,1,
    10000001237,123456,Robert Loblaw,345.12,
    10000001238,1.05,Loose Seal Bluth,111,
    10000001240,123.45,George Maharis,14530.1555,2017-01-02
    """
    df = pd.read_csv(StringIO(data), sep=",")
    database = snowflake_session.get_current_database().replace('"', "")
    schema = snowflake_session.get_current_schema().replace('"', "")
    full_table_name = f"{database}.{schema}"
    toy_table_name_1 = "DC_TOY_TABLE_1"
    toy_table_name_2 = "DC_TOY_TABLE_2"
    full_toy_table_name_1 = f"{full_table_name}.{toy_table_name_1}"
    full_toy_table_name_2 = f"{full_table_name}.{toy_table_name_2}"

    snowflake_session.write_pandas(
        df, toy_table_name_1, table_type="temp", auto_create_table=True, overwrite=True
    )
    snowflake_session.write_pandas(
        df, toy_table_name_2, table_type="temp", auto_create_table=True, overwrite=True
    )

    compare = SnowflakeCompare(
        snowflake_session,
        full_toy_table_name_1,
        full_toy_table_name_2,
        join_columns=["ACCT_ID"],
    )
    assert compare.df1.toPandas().equals(df)
    assert compare.join_columns == ["ACCT_ID"]


def test_compare_df_setter_bad(snowflake_session):
    pdf = pd.DataFrame([{"A": 1, "C": 2}, {"A": 2, "C": 2}])
    df = snowflake_session.createDataFrame(pdf)
    with raises(TypeError, match=r"DF1 must be a valid sp.Dataframe"):
        SnowflakeCompare(snowflake_session, 3, 2, ["A"])
    with raises(ValueError, match="DF1 must have all columns from join_columns"):
        SnowflakeCompare(snowflake_session, df, df.select("*"), ["B"])
    pdf = pd.DataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 3}])
    df_dupe = snowflake_session.createDataFrame(pdf)
    pd.testing.assert_frame_equal(
        SnowflakeCompare(
            snowflake_session, df_dupe, df_dupe.select("*"), ["A", "B"]
        ).df1.toPandas(),
        pdf,
        check_dtype=False,
    )


def test_compare_df_setter_good(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 2, "B": 2}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 2, "B": 3}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["A"])
    assert compare.df1.toPandas().equals(df1.toPandas())
    assert compare.join_columns == ["A"]
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["A", "B"])
    assert compare.df1.toPandas().equals(df1.toPandas())
    assert compare.join_columns == ["A", "B"]


def test_compare_df_setter_different_cases(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 2, "B": 2}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 2, "B": 3}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["A"])
    assert compare.df1.toPandas().equals(df1.toPandas())


def test_columns_overlap(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 2, "B": 2}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 2, "B": 3}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["A"])
    assert compare.df1_unq_columns() == set()
    assert compare.df2_unq_columns() == set()
    assert compare.intersect_columns() == {"A", "B"}


def test_columns_no_overlap(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "C": "HI"}, {"A": 2, "B": 2, "C": "YO"}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "D": "OH"}, {"A": 2, "B": 3, "D": "YA"}]
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["A"])
    assert compare.df1_unq_columns() == {"C"}
    assert compare.df2_unq_columns() == {"D"}
    assert compare.intersect_columns() == {"A", "B"}


def test_columns_maintain_order_through_set_operations(snowflake_session):
    pdf1 = pd.DataFrame(
        {
            "JOIN": ["A", "B"],
            "F": [0, 0],
            "G": [1, 2],
            "B": [2, 2],
            "H": [3, 3],
            "A": [4, 4],
            "C": [-2, -3],
        }
    )
    pdf2 = pd.DataFrame(
        {
            "JOIN": ["A", "B"],
            "E": [0, 1],
            "H": [1, 2],
            "B": [2, 3],
            "A": [-1, -1],
            "G": [4, 4],
            "D": [-3, -2],
        }
    )
    df1 = snowflake_session.createDataFrame(pdf1)
    df2 = snowflake_session.createDataFrame(pdf2)
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["JOIN"])
    assert list(compare.df1_unq_columns()) == ["F", "C"]
    assert list(compare.df2_unq_columns()) == ["E", "D"]
    assert list(compare.intersect_columns()) == ["JOIN", "G", "B", "H", "A"]


def test_10k_rows(snowflake_session):
    rng = np.random.default_rng()
    pdf = pd.DataFrame(rng.integers(0, 100, size=(10000, 2)), columns=["B", "C"])
    pdf.reset_index(inplace=True)
    pdf.columns = ["A", "B", "C"]
    pdf2 = pdf.copy()
    pdf2["B"] = pdf2["B"] + 0.1
    df1 = snowflake_session.createDataFrame(pdf)
    df2 = snowflake_session.createDataFrame(pdf2)
    compare_tol = SnowflakeCompare(snowflake_session, df1, df2, ["A"], abs_tol=0.2)
    assert compare_tol.matches()
    assert compare_tol.df1_unq_rows.count() == 0
    assert compare_tol.df2_unq_rows.count() == 0
    assert compare_tol.intersect_columns() == {"A", "B", "C"}
    assert compare_tol.all_columns_match()
    assert compare_tol.all_rows_overlap()
    assert compare_tol.intersect_rows_match()

    compare_no_tol = SnowflakeCompare(snowflake_session, df1, df2, ["A"])
    assert not compare_no_tol.matches()
    assert compare_no_tol.df1_unq_rows.count() == 0
    assert compare_no_tol.df2_unq_rows.count() == 0
    assert compare_no_tol.intersect_columns() == {"A", "B", "C"}
    assert compare_no_tol.all_columns_match()
    assert compare_no_tol.all_rows_overlap()
    assert not compare_no_tol.intersect_rows_match()


def test_10k_rows_abs_tol_per_column(snowflake_session):
    rng = np.random.default_rng()
    pdf = pd.DataFrame(rng.integers(0, 100, size=(10000, 2)), columns=["B", "C"])
    pdf.reset_index(inplace=True)
    pdf.columns = ["A", "B", "C"]
    pdf2 = pdf.copy()
    pdf2["B"] = pdf2["B"] + 0.1
    df1 = snowflake_session.createDataFrame(pdf)
    df2 = snowflake_session.createDataFrame(pdf2)
    compare_tol = SnowflakeCompare(
        snowflake_session, df1, df2, ["A"], abs_tol={"B": 0.2}
    )
    assert compare_tol.matches()
    assert compare_tol.df1_unq_rows.count() == 0
    assert compare_tol.df2_unq_rows.count() == 0
    assert compare_tol.intersect_columns() == {"A", "B", "C"}
    assert compare_tol.all_columns_match()
    assert compare_tol.all_rows_overlap()
    assert compare_tol.intersect_rows_match()


def test_10k_rows_abs_tol_per_column_default(snowflake_session):
    rng = np.random.default_rng()
    pdf = pd.DataFrame(rng.integers(0, 100, size=(10000, 2)), columns=["B", "C"])
    pdf.reset_index(inplace=True)
    pdf.columns = ["A", "B", "C"]
    pdf2 = pdf.copy()
    pdf2["B"] = pdf2["B"] + 0.1
    pdf2["C"] = pdf2["C"] + 0.3
    df1 = snowflake_session.createDataFrame(pdf)
    df2 = snowflake_session.createDataFrame(pdf2)
    compare_tol = SnowflakeCompare(
        snowflake_session, df1, df2, ["A"], abs_tol={"c": 0.0, "default": 0.2}
    )
    assert not compare_tol.matches()
    assert compare_tol.df1_unq_rows.count() == 0
    assert compare_tol.df2_unq_rows.count() == 0
    assert compare_tol.intersect_columns() == {"A", "B", "C"}
    assert compare_tol.all_columns_match()
    assert compare_tol.all_rows_overlap()
    assert not compare_tol.intersect_rows_match()


def test_10k_rows_rel_tol_per_column(snowflake_session):
    rng = np.random.default_rng()
    pdf = pd.DataFrame(rng.integers(0, 100, size=(10000, 2)), columns=["B", "C"])
    pdf.reset_index(inplace=True)
    pdf.columns = ["A", "B", "C"]
    pdf2 = pdf.copy()
    pdf2["B"] = pdf2["B"] + 0.1
    df1 = snowflake_session.createDataFrame(pdf)
    df2 = snowflake_session.createDataFrame(pdf2)
    compare_tol = SnowflakeCompare(
        snowflake_session, df1, df2, ["A"], rel_tol={"B": 1.0}
    )
    assert compare_tol.matches()
    assert compare_tol.df1_unq_rows.count() == 0
    assert compare_tol.df2_unq_rows.count() == 0
    assert compare_tol.intersect_columns() == {"A", "B", "C"}
    assert compare_tol.all_columns_match()
    assert compare_tol.all_rows_overlap()
    assert compare_tol.intersect_rows_match()


def test_10k_rows_rel_tol_per_column_default(snowflake_session):
    rng = np.random.default_rng()
    pdf = pd.DataFrame(rng.integers(0, 100, size=(10000, 2)), columns=["B", "C"])
    pdf.reset_index(inplace=True)
    pdf.columns = ["A", "B", "C"]
    pdf2 = pdf.copy()
    pdf2["B"] = pdf2["B"] + 0.1
    pdf2["C"] = pdf2["C"] + 0.1
    df1 = snowflake_session.createDataFrame(pdf)
    df2 = snowflake_session.createDataFrame(pdf2)
    compare_tol = SnowflakeCompare(
        snowflake_session, df1, df2, ["A"], rel_tol={"c": 0.0, "default": 1}
    )
    assert not compare_tol.matches()
    assert compare_tol.df1_unq_rows.count() == 0
    assert compare_tol.df2_unq_rows.count() == 0
    assert compare_tol.intersect_columns() == {"A", "B", "C"}
    assert compare_tol.all_columns_match()
    assert compare_tol.all_rows_overlap()
    assert not compare_tol.intersect_rows_match()


def test_subset(snowflake_session, caplog):
    caplog.set_level(logging.DEBUG)
    df1 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "C": "HI"}, {"A": 2, "B": 2, "C": "YO"}]
    )
    df2 = snowflake_session.createDataFrame([{"A": 1, "C": "HI"}])
    comp = SnowflakeCompare(snowflake_session, df1, df2, ["A"])
    assert comp.subset()


def test_not_subset(snowflake_session, caplog):
    caplog.set_level(logging.INFO)
    df1 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "C": "HI"}, {"A": 2, "B": 2, "C": "YO"}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "C": "HI"}, {"A": 2, "B": 2, "C": "GREAT"}]
    )
    comp = SnowflakeCompare(snowflake_session, df1, df2, ["A"])
    assert not comp.subset()
    assert "C: 1 / 2 (50.00%) match" in caplog.text


def test_large_subset(snowflake_session):
    rng = np.random.default_rng()
    pdf = pd.DataFrame(rng.integers(0, 100, size=(10000, 2)), columns=["B", "C"])
    pdf.reset_index(inplace=True)
    pdf.columns = ["A", "B", "C"]
    pdf2 = pdf[["A", "B"]].head(50).copy()
    df1 = snowflake_session.createDataFrame(pdf)
    df2 = snowflake_session.createDataFrame(pdf2)
    comp = SnowflakeCompare(snowflake_session, df1, df2, ["A"])
    assert not comp.matches()
    assert comp.subset()


def test_string_joiner(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"AB": 1, "BC": 2}, {"AB": 2, "BC": 2}])
    df2 = snowflake_session.createDataFrame([{"AB": 1, "BC": 2}, {"AB": 2, "BC": 2}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, "AB")
    assert compare.matches()


def test_decimal_with_joins(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": Decimal("1"), "B": 2}, {"A": Decimal("2"), "B": 2}]
    )
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 2, "B": 2}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, "A")
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()


def test_decimal_with_nulls(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": 1, "B": Decimal("2")}, {"A": 2, "B": Decimal("2")}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2}, {"A": 2, "B": 2}, {"A": 3, "B": 2}]
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, "A")
    assert not compare.matches()
    assert compare.all_columns_match()
    assert not compare.all_rows_overlap()
    assert compare.intersect_rows_match()


def test_strings_with_joins(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": "HI", "B": 2}, {"A": "BYE", "B": 2}])
    df2 = snowflake_session.createDataFrame([{"A": "HI", "B": 2}, {"A": "BYE", "B": 2}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, "A")
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()


def test_temp_column_name(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": "HI", "B": 2}, {"A": "BYE", "B": 2}])
    df2 = snowflake_session.createDataFrame(
        [{"A": "HI", "B": 2}, {"A": "BYE", "B": 2}, {"A": "back fo mo", "B": 3}]
    )
    actual = temp_column_name(df1, df2)
    assert actual == "_TEMP_0"


def test_temp_column_name_one_has(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"_TEMP_0": "HI", "B": 2}, {"_TEMP_0": "BYE", "B": 2}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": "HI", "B": 2}, {"A": "BYE", "B": 2}, {"A": "back fo mo", "B": 3}]
    )
    actual = temp_column_name(df1, df2)
    assert actual == "_TEMP_1"


def test_temp_column_name_both_have_temp_1(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"_TEMP_0": "HI", "B": 2}, {"_TEMP_0": "BYE", "B": 2}]
    )
    df2 = snowflake_session.createDataFrame(
        [
            {"_TEMP_0": "HI", "B": 2},
            {"_TEMP_0": "BYE", "B": 2},
            {"A": "back fo mo", "B": 3},
        ]
    )
    actual = temp_column_name(df1, df2)
    assert actual == "_TEMP_1"


def test_temp_column_name_both_have_temp_2(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"_TEMP_0": "HI", "B": 2}, {"_TEMP_0": "BYE", "B": 2}]
    )
    df2 = snowflake_session.createDataFrame(
        [
            {"_TEMP_0": "HI", "B": 2},
            {"_TEMP_1": "BYE", "B": 2},
            {"A": "back fo mo", "B": 3},
        ]
    )
    actual = temp_column_name(df1, df2)
    assert actual == "_TEMP_2"


def test_temp_column_name_one_already(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"_TEMP_1": "HI", "B": 2}, {"_TEMP_1": "BYE", "B": 2}]
    )
    df2 = snowflake_session.createDataFrame(
        [
            {"_TEMP_1": "HI", "B": 2},
            {"_TEMP_1": "BYE", "B": 2},
            {"A": "back fo mo", "B": 3},
        ]
    )
    actual = temp_column_name(df1, df2)
    assert actual == "_TEMP_0"


# Duplicate testing!


def test_simple_dupes_one_field(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 2}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 2}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["A"])
    assert compare.matches()
    # Just render the report to make sure it renders.
    compare.report()


def test_simple_dupes_two_fields(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2}, {"A": 1, "B": 2, "C": 2}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2}, {"A": 1, "B": 2, "C": 2}]
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["A", "B"])
    assert compare.matches()
    # Just render the report to make sure it renders.
    compare.report()


def test_simple_dupes_one_field_two_vals_1(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 0}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["A"])
    assert compare.matches()
    # Just render the report to make sure it renders.
    compare.report()


def test_simple_dupes_one_field_two_vals_2(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 0}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 2, "B": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["A"])
    assert not compare.matches()
    assert compare.df1_unq_rows.count() == 1
    assert compare.df2_unq_rows.count() == 1
    assert compare.intersect_rows.count() == 1
    # Just render the report to make sure it renders.
    compare.report()


def test_simple_dupes_one_field_three_to_two_vals(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2}, {"A": 1, "B": 0}, {"A": 1, "B": 0}]
    )
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["A"])
    assert not compare.matches()
    assert compare.df1_unq_rows.count() == 1
    assert compare.df2_unq_rows.count() == 0
    assert compare.intersect_rows.count() == 2
    # Just render the report to make sure it renders.
    compare.report()
    assert "(First 1 Columns)" in compare.report(column_count=1)
    assert "(First 2 Columns)" in compare.report(column_count=2)


def test_dupes_from_real_data(snowflake_session):
    data = """ACCT_ID,ACCT_SFX_NUM,TRXN_POST_DT,TRXN_POST_SEQ_NUM,TRXN_AMT,TRXN_DT,DEBIT_CR_CD,CASH_ADV_TRXN_COMN_CNTRY_CD,MRCH_CATG_CD,MRCH_PSTL_CD,VISA_MAIL_PHN_CD,VISA_RQSTD_PMT_SVC_CD,MC_PMT_FACILITATOR_IDN_NUM
100,0,2017-06-17,1537019,30.64,2017-06-15,D,CAN,5812,M2N5P5,,,0.0
200,0,2017-06-24,1022477,485.32,2017-06-22,D,USA,4511,7114,7.0,1,
100,0,2017-06-17,1537039,2.73,2017-06-16,D,CAN,5812,M4J 1M9,,,0.0
200,0,2017-06-29,1049223,22.41,2017-06-28,D,USA,4789,21211,,A,
100,0,2017-06-17,1537029,34.05,2017-06-16,D,CAN,5812,M4E 2C7,,,0.0
200,0,2017-06-29,1049213,9.12,2017-06-28,D,CAN,5814,0,,,
100,0,2017-06-19,1646426,165.21,2017-06-17,D,CAN,5411,M4M 3H9,,,0.0
200,0,2017-06-30,1233082,28.54,2017-06-29,D,USA,4121,94105,7.0,G,
100,0,2017-06-19,1646436,17.87,2017-06-18,D,CAN,5812,M4J 1M9,,,0.0
200,0,2017-06-30,1233092,24.39,2017-06-29,D,USA,4121,94105,7.0,G,
100,0,2017-06-19,1646446,5.27,2017-06-17,D,CAN,5200,M4M 3G6,,,0.0
200,0,2017-06-30,1233102,61.8,2017-06-30,D,CAN,4121,0,,,
100,0,2017-06-20,1607573,41.99,2017-06-19,D,CAN,5661,M4C1M9,,,0.0
200,0,2017-07-01,1009403,2.31,2017-06-29,D,USA,5814,22102,,F,
100,0,2017-06-20,1607553,86.88,2017-06-19,D,CAN,4812,H2R3A8,,,0.0
200,0,2017-07-01,1009423,5.5,2017-06-29,D,USA,5812,2903,,F,
100,0,2017-06-20,1607563,25.17,2017-06-19,D,CAN,5641,M4C 1M9,,,0.0
200,0,2017-07-01,1009433,214.12,2017-06-29,D,USA,3640,20170,,A,
100,0,2017-06-20,1607593,1.67,2017-06-19,D,CAN,5814,M2N 6L7,,,0.0
200,0,2017-07-01,1009393,2.01,2017-06-29,D,USA,5814,22102,,F,"""
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data), sep=","))
    df2 = df1.select("*")
    compare_acct = SnowflakeCompare(
        snowflake_session, df1, df2, join_columns=["ACCT_ID"]
    )
    assert compare_acct.matches()
    compare_acct.report()

    compare_unq = SnowflakeCompare(
        snowflake_session,
        df1,
        df2,
        join_columns=["ACCT_ID", "ACCT_SFX_NUM", "TRXN_POST_DT", "TRXN_POST_SEQ_NUM"],
    )
    assert compare_unq.matches()
    compare_unq.report()


def test_strings_with_joins_with_ignore_spaces(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": "HI", "B": " A"}, {"A": "BYE", "B": "A"}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": "HI", "B": "A"}, {"A": "BYE", "B": "A "}]
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=False)
    assert not compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert not compare.intersect_rows_match()

    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=True)
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()


def test_decimal_with_joins_with_ignore_spaces(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": " A"}, {"A": 2, "B": "A"}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": "A"}, {"A": 2, "B": "A "}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=False)
    assert not compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert not compare.intersect_rows_match()

    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=True)
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()


def test_joins_with_ignore_spaces(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": " A"}, {"A": 2, "B": "A"}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": "A"}, {"A": 2, "B": "A "}])

    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=True)
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()


def test_joins_with_insensitive_lowercase_cols(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "B": "A"}, {"a": 2, "B": "A"}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": "A"}, {"A": 2, "B": "A"}])

    compare = SnowflakeCompare(snowflake_session, df1, df2, "A")
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()

    df1 = snowflake_session.createDataFrame([{"A": 1, "B": "A"}, {"A": 2, "B": "A"}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": "A"}, {"A": 2, "B": "A"}])

    compare = SnowflakeCompare(snowflake_session, df1, df2, "a")
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()


def test_joins_with_sensitive_lowercase_cols(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{'"a"': 1, "B": "A"}, {'"a"': 2, "B": "A"}]
    )
    df2 = snowflake_session.createDataFrame(
        [{'"a"': 1, "B": "A"}, {'"a"': 2, "B": "A"}]
    )

    compare = SnowflakeCompare(snowflake_session, df1, df2, '"a"')
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()


def test_full_join_counts_all_matches(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 2}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 2}])
    compare = SnowflakeCompare(
        snowflake_session, df1, df2, ["A", "B"], ignore_spaces=False
    )
    assert compare.count_matching_rows() == 2


def test_strings_with_ignore_spaces_and_join_columns(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": "HI", "B": "A"}, {"A": "BYE", "B": "A"}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": " HI ", "B": "A"}, {"A": " BYE ", "B": "A"}]
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=False)
    assert not compare.matches()
    assert compare.all_columns_match()
    assert not compare.all_rows_overlap()
    assert compare.count_matching_rows() == 0

    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=True)
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()
    assert compare.count_matching_rows() == 2


def test_integers_with_ignore_spaces_and_join_columns(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": "A"}, {"A": 2, "B": "A"}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": "A"}, {"A": 2, "B": "A"}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=False)
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()
    assert compare.count_matching_rows() == 2

    compare = SnowflakeCompare(snowflake_session, df1, df2, "A", ignore_spaces=True)
    assert compare.matches()
    assert compare.all_columns_match()
    assert compare.all_rows_overlap()
    assert compare.intersect_rows_match()
    assert compare.count_matching_rows() == 2


def test_sample_mismatch(snowflake_session):
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
    10000001234,123.45,George Maharis,14530.1555,2017-01-01
    10000001235,0.45,Michael Bluth,1,2017-01-01
    10000001236,1345,George Bluth,,2017-01-01
    10000001237,123456,Bob Loblaw,345.12,2017-01-01
    10000001239,1.05,Lucille Bluth,,2017-01-01
    10000001240,123.45,George Maharis,14530.1555,2017-01-02
    """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
    10000001234,123.4,George Michael Bluth,14530.155,
    10000001235,0.45,Michael Bluth,,
    10000001236,1345,George Bluth,1,
    10000001237,123456,Robert Loblaw,345.12,
    10000001238,1.05,Loose Seal Bluth,111,
    10000001240,123.45,George Maharis,14530.1555,2017-01-02
    """

    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))

    compare = SnowflakeCompare(snowflake_session, df1, df2, "ACCT_ID")

    output = compare.sample_mismatch(column="NAME", sample_count=1).toPandas()
    assert output.shape[0] == 1
    assert (output.NAME_DF1 != output.NAME_DF2).all()

    output = compare.sample_mismatch(column="NAME", sample_count=2).toPandas()
    assert output.shape[0] == 2
    assert (output.NAME_DF1 != output.NAME_DF2).all()

    output = compare.sample_mismatch(column="NAME", sample_count=3).toPandas()
    assert output.shape[0] == 2
    assert (output.NAME_DF1 != output.NAME_DF2).all()


def test_all_mismatch_not_ignore_matching_cols_no_cols_matching(snowflake_session):
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
    10000001234,123.45,George Maharis,14530.1555,2017-01-01
    10000001235,0.45,Michael Bluth,1,2017-01-01
    10000001236,1345,George Bluth,,2017-01-01
    10000001237,123456,Bob Loblaw,345.12,2017-01-01
    10000001239,1.05,Lucille Bluth,,2017-01-01
    10000001240,123.45,George Maharis,14530.1555,2017-01-02
    """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
    10000001234,123.4,George Michael Bluth,14530.155,
    10000001235,0.45,Michael Bluth,,
    10000001236,1345,George Bluth,1,
    10000001237,123456,Robert Loblaw,345.12,
    10000001238,1.05,Loose Seal Bluth,111,
    10000001240,123.45,George Maharis,14530.1555,2017-01-02
    """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(snowflake_session, df1, df2, "ACCT_ID")

    output = compare.all_mismatch().toPandas()
    assert output.shape[0] == 4
    assert output.shape[1] == 9

    assert (output.NAME_DF1 != output.NAME_DF2).values.sum() == 2
    assert (~(output.NAME_DF1 != output.NAME_DF2)).values.sum() == 2

    assert (output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2).values.sum() == 1
    assert (~(output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2)).values.sum() == 3

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 3
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 4
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 0


def test_all_mismatch_not_ignore_matching_cols_some_cols_matching(snowflake_session):
    # Columns dollar_amt and name are matching
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1,2017-01-01
        10000001236,1345,George Bluth,,2017-01-01
        10000001237,123456,Bob Loblaw,345.12,2017-01-01
        10000001239,1.05,Lucille Bluth,,2017-01-01
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.155,
        10000001235,0.45,Michael Bluth,,
        10000001236,1345,George Bluth,1,
        10000001237,123456,Bob Loblaw,345.12,
        10000001238,1.05,Lucille Bluth,111,
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(snowflake_session, df1, df2, "ACCT_ID")

    output = compare.all_mismatch().toPandas()
    assert output.shape[0] == 4
    assert output.shape[1] == 9

    assert (output.NAME_DF1 != output.NAME_DF2).values.sum() == 0
    assert (~(output.NAME_DF1 != output.NAME_DF2)).values.sum() == 4

    assert (output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2).values.sum() == 0
    assert (~(output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2)).values.sum() == 4

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 3
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 4
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 0


def test_all_mismatch_ignore_matching_cols_some_cols_matching_diff_rows(
    snowflake_session,
):
    # Case where there are rows on either dataset which don't match up.
    # Columns dollar_amt and name are matching
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1,2017-01-01
        10000001236,1345,George Bluth,,2017-01-01
        10000001237,123456,Bob Loblaw,345.12,2017-01-01
        10000001239,1.05,Lucille Bluth,,2017-01-01
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        10000001241,1111.05,Lucille Bluth,
        """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.155,
        10000001235,0.45,Michael Bluth,,
        10000001236,1345,George Bluth,1,
        10000001237,123456,Bob Loblaw,345.12,
        10000001238,1.05,Lucille Bluth,111,
        """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(snowflake_session, df1, df2, "ACCT_ID")

    output = compare.all_mismatch(ignore_matching_cols=True).toPandas()

    assert output.shape[0] == 4
    assert output.shape[1] == 5

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 3
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 4
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 0

    assert not ("NAME_DF1" in output and "NAME_DF2" in output)
    assert not ("DOLLAR_AMT_DF1" in output and "DOLLAR_AMT_DF1" in output)


def test_all_mismatch_ignore_matching_cols_some_cols_matching(snowflake_session):
    # Columns dollar_amt and name are matching
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1,2017-01-01
        10000001236,1345,George Bluth,,2017-01-01
        10000001237,123456,Bob Loblaw,345.12,2017-01-01
        10000001239,1.05,Lucille Bluth,,2017-01-01
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.155,
        10000001235,0.45,Michael Bluth,,
        10000001236,1345,George Bluth,1,
        10000001237,123456,Bob Loblaw,345.12,
        10000001238,1.05,Lucille Bluth,111,
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(snowflake_session, df1, df2, "ACCT_ID")

    output = compare.all_mismatch(ignore_matching_cols=True).toPandas()

    assert output.shape[0] == 4
    assert output.shape[1] == 5

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 3
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 4
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 0

    assert not ("NAME_DF1" in output and "NAME_DF2" in output)
    assert not ("DOLLAR_AMT_DF1" in output and "DOLLAR_AMT_DF1" in output)


def test_all_mismatch_ignore_matching_cols_no_cols_matching(snowflake_session):
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1,2017-01-01
        10000001236,1345,George Bluth,,2017-01-01
        10000001237,123456,Bob Loblaw,345.12,2017-01-01
        10000001239,1.05,Lucille Bluth,,2017-01-01
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.4,George Michael Bluth,14530.155,
        10000001235,0.45,Michael Bluth,,
        10000001236,1345,George Bluth,1,
        10000001237,123456,Robert Loblaw,345.12,
        10000001238,1.05,Loose Seal Bluth,111,
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(snowflake_session, df1, df2, "ACCT_ID")

    output = compare.all_mismatch().toPandas()
    assert output.shape[0] == 4
    assert output.shape[1] == 9

    assert (output.NAME_DF1 != output.NAME_DF2).values.sum() == 2
    assert (~(output.NAME_DF1 != output.NAME_DF2)).values.sum() == 2

    assert (output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2).values.sum() == 1
    assert (~(output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2)).values.sum() == 3

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 3
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 4
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 0


def test_all_mismatch_ignore_matching_cols_no_cols_matching_abs_tol_float(
    snowflake_session,
):
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1,2017-01-01
        10000001236,1345,George Bluth,,2017-01-01
        10000001237,123456,Bob Loblaw,345.12,2017-01-01
        10000001239,1.05,Lucille Bluth,,2017-01-01
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.4,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1.04,2017-01-01
        10000001236,1345,George Bluth,1,
        10000001237,123456,Robert Loblaw,345.12,
        10000001238,1.05,Loose Seal Bluth,111,
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(snowflake_session, df1, df2, "ACCT_ID", 0.05)

    output = compare.all_mismatch().toPandas()
    assert output.shape[0] == 2
    assert output.shape[1] == 9

    assert (output.NAME_DF1 != output.NAME_DF2).values.sum() == 1
    assert (~(output.NAME_DF1 != output.NAME_DF2)).values.sum() == 1

    assert (output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2).values.sum() == 0
    assert (~(output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2)).values.sum() == 2

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 1
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 2
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 0


def test_all_mismatch_ignore_matching_cols_no_cols_matching_abs_tol_dict(
    snowflake_session,
):
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1,2017-01-01
        10000001236,1345,George Bluth,,2017-01-01
        10000001237,123456,Bob Loblaw,345.12,2017-01-01
        10000001239,1.05,Lucille Bluth,,2017-01-01
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.4,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1.05,2017-01-01
        10000001236,1345,George Bluth,1,
        10000001237,123456,Robert Loblaw,345.12,
        10000001238,1.05,Loose Seal Bluth,111,
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(
        snowflake_session, df1, df2, "ACCT_ID", {"DOLLAR_AMT": 0.05}
    )

    output = compare.all_mismatch().toPandas()
    compare.report()

    assert output.shape[0] == 3
    assert output.shape[1] == 9

    assert (output.NAME_DF1 != output.NAME_DF2).values.sum() == 1
    assert (~(output.NAME_DF1 != output.NAME_DF2)).values.sum() == 2

    assert (output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2).values.sum() == 0
    assert (~(output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2)).values.sum() == 3

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 2
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 2
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 1


def test_all_mismatch_ignore_matching_cols_no_cols_matching_rel_tol_float(
    snowflake_session,
):
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1,2017-01-01
        10000001236,1345,George Bluth,,2017-01-01
        10000001237,123456,Bob Loblaw,345.12,2017-01-01
        10000001239,1.05,Lucille Bluth,,2017-01-01
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.4,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1.04,2017-01-01
        10000001236,1345,George Bluth,1,
        10000001237,123456,Robert Loblaw,345.12,
        10000001238,1.05,Loose Seal Bluth,111,
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(snowflake_session, df1, df2, "ACCT_ID", rel_tol=0.1)

    output = compare.all_mismatch().toPandas()
    assert output.shape[0] == 2
    assert output.shape[1] == 9

    assert (output.NAME_DF1 != output.NAME_DF2).values.sum() == 1
    assert (~(output.NAME_DF1 != output.NAME_DF2)).values.sum() == 1

    assert (output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2).values.sum() == 0
    assert (~(output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2)).values.sum() == 2

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 1
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 2
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 0


def test_all_mismatch_ignore_matching_cols_no_cols_matching_rel_tol_dict(
    snowflake_session,
):
    data1 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.45,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1,2017-01-01
        10000001236,1345,George Bluth,,2017-01-01
        10000001237,123456,Bob Loblaw,345.12,2017-01-01
        10000001239,1.05,Lucille Bluth,,2017-01-01
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """

    data2 = """ACCT_ID,DOLLAR_AMT,NAME,FLOAT_FLD,DATE_FLD
        10000001234,123.4,George Maharis,14530.1555,2017-01-01
        10000001235,0.45,Michael Bluth,1.05,2017-01-01
        10000001236,1345,George Bluth,1,
        10000001237,123456,Robert Loblaw,345.12,
        10000001238,1.05,Loose Seal Bluth,111,
        10000001240,123.45,George Maharis,14530.1555,2017-01-02
        """
    df1 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data1), sep=","))
    df2 = snowflake_session.createDataFrame(pd.read_csv(StringIO(data2), sep=","))
    compare = SnowflakeCompare(
        snowflake_session, df1, df2, "ACCT_ID", {"DOLLAR_AMT": 0.05}
    )

    output = compare.all_mismatch().toPandas()
    compare.report()

    assert output.shape[0] == 3
    assert output.shape[1] == 9

    assert (output.NAME_DF1 != output.NAME_DF2).values.sum() == 1
    assert (~(output.NAME_DF1 != output.NAME_DF2)).values.sum() == 2

    assert (output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2).values.sum() == 0
    assert (~(output.DOLLAR_AMT_DF1 != output.DOLLAR_AMT_DF2)).values.sum() == 3

    assert (output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2).values.sum() == 2
    assert (~(output.FLOAT_FLD_DF1 != output.FLOAT_FLD_DF2)).values.sum() == 1

    assert (output.DATE_FLD_DF1 != output.DATE_FLD_DF2).values.sum() == 2
    assert (~(output.DATE_FLD_DF1 != output.DATE_FLD_DF2)).values.sum() == 1


@pytest.mark.parametrize(
    "column, expected",
    [
        ("BASE", 0),
        ("FLOATS", 0.2),
        ("DECIMALS", 0.1),
        ("NULL_FLOATS", 0.1),
        ("STRINGS", 0.1),
        ("INFINITY", np.inf),
    ],
)
def test_calculate_max_diff(snowflake_session, column, expected):
    pdf = pd.DataFrame(
        {
            "BASE": [1, 1, 1, 1, 1],
            "FLOATS": [1.1, 1.1, 1.1, 1.2, 0.9],
            "DECIMALS": [
                Decimal("1.1"),
                Decimal("1.1"),
                Decimal("1.1"),
                Decimal("1.1"),
                Decimal("1.1"),
            ],
            "NULL_FLOATS": [np.nan, 1.1, 1, 1, 1],
            "STRINGS": ["1", "1", "1", "1.1", "1"],
            "INFINITY": [1, 1, 1, 1, np.inf],
        }
    )
    MAX_DIFF_DF = snowflake_session.createDataFrame(pdf)
    assert np.isclose(
        calculate_max_diff(MAX_DIFF_DF, "BASE", column).result()[0][0],
        expected,
    )


def test_dupes_with_nulls_strings(snowflake_session):
    pdf1 = pd.DataFrame(
        {
            "FLD_1": [1, 2, 2, 3, 3, 4, 5, 5],
            "FLD_2": ["A", np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
            "FLD_3": [1, 2, 2, 3, 3, 4, 5, 5],
        }
    )
    pdf2 = pd.DataFrame(
        {
            "FLD_1": [1, 2, 3, 4, 5],
            "FLD_2": ["A", np.nan, np.nan, np.nan, np.nan],
            "FLD_3": [1, 2, 3, 4, 5],
        }
    )
    df1 = snowflake_session.createDataFrame(pdf1)
    df2 = snowflake_session.createDataFrame(pdf2)
    comp = SnowflakeCompare(
        snowflake_session, df1, df2, join_columns=["FLD_1", "FLD_2"]
    )
    assert comp.subset()


def test_dupes_with_nulls_ints(snowflake_session):
    pdf1 = pd.DataFrame(
        {
            "FLD_1": [1, 2, 2, 3, 3, 4, 5, 5],
            "FLD_2": [1, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan],
            "FLD_3": [1, 2, 2, 3, 3, 4, 5, 5],
        }
    )
    pdf2 = pd.DataFrame(
        {
            "FLD_1": [1, 2, 3, 4, 5],
            "FLD_2": [1, np.nan, np.nan, np.nan, np.nan],
            "FLD_3": [1, 2, 3, 4, 5],
        }
    )
    df1 = snowflake_session.createDataFrame(pdf1)
    df2 = snowflake_session.createDataFrame(pdf2)
    comp = SnowflakeCompare(
        snowflake_session, df1, df2, join_columns=["FLD_1", "FLD_2"]
    )
    assert comp.subset()


def test_generate_id_within_group(snowflake_session):
    matrix = [
        (
            pd.DataFrame({"A": [1, 2, 3], "B": [1, 2, 3], "__INDEX": [1, 2, 3]}),
            pd.Series([0, 0, 0]),
        ),
        (
            pd.DataFrame(
                {
                    "A": ["A", "A", "DATACOMPY_NULL"],
                    "B": [1, 1, 2],
                    "__INDEX": [1, 2, 3],
                }
            ),
            pd.Series([0, 1, 0]),
        ),
        (
            pd.DataFrame({"A": [-999, 2, 3], "B": [1, 2, 3], "__INDEX": [1, 2, 3]}),
            pd.Series([0, 0, 0]),
        ),
        (
            pd.DataFrame(
                {"A": [1, np.nan, np.nan], "B": [1, 2, 2], "__INDEX": [1, 2, 3]}
            ),
            pd.Series([0, 0, 1]),
        ),
        (
            pd.DataFrame(
                {"A": ["1", np.nan, np.nan], "B": ["1", "2", "2"], "__INDEX": [1, 2, 3]}
            ),
            pd.Series([0, 0, 1]),
        ),
        (
            pd.DataFrame(
                {
                    "A": [datetime(2018, 1, 1), np.nan, np.nan],
                    "B": ["1", "2", "2"],
                    "__INDEX": [1, 2, 3],
                }
            ),
            pd.Series([0, 0, 1]),
        ),
    ]
    for i in matrix:
        dataframe = i[0]
        expected = i[1]
        actual = (
            _generate_id_within_group(
                snowflake_session.createDataFrame(dataframe), ["A", "B"], "_TEMP_0"
            )
            .orderBy("__INDEX")
            .select("_TEMP_0")
            .toPandas()
        )
        assert (actual["_TEMP_0"] == expected).all()


def test_generate_id_within_group_single_join(snowflake_session):
    dataframe = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "__INDEX": 1}, {"A": 1, "B": 2, "__INDEX": 2}]
    )
    expected = pd.Series([0, 1])
    actual = (
        _generate_id_within_group(dataframe, ["A"], "_TEMP_0")
        .orderBy("__INDEX")
        .select("_TEMP_0")
    ).toPandas()
    assert (actual["_TEMP_0"] == expected).all()


@mock.patch("datacompy.snowflake.render")
@mock.patch("datacompy.snowflake.save_html_report")
def test_save_html(mock_save_html, mock_render, snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 2}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 2}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["A"])

    # Test without HTML file
    compare.report()
    mock_render.assert_called_once()
    mock_save_html.assert_not_called()

    mock_render.reset_mock()
    mock_save_html.reset_mock()

    # Test with HTML file
    compare.report(html_file="test.html")
    mock_render.assert_called_once()
    mock_save_html.assert_called_once()
    args, _ = mock_save_html.call_args
    assert len(args) == 2
    assert args[1] == "test.html"  # The filename


def test_full_join_counts_no_matches(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 3}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 4}, {"A": 1, "B": 5}])
    compare = SnowflakeCompare(
        snowflake_session, df1, df2, ["A", "B"], ignore_spaces=False
    )
    assert not compare.matches()
    assert compare.all_columns_match()
    assert not compare.all_rows_overlap()
    assert not compare.intersect_rows_match()
    assert compare.count_matching_rows() == 0
    assert_frame_equal(
        compare.sample_mismatch(column="A")
        .toPandas()
        .sort_values("A")
        .reset_index(drop=True),
        pd.DataFrame([{"A": 1}, {"A": 1}, {"A": 1}, {"A": 1}]),
    )
    assert_frame_equal(
        compare.sample_mismatch(column="B")
        .toPandas()
        .sort_values("B")
        .reset_index(drop=True),
        pd.DataFrame([{"B": 2}, {"B": 3}, {"B": 4}, {"B": 5}]),
    )
    assert_frame_equal(
        compare.all_mismatch()
        .toPandas()
        .sort_values(["A", "B"])
        .reset_index(drop=True),
        pd.DataFrame(
            [{"A": 1, "B": 2}, {"A": 1, "B": 3}, {"A": 1, "B": 4}, {"A": 1, "B": 5}]
        ),
    )


def test_full_join_counts_some_matches(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 3}])
    df2 = snowflake_session.createDataFrame([{"A": 1, "B": 2}, {"A": 1, "B": 5}])
    compare = SnowflakeCompare(
        snowflake_session, df1, df2, ["A", "B"], ignore_spaces=False
    )
    assert not compare.matches()
    assert compare.all_columns_match()
    assert not compare.all_rows_overlap()
    assert compare.intersect_rows_match()
    assert compare.count_matching_rows() == 1
    assert_frame_equal(
        compare.sample_mismatch(column="A")
        .toPandas()
        .sort_values("A")
        .reset_index(drop=True),
        pd.DataFrame([{"A": 1}, {"A": 1}]),
    )
    assert_frame_equal(
        compare.sample_mismatch(column="B")
        .toPandas()
        .sort_values("B")
        .reset_index(drop=True),
        pd.DataFrame([{"B": 3}, {"B": 5}]),
    )
    assert_frame_equal(
        compare.all_mismatch()
        .toPandas()
        .sort_values(["A", "B"])
        .reset_index(drop=True),
        pd.DataFrame(
            [
                {"A": 1, "B": 3},
                {"A": 1, "B": 5},
            ]
        ),
    )


def test_non_full_join_counts_no_matches(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "C": 4}, {"A": 1, "B": 3, "C": 4}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 4, "D": 5}, {"A": 1, "B": 5, "D": 5}]
    )
    compare = SnowflakeCompare(
        snowflake_session, df1, df2, ["A", "B"], ignore_spaces=False
    )
    assert not compare.matches()
    assert not compare.all_columns_match()
    assert not compare.all_rows_overlap()
    assert not compare.intersect_rows_match()
    assert compare.count_matching_rows() == 0
    assert_frame_equal(
        compare.sample_mismatch(column="A")
        .toPandas()
        .sort_values("A")
        .reset_index(drop=True),
        pd.DataFrame(
            [{"A": 1}, {"A": 1}, {"A": 1}, {"A": 1}],
        ),
    )
    assert_frame_equal(
        compare.sample_mismatch(column="B")
        .toPandas()
        .sort_values("B")
        .reset_index(drop=True),
        pd.DataFrame([{"B": 2}, {"B": 3}, {"B": 4}, {"B": 5}]),
    )
    assert_frame_equal(
        compare.all_mismatch()
        .toPandas()
        .sort_values(["A", "B"])
        .reset_index(drop=True),
        pd.DataFrame(
            [
                {"A": 1, "B": 2},
                {"A": 1, "B": 3},
                {"A": 1, "B": 4},
                {"A": 1, "B": 5},
            ]
        ),
    )


def test_non_full_join_counts_some_matches(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "C": 4}, {"A": 1, "B": 3, "C": 4}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"A": 1, "B": 2, "D": 5}, {"A": 1, "B": 5, "D": 5}]
    )
    compare = SnowflakeCompare(
        snowflake_session, df1, df2, ["A", "B"], ignore_spaces=False
    )
    assert not compare.matches()
    assert not compare.all_columns_match()
    assert not compare.all_rows_overlap()
    assert compare.intersect_rows_match()
    assert compare.count_matching_rows() == 1
    assert_frame_equal(
        compare.sample_mismatch(column="A")
        .toPandas()
        .sort_values("A")
        .reset_index(drop=True),
        pd.DataFrame([{"A": 1}, {"A": 1}]),
    )
    assert_frame_equal(
        compare.sample_mismatch(column="B")
        .toPandas()
        .sort_values("B")
        .reset_index(drop=True),
        pd.DataFrame([{"B": 3}, {"B": 5}]),
    )
    assert_frame_equal(
        compare.all_mismatch()
        .toPandas()
        .sort_values(["A", "B"])
        .reset_index(drop=True),
        pd.DataFrame(
            [
                {"A": 1, "B": 3},
                {"A": 1, "B": 5},
            ]
        ),
    )


def test_custom_template_usage(snowflake_session):
    """Test using a custom template with template_path parameter."""
    df1 = snowflake_session.createDataFrame([("a", 1), ("b", 2)], ["id", "value"])
    df2 = snowflake_session.createDataFrame([("a", 1), ("b", 3)], ["id", "value"])
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["id"])

    # Create a simple test template
    with tempfile.NamedTemporaryFile(suffix=".j2", delete=False, mode="w") as tmp:
        tmp.write("Custom Template\n")
        tmp.write(
            "Columns: {{ mismatch_stats.stats|map(attribute='column')|join(', ') if mismatch_stats.has_mismatches else '' }}\n"
        )
        tmp.write(
            "Matches: "
            "{% if mismatch_stats.has_mismatches %}"
            "{% for col in mismatch_stats.stats %}"
            "{% if col.unequal_cnt > 0 %}False{% else %}True{% endif %}"
            "{% endfor %}"
            "{% else %}All match{% endif %}"
        )
        template_path = tmp.name

    try:
        # Test with custom template
        result = compare.report(template_path=template_path)
        assert "Custom Template" in result
        # Should list the column with mismatches (value)
        assert "VALUE" in result
        # Should show False for column value (has mismatches)
        assert "False" in result
    finally:
        # Clean up the temporary file
        if os.path.exists(template_path):
            os.unlink(template_path)


def test_template_without_extension(snowflake_session):
    """Test that template_path works without .j2 extension."""
    df1 = snowflake_session.createDataFrame([("a", 1), ("b", 2)], ["id", "value"])
    df2 = snowflake_session.createDataFrame([("a", 1), ("b", 3)], ["id", "value"])
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["id"])

    # Create a test template without .j2 extension
    with tempfile.NamedTemporaryFile(delete=False, mode="w") as tmp:
        tmp.write("Test Template")
        template_path = tmp.name

    try:
        result = compare.report(template_path=template_path)
        assert "Test Template" in result
    finally:
        if os.path.exists(template_path):
            os.unlink(template_path)


def test_nonexistent_template(snowflake_session):
    """Test that a clear error is raised when template file doesn't exist."""
    df1 = snowflake_session.createDataFrame([("a", 1), ("b", 2)], ["id", "value"])
    df2 = snowflake_session.createDataFrame([("a", 1), ("b", 3)], ["id", "value"])
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["id"])

    with pytest.raises(Exception) as exc_info:
        compare.report(template_path="nonexistent_template.j2")
    # Check that the error message is helpful
    assert "Template not found" in str(
        exc_info.value
    ) or "nonexistent_template.j2" in str(exc_info.value)


def test_template_context_variables(snowflake_session):
    """Test that all expected context variables are available in the template."""
    df1 = snowflake_session.createDataFrame([("a", 1), ("b", 2)], ["id", "value"])
    df2 = snowflake_session.createDataFrame([("a", 1), ("b", 3)], ["id", "value"])
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["id"])

    # Create a test template that checks for expected variables
    with tempfile.NamedTemporaryFile(suffix=".j2", delete=False, mode="w") as tmp:
        tmp.write(
            "{% if mismatch_stats is defined and df1_name is defined and df2_name is defined %}"
        )
        tmp.write("All required variables present\n")
        tmp.write("{% else %}")
        tmp.write("Missing required variables\n")
        tmp.write("{% endif %}")
        tmp.write(
            "Columns: {{ mismatch_stats.stats|map(attribute='column')|join(', ') if mismatch_stats.has_mismatches else '' }}"
        )
        template_path = tmp.name

    try:
        result = compare.report(template_path=template_path)
        assert "All required variables present" in result
        # Should list the column with mismatches (value)
        assert "VALUE" in result
    finally:
        if os.path.exists(template_path):
            os.unlink(template_path)


@mock.patch("datacompy.snowflake.save_html_report")
@mock.patch("datacompy.snowflake.render")
def test_html_report_generation(mock_render, mock_save_html, snowflake_session):
    """Test that HTML reports can be generated and saved to a file."""
    df1 = snowflake_session.createDataFrame([("a", 1), ("b", 2)], ["id", "value"])
    df2 = snowflake_session.createDataFrame([("a", 1), ("b", 3)], ["id", "value"])
    compare = SnowflakeCompare(snowflake_session, df1, df2, ["id"])

    # Mock the render function to return a test string
    mock_render.return_value = "<html><body>Test Report</body></html>"

    # Create a temporary file for the HTML output
    with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as tmp:
        html_file = tmp.name

    try:
        # Call report with html_file parameter
        result = compare.report(html_file=html_file)

        # Check that save_html_report was called with the correct arguments
        mock_save_html.assert_called_once_with(
            "<html><body>Test Report</body></html>", html_file
        )
        # Check that the result is the rendered template
        assert result == "<html><body>Test Report</body></html>"
    finally:
        # Clean up the temporary file
        if os.path.exists(html_file):
            os.unlink(html_file)


def test_custom_comparator_snowflake(snowflake_session):
    """Test that a custom comparator can be passed and used with Snowflake."""

    class StringLengthComparator(BaseComparator):
        """A custom comparator that matches strings based on length."""

        def compare(self, dataframe, col1, col2, col_match):
            base_dtype, compare_dtype = get_snowflake_column_dtypes(
                dataframe, col1, col2
            )
            base_string_type = any(
                base_dtype.startswith(t) for t in SNOWFLAKE_STRING_TYPE
            )
            compare_string_type = any(
                compare_dtype.startswith(t) for t in SNOWFLAKE_STRING_TYPE
            )
            if base_string_type and compare_string_type:
                return dataframe.withColumn(
                    col_match,
                    when(length(col(col1)) == length(col(col2)), lit(True)).otherwise(
                        lit(False)
                    ),
                )
            return None

    df1 = snowflake_session.createDataFrame([(1, "apple")], ["id", "value"])
    df2 = snowflake_session.createDataFrame([(1, "grape")], ["id", "value"])

    # With custom comparator, it should match because 'apple' and 'grape' have the same length
    compare_custom = SnowflakeCompare(
        snowflake_session,
        df1,
        df2,
        join_columns=["id"],
        custom_comparators=[StringLengthComparator()],
    )
    assert compare_custom.matches()

    # Without custom comparator, it should not match
    compare_default = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["id"])
    assert not compare_default.matches()

    # Test case where custom comparator does not apply (returns None)
    # and default comparison should be used.
    df3 = snowflake_session.createDataFrame([(1, 10)], ["id", "value"])
    df4 = snowflake_session.createDataFrame([(1, 20)], ["id", "value"])

    # With custom comparator, but it won't apply to integer 'value' column
    # so default comparison for integers should kick in, resulting in a mismatch.
    compare_custom_fallback = SnowflakeCompare(
        snowflake_session,
        df3,
        df4,
        join_columns=["id"],
        custom_comparators=[StringLengthComparator()],
    )
    assert not compare_custom_fallback.matches()

    # Test case where custom comparator does not apply (returns None)
    # and default comparison should be used.
    df5 = snowflake_session.createDataFrame([(1, 10)], ["id", "value"])
    df6 = snowflake_session.createDataFrame([(1, 10)], ["id", "value"])

    # With custom comparator, but it won't apply to integer 'value' column
    # so default comparison for integers should kick in, resulting in a match.
    compare_custom_fallback = SnowflakeCompare(
        snowflake_session,
        df5,
        df6,
        join_columns=["id"],
        custom_comparators=[StringLengthComparator()],
    )
    assert compare_custom_fallback.matches()

    # Ensure the StringLengthComparator is actually used for string columns
    df7 = snowflake_session.createDataFrame([(1, "test")], ["id", "value"])
    df8 = snowflake_session.createDataFrame([(1, "abcd")], ["id", "value"])

    compare_string_custom = SnowflakeCompare(
        snowflake_session,
        df7,
        df8,
        join_columns=["id"],
        custom_comparators=[StringLengthComparator()],
    )
    assert compare_string_custom.matches()

    compare_string_default = SnowflakeCompare(
        snowflake_session, df7, df8, join_columns=["id"]
    )
    assert not compare_string_default.matches()

    # StringLengthComparator mismatch case
    df9 = snowflake_session.createDataFrame([(1, "test")], ["id", "value"])
    df10 = snowflake_session.createDataFrame([(1, "abcde")], ["id", "value"])

    compare_string_custom_mismatch = SnowflakeCompare(
        snowflake_session,
        df9,
        df10,
        join_columns=["id"],
        custom_comparators=[StringLengthComparator()],
    )
    assert not compare_string_custom_mismatch.matches()


def test_array_comparator_snowflake(snowflake_session):
    schema = StructType(
        [
            StructField("id", IntegerType(), True),
            StructField("array_col", ArrayType(IntegerType()), True),
        ]
    )
    data1 = [
        (1, [1, 2, 3]),
        (2, [4, 5, 6]),
        (3, [7, 8, 9]),
        (5, [1, 2, 3]),
        (6, [1, 2]),
        (7, None),
        (8, [1, None]),
    ]
    df1 = snowflake_session.createDataFrame(data1, schema)
    data2 = [
        (1, [1, 2, 3]),
        (2, [4, 5, 7]),
        (4, [10, 11, 12]),
        (5, [3, 2, 1]),
        (6, [1, 2, 3]),
        (7, None),
        (8, [1, None]),
    ]
    df2 = snowflake_session.createDataFrame(data2, schema)
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["id"])
    assert not compare.matches()
    assert compare.df1_unq_rows.count() == 1
    assert compare.df1_unq_rows.toPandas()["ID_DF1"].iloc[0] == 3
    assert compare.df2_unq_rows.count() == 1
    assert compare.df2_unq_rows.toPandas()["ID_DF2"].iloc[0] == 4
    assert compare.intersect_rows.count() == 6
    assert not compare.intersect_rows_match()
    assert compare.count_matching_rows() == 3
    mismatch_df = (
        compare.all_mismatch().toPandas().sort_values("ID").reset_index(drop=True)
    )
    assert len(mismatch_df) == 3
    assert mismatch_df["ID"].iloc[0] == 2
    assert mismatch_df["ARRAY_COL_DF1"].iloc[0] == "[\n  4,\n  5,\n  6\n]"
    assert mismatch_df["ARRAY_COL_DF2"].iloc[0] == "[\n  4,\n  5,\n  7\n]"
    assert mismatch_df["ID"].iloc[1] == 5
    assert mismatch_df["ARRAY_COL_DF1"].iloc[1] == "[\n  1,\n  2,\n  3\n]"
    assert mismatch_df["ARRAY_COL_DF2"].iloc[1] == "[\n  3,\n  2,\n  1\n]"
    assert mismatch_df["ID"].iloc[2] == 6
    assert mismatch_df["ARRAY_COL_DF1"].iloc[2] == "[\n  1,\n  2\n]"
    assert mismatch_df["ARRAY_COL_DF2"].iloc[2] == "[\n  1,\n  2,\n  3\n]"


def test_columns_with_mismatches_single_column(snowflake_session):
    """Test columns_with_mismatches with a single mismatched column."""
    df1 = snowflake_session.createDataFrame(
        [(1, "Alice", 25), (2, "Bob", 30), (3, "Charlie", 35)], ["ID", "NAME", "AGE"]
    )
    df2 = snowflake_session.createDataFrame(
        [
            (1, "Alice", 25),
            (2, "Bob", 31),  # age differs for id=2
            (3, "Charlie", 35),
        ],
        ["ID", "NAME", "AGE"],
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["ID"])
    result = compare.columns_with_mismatches()
    assert result == ["AGE"]


def test_columns_with_mismatches_multiple_columns(snowflake_session):
    """Test columns_with_mismatches with multiple mismatched columns."""
    df1 = snowflake_session.createDataFrame(
        [(1, "Alice", 25, "NYC"), (2, "Bob", 30, "LA"), (3, "Charlie", 35, "Chicago")],
        ["ID", "NAME", "AGE", "CITY"],
    )
    df2 = snowflake_session.createDataFrame(
        [
            (1, "Alice", 25, "NYC"),
            (2, "Bob", 31, "LA"),  # age differs for id=2
            (3, "Charlie", 35, "Boston"),  # city differs for id=3
        ],
        ["ID", "NAME", "AGE", "CITY"],
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["ID"])
    result = compare.columns_with_mismatches()
    assert sorted(result) == ["AGE", "CITY"]


def test_columns_with_mismatches_no_mismatches(snowflake_session):
    """Test columns_with_mismatches when all columns match."""
    df1 = snowflake_session.createDataFrame(
        [(1, "Alice", 25), (2, "Bob", 30), (3, "Charlie", 35)], ["ID", "NAME", "AGE"]
    )
    df2 = snowflake_session.createDataFrame(
        [(1, "Alice", 25), (2, "Bob", 30), (3, "Charlie", 35)], ["ID", "NAME", "AGE"]
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["ID"])
    result = compare.columns_with_mismatches()
    assert result == []


def test_columns_with_mismatches_excludes_join_columns(snowflake_session):
    """Test that join columns are excluded from the result."""
    df1 = snowflake_session.createDataFrame(
        [(1, "a"), (2, "b"), (3, "c")], ["ID", "VALUE"]
    )
    df2 = snowflake_session.createDataFrame(
        [
            (1, "a"),
            (2, "b"),
            (4, "d"),  # id=3 missing, id=4 added
        ],
        ["ID", "VALUE"],
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["ID"])
    result = compare.columns_with_mismatches()
    # 'ID' should not be in the result even though there are row mismatches
    assert "ID" not in result
    # Result should be empty because 'VALUE' matches for the intersecting rows
    assert result == []


def test_columns_with_mismatches_with_nulls(snowflake_session):
    """Test columns_with_mismatches with null values."""
    df1 = snowflake_session.createDataFrame(
        [(1, "a"), (2, None), (3, "c")], ["ID", "VALUE"]
    )
    df2 = snowflake_session.createDataFrame(
        [
            (1, "a"),
            (2, "b"),  # null differs to 'b' for id=2
            (3, "c"),
        ],
        ["ID", "VALUE"],
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["ID"])
    result = compare.columns_with_mismatches()
    assert result == ["VALUE"]


def test_columns_with_mismatches_multiple_join_columns(snowflake_session):
    """Test columns_with_mismatches with multiple join columns."""
    df1 = snowflake_session.createDataFrame(
        [(1, "a", 10, 100), (1, "b", 20, 200), (2, "a", 30, 300), (2, "b", 40, 400)],
        ["ID1", "ID2", "VALUE1", "VALUE2"],
    )
    df2 = snowflake_session.createDataFrame(
        [
            (1, "a", 10, 100),
            (1, "b", 25, 200),  # value1 differs for (1, 'b')
            (2, "a", 30, 305),  # value2 differs for (2, 'a')
            (2, "b", 40, 400),
        ],
        ["ID1", "ID2", "VALUE1", "VALUE2"],
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["ID1", "ID2"])
    result = compare.columns_with_mismatches()
    assert "ID1" not in result
    assert "ID2" not in result
    assert sorted(result) == ["VALUE1", "VALUE2"]


def test_sensitive_columns_hide(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["b"])

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "B"] == 2
    assert compare.df1.toPandas().loc[1, "B"] == 0
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 1
    assert df1_unq_rows.loc[0, "B_DF1"] == "*******"
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "A_DF2"] == 2
    assert df2_unq_rows.loc[0, "B_DF2"] == "*******"
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "A_DF1"] == 1
    assert intersect_rows.loc[0, "B_DF1"] == "*******"
    assert intersect_rows.loc[0, "B_DF2"] == "*******"
    assert intersect_rows.loc[0, "B_MATCH"]
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_hide_hide(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["b"])

    with pytest.raises(
        ValueError,
        match=re.escape(
            "sensitive columns are already hidden, call reveal_sensitive_columns() first"
        ),
    ):
        compare.hide_sensitive_columns(["c"])


def test_sensitive_columns_hide_reveal(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["b"])
    compare.reveal_sensitive_columns()

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "B"] == 2
    assert compare.df1.toPandas().loc[1, "B"] == 0
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 1
    assert df1_unq_rows.loc[0, "B_DF1"] == 0
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "A_DF2"] == 2
    assert df2_unq_rows.loc[0, "B_DF2"] == 0
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "A_DF1"] == 1
    assert intersect_rows.loc[0, "B_DF1"] == 2
    assert intersect_rows.loc[0, "B_DF2"] == 2
    assert intersect_rows.loc[0, "B_MATCH"]
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_hide_reveal_hide(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["b"])
    compare.reveal_sensitive_columns()
    compare.hide_sensitive_columns(["b"])

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "B"] == 2
    assert compare.df1.toPandas().loc[1, "B"] == 0
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 1
    assert df1_unq_rows.loc[0, "B_DF1"] == "*******"
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "A_DF2"] == 2
    assert df2_unq_rows.loc[0, "B_DF2"] == "*******"
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "A_DF1"] == 1
    assert intersect_rows.loc[0, "B_DF1"] == "*******"
    assert intersect_rows.loc[0, "B_DF2"] == "*******"
    assert intersect_rows.loc[0, "B_MATCH"]
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_case_insensitive(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["B"])

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "B"] == 2
    assert compare.df1.toPandas().loc[1, "B"] == 0
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 1
    assert df1_unq_rows.loc[0, "B_DF1"] == "*******"
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "A_DF2"] == 2
    assert df2_unq_rows.loc[0, "B_DF2"] == "*******"
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "A_DF1"] == 1
    assert intersect_rows.loc[0, "B_DF1"] == "*******"
    assert intersect_rows.loc[0, "B_DF2"] == "*******"
    assert intersect_rows.loc[0, "B_MATCH"]
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_hide_join_columns(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["a"])

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    sample_mismatch = compare.sample_mismatch("a").toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "A"] == 1
    assert compare.df1.toPandas().loc[1, "A"] == 1
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == "*******"
    assert len(sample_mismatch) == 2
    assert sample_mismatch.loc[0, "A"] == "*******"
    assert sample_mismatch.loc[1, "A"] == "*******"
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_hide_reveal_join_columns(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["a"])
    compare.reveal_sensitive_columns()

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    sample_mismatch = compare.sample_mismatch("a").toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "A"] == 1
    assert compare.df1.toPandas().loc[1, "A"] == 1
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 1
    assert len(sample_mismatch) == 2
    assert sample_mismatch.sort_values("A").reset_index(drop=True).loc[0, "A"] == 1
    assert sample_mismatch.sort_values("A").reset_index(drop=True).loc[1, "A"] == 2
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_missing(snowflake_session):
    df1 = snowflake_session.createDataFrame(
        [{"a": 1, "b": "bruh", "c": 3}, {"a": 3, "b": "67", "c": 6}]
    )
    df2 = snowflake_session.createDataFrame(
        [{"a": 1, "b": "hello", "d": 4}, {"a": 2, "b": "yo", "d": 7}]
    )
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["b", "c"])

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "B"] == "bruh"
    assert compare.df1.toPandas().loc[1, "B"] == "67"
    assert compare.df1.toPandas().loc[0, "C"] == 3
    assert compare.df1.toPandas().loc[1, "C"] == 6
    assert compare.df2.toPandas().loc[0, "D"] == 4
    assert compare.df2.toPandas().loc[1, "D"] == 7
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 3
    assert df1_unq_rows.loc[0, "B_DF1"] == "*******"
    assert df1_unq_rows.loc[0, "C_DF1"] == "*******"
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "A_DF2"] == 2
    assert df2_unq_rows.loc[0, "B_DF2"] == "*******"
    assert df2_unq_rows.loc[0, "D_DF2"] == 7
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "B_DF1"] == "*******"
    assert intersect_rows.loc[0, "B_DF2"] == "*******"
    assert intersect_rows.loc[0, "C_DF1"] == "*******"
    assert not intersect_rows.loc[0, "B_MATCH"]
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_unused(snowflake_session, caplog):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    with caplog.at_level(logging.WARNING):
        compare.hide_sensitive_columns(["c"])
        assert (
            "sensitive columns not found in either df1 or df2 will be ignored: ['C']"
            in caplog.text
        )

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "B"] == 2
    assert compare.df1.toPandas().loc[1, "B"] == 0
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 1
    assert df1_unq_rows.loc[0, "B_DF1"] == 0
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "A_DF2"] == 2
    assert df2_unq_rows.loc[0, "B_DF2"] == 0
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "A_DF1"] == 1
    assert intersect_rows.loc[0, "B_DF1"] == 2
    assert intersect_rows.loc[0, "B_DF2"] == 2
    assert intersect_rows.loc[0, "B_MATCH"]
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_hide_reveal_empty(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns([])
    compare.reveal_sensitive_columns()

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "B"] == 2
    assert compare.df1.toPandas().loc[1, "B"] == 0
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 1
    assert df1_unq_rows.loc[0, "B_DF1"] == 0
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "A_DF2"] == 2
    assert df2_unq_rows.loc[0, "B_DF2"] == 0
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "A_DF1"] == 1
    assert intersect_rows.loc[0, "B_DF1"] == 2
    assert intersect_rows.loc[0, "B_DF2"] == 2
    assert intersect_rows.loc[0, "B_MATCH"]
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_hide_empty(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 1, "b": 0}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}, {"a": 2, "b": 0}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns([])

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert compare.df1.toPandas().loc[0, "B"] == 2
    assert compare.df1.toPandas().loc[1, "B"] == 0
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "A_DF1"] == 1
    assert df1_unq_rows.loc[0, "B_DF1"] == 0
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "A_DF2"] == 2
    assert df2_unq_rows.loc[0, "B_DF2"] == 0
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "A_DF1"] == 1
    assert intersect_rows.loc[0, "B_DF1"] == 2
    assert intersect_rows.loc[0, "B_DF2"] == 2
    assert intersect_rows.loc[0, "B_MATCH"]
    # Just render the report to make sure it renders.
    compare.report()


def test_sensitive_columns_setter(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}])
    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])

    # Valid setter call
    compare._set_and_validate_sensitive_columns(["b"])
    assert compare.sensitive_columns == ["B"]

    # Invalid setter call - not a list of strings
    with pytest.raises(TypeError, match="sensitive_columns must be a list of strings"):
        compare._set_and_validate_sensitive_columns([1, 2, 3])


def test_sensitive_columns_duplicates(snowflake_session):
    df1 = snowflake_session.createDataFrame([{"a": 1, "b": 2}])
    df2 = snowflake_session.createDataFrame([{"a": 1, "b": 2}])

    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    # Duplicate columns should raise ValueError during hide_sensitive_columns()
    with pytest.raises(ValueError, match=r"duplicate columns: {'B'}"):
        compare.hide_sensitive_columns(["B", "b"])


def test_sensitive_columns_numeric_types(snowflake_session):
    """Verify that hiding works for different numeric types without LossySetitemError."""
    df1 = snowflake_session.createDataFrame(
        [
            {"a": 1, "b": 10, "c": 1.1},
            {"a": 2, "b": 20, "c": 2.2},
        ]
    )
    df2 = snowflake_session.createDataFrame(
        [
            {"a": 1, "b": 10, "c": 1.1},
            {"a": 2, "b": 20, "c": 2.2},
        ]
    )

    compare = SnowflakeCompare(snowflake_session, df1, df2, join_columns=["a"])
    compare.hide_sensitive_columns(["b", "c"])

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert not isinstance(compare.df1.toPandas()["B"].loc[0], str)
    assert not isinstance(compare.df1.toPandas()["C"].loc[0], str)
    assert len(df1_unq_rows) == 0
    assert intersect_rows.loc[0, "B_DF1"] == "*******"
    assert intersect_rows.loc[0, "B_DF2"] == "*******"
    assert intersect_rows.loc[0, "C_DF1"] == "*******"
    assert intersect_rows.loc[0, "C_DF2"] == "*******"


def test_sensitive_columns_numeric_types_with_tolerance(snowflake_session):
    """Verify that hiding works for different numeric types with tolerance."""
    df1 = snowflake_session.createDataFrame(
        [
            {"a": 1, "b": 10, "c": 1.1},
            {"a": 2, "b": 20, "c": 2.1},
        ]
    )
    df2 = snowflake_session.createDataFrame(
        [
            {"a": 1, "b": 10, "c": 1.2},
            {"a": 3, "b": 21, "c": 2.1},
        ]
    )

    compare = SnowflakeCompare(
        snowflake_session, df1, df2, join_columns=["a"], abs_tol=0.1
    )
    compare.hide_sensitive_columns(["b", "c"])

    df1_unq_rows = compare.df1_unq_rows.toPandas().reset_index(drop=True)
    df2_unq_rows = compare.df2_unq_rows.toPandas().reset_index(drop=True)
    intersect_rows = compare.intersect_rows.toPandas().reset_index(drop=True)

    assert not isinstance(compare.df1.toPandas()["B"].loc[0], str)
    assert not isinstance(compare.df1.toPandas()["C"].loc[0], str)
    assert len(df1_unq_rows) == 1
    assert df1_unq_rows.loc[0, "B_DF1"] == "*******"
    assert df1_unq_rows.loc[0, "C_DF1"] == "*******"
    assert len(df2_unq_rows) == 1
    assert df2_unq_rows.loc[0, "B_DF2"] == "*******"
    assert df2_unq_rows.loc[0, "C_DF2"] == "*******"
    assert len(intersect_rows) == 1
    assert intersect_rows.loc[0, "B_DF1"] == "*******"
    assert intersect_rows.loc[0, "B_DF2"] == "*******"
    assert intersect_rows.loc[0, "B_MATCH"]
    assert intersect_rows.loc[0, "C_DF1"] == "*******"
    assert intersect_rows.loc[0, "C_DF2"] == "*******"
    assert intersect_rows.loc[0, "C_MATCH"]
