import json
import logging
import os
import time

import logistro


def write_to_pipe(caplog, pipe, message, human):
    termed_message = message + "\n"
    os.write(pipe, termed_message.encode("utf-8"))
    time.sleep(0.5)
    if human:
        assert message in caplog.text
    else:
        obj = json.loads(caplog.text)
        assert obj["message"] == message
    caplog.clear()


def write_to_logger(caplog, logger, level, message, human):
    logger.log(level, message)
    level_name = logging.getLevelName(level)
    if human:
        assert level_name in caplog.text
        assert message in caplog.text
    else:
        obj = json.loads(caplog.text)
        assert obj["level"] == level_name
        assert obj["message"] == message
    caplog.clear()


def test_human_logs(caplog):
    logistro.set_human()
    human = logistro.getLogger("human")
    human.setLevel(logistro.DEBUG2)
    write_to_logger(caplog, human, logistro.DEBUG2, "d2-message", True)

    w, pipelogger = logistro.getPipeLogger("pipe1")
    pipelogger.setLevel(logistro.DEBUG2)
    try:
        write_to_pipe(caplog, w, "d2-message", True)
    finally:
        os.close(w)


def test_structured_logs(caplog):
    logistro.set_structured()
    logistro.coerce_logger(logistro.getLogger())
    structured = logistro.getLogger("structured")
    structured.setLevel(logistro.DEBUG2)
    # write_to_logger(caplog, structured, logistro.DEBUG2, "d2-message", False)

    w, pipelogger = logistro.getPipeLogger("pipe2")
    pipelogger.setLevel(logistro.DEBUG2)
    try:
        write_to_pipe(caplog, w, "d2-message", False)
    finally:
        os.close(w)
