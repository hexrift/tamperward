"""Sample module with only module-level imports."""

import json
import pathlib
import re


def load(path):
    data = pathlib.Path(path).read_text()
    return json.loads(data)


def find_all(pattern, text):
    return re.findall(pattern, text)
