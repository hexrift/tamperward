"""Sample module with imports nested inside function bodies."""


def load(path):
    import json
    import pathlib
    data = pathlib.Path(path).read_text()
    return json.loads(data)


def find_all(pattern, text):
    import re
    return re.findall(pattern, text)
