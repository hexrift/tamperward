# fmt: off
from .loader import load, loads, scan_file, scan_zip_archive, ScanResult  # noqa
from .context import check_safety #noqa
from .hook import always_check_safety, activate_safe_ml_environment #noqa
from .analysis import is_likely_safe # noqa
from .constants import EXIT_CLEAN, EXIT_UNSAFE, EXIT_ERROR  # noqa - ClamAV-compatible exit codes
# fmt: on

# The above lines enables `fickling.load()`, `fickling.loads()` and `with fickling.check_safety()`
# The comments are necessary to comply with linters
__version__ = "0.1.12"
