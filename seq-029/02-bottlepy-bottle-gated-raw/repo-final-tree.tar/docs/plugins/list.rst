.. currentmodule:: bottle

=========================
3rd Party Plugins
=========================

This is a list of third-party plugins that add extend Bottles core functionality or integrate other libraries with the Bottle framework.

Have a look at :ref:`plugins` for general questions about plugins (installation, usage). If you plan to develop a new plugin, the :ref:`plugindev` may help you.

`Bottle-Beaker <https://pypi.python.org/pypi/bottle-beaker/>`_
    Beaker to session and caching library with WSGI Middleware

`Bottle-Cork <https://pypi.org/project/bottle-cork/>`_
	Cork provides a simple set of methods to implement Authentication and Authorization in web applications based on Bottle.

`Bottle-Cors-plugin <https://pypi.org/project/bottle-cors-plugin/>`_
	Cors-plugin is the easiest way to implement cors on your bottle web application

`Bottle-Extras <https://pypi.python.org/pypi/bottle-extras/>`_
	Meta package to install the bottle plugin collection.

`Bottle-Flash <https://pypi.python.org/pypi/bottle-flash/>`_
	flash plugin for bottle

`Bottle-Hotqueue <https://pypi.python.org/pypi/bottle-hotqueue/>`_
	FIFO Queue for Bottle built upon redis

`Macaron <https://nobrin.github.com/macaron/webapp.html>`_
	Macaron is an object-relational mapper (ORM) for SQLite.

`Bottle-Memcache <https://pypi.python.org/pypi/bottle-memcache/>`_
	Memcache integration for Bottle.

`Bottle-Mongo <https://pypi.python.org/pypi/bottle-mongo/>`_
	MongoDB integration for Bottle

`Bottle-OAuthlib <https://pypi.python.org/pypi/bottle-oauthlib/>`_
	Adapter for oauthlib - create your own OAuth2.0 implementation

`Bottle-Redis <https://pypi.python.org/pypi/bottle-redis/>`_
	Redis integration for Bottle.

`Bottle-Renderer <https://pypi.python.org/pypi/bottle-renderer/>`_
	Renderer plugin for bottle

`Bottle-Servefiles <https://pypi.python.org/pypi/bottle-servefiles/>`_
	A reusable app that serves static files for bottle apps

`Bottle-Sqlalchemy <https://pypi.python.org/pypi/bottle-sqlalchemy/>`_
	SQLAlchemy integration for Bottle.

`Bottle-Sqlite <https://pypi.python.org/pypi/bottle-sqlite/>`_
	SQLite3 database integration for Bottle.

`Bottle-Web2pydal <https://pypi.python.org/pypi/bottle-web2pydal/>`_
	Web2py Dal integration for Bottle.

`Bottle-Werkzeug <https://pypi.python.org/pypi/bottle-werkzeug/>`_
	Integrates the `werkzeug` library (alternative request and response objects, advanced debugging middleware and more).

`bottle-smart-filters <https://github.com/agile4you/bottle-smart-filters/>`_
	Bottle Querystring smart guessing.

`bottle-jwt <https://github.com/agile4you/bottle-jwt/>`_
	JSON Web Token authentication plugin for bottle.py

`bottlejwt <https://github.com/agalera/bottlejwt>`_
	JWT integration for bottle

`canister <https://github.com/dagnelies/canister>`_
	a bottle wrapper to provide logging, sessions and authentication

`bottle-cerberus <https://github.com/agalera/bottle-cerberus>`_
	Cerberus integration for bottle

`Bottle-errorsrest <https://github.com/agalera/bottle-errorsrest>`_
	All errors generated from bottle are returned in json

`Bottle-tools <https://github.com/theSage21/bottle-tools>`_
	Decorators that auto-supply function arguments using POST/query string data.


Plugins listed here are not part of Bottle or the Bottle project, but developed and maintained by third parties.
