"""
Pure Python BM25 implementation fallback when bm25s is not available.

This is a simplified, pure-Python implementation that:
1. Limits search to latest 10 conversations (performance optimization)
2. Uses basic Porter stemming approximation
3. Includes English stopword filtering
4. Implements standard BM25 ranking algorithm

Install the full version with: pip install tom-swe[search]
"""

import math
import re
from collections import Counter
from typing import Dict, List, Optional, Set, Tuple

STOPWORDS: Set[str] = {
    "a", "an", "and", "are", "as", "at", "be", "by", "for", "from",
    "has", "he", "in", "is", "it", "its", "of", "on", "that", "the",
    "to", "was", "were", "will", "with", "this", "but", "they", "have",
    "had", "what", "when", "where", "who", "which", "why", "how",
    "or", "not", "no", "do", "does", "did", "can", "could", "should",
    "would", "i", "you", "your", "we", "our", "their", "them", "he",
    "she", "his", "her", "if", "than", "then", "there", "these",
    "those", "so", "such", "into", "about", "over", "under",
}


class SimpleStemmer:
    """A very small Porter-stemmer approximation covering common English suffixes."""

    _SUFFIXES: List[Tuple[str, str]] = [
        ("ational", "ate"),
        ("ization", "ize"),
        ("fulness", "ful"),
        ("ousness", "ous"),
        ("iveness", "ive"),
        ("ing", ""),
        ("edly", ""),
        ("ies", "y"),
        ("ed", ""),
        ("es", ""),
        ("s", ""),
    ]

    def stem(self, word: str) -> str:
        if len(word) <= 3:
            return word

        for suffix, replacement in self._SUFFIXES:
            if word.endswith(suffix) and len(word) - len(suffix) >= 2:
                stem = word[: -len(suffix)] + replacement
                return stem

        return word


def tokenize(
    text: str,
    remove_stopwords: bool = True,
    stemmer: Optional[SimpleStemmer] = None,
) -> List[str]:
    """Tokenize text into lowercase word tokens, optionally removing stopwords and stemming."""
    tokens = re.findall(r"[a-zA-Z0-9]+", text.lower())

    if remove_stopwords:
        tokens = [t for t in tokens if t not in STOPWORDS]

    if stemmer is not None:
        tokens = [stemmer.stem(t) for t in tokens]

    return tokens


def tokenize_corpus(
    corpus: List[str],
    stopwords: str = "en",
    stemmer: Optional[SimpleStemmer] = None,
) -> List[List[str]]:
    """Tokenize a corpus of documents, matching the bm25s tokenize_corpus API shape."""
    remove_stopwords = stopwords == "en"
    return [
        tokenize(doc, remove_stopwords=remove_stopwords, stemmer=stemmer)
        for doc in corpus
    ]


class BM25:
    """Minimal BM25 ranking implementation with an API shaped like bm25s.BM25."""

    def __init__(self, k1: float = 1.5, b: float = 0.75) -> None:
        self.k1 = k1
        self.b = b
        self.corpus_tokens: List[List[str]] = []
        self.doc_freqs: List[Dict[str, int]] = []
        self.idf: Dict[str, float] = {}
        self.doc_lens: List[int] = []
        self.avg_doc_len: float = 0.0

    def index(self, corpus_tokens: List[List[str]]) -> None:
        self.corpus_tokens = corpus_tokens
        self.doc_freqs = [Counter(tokens) for tokens in corpus_tokens]
        self.doc_lens = [len(tokens) for tokens in corpus_tokens]
        num_docs = len(corpus_tokens)
        self.avg_doc_len = sum(self.doc_lens) / num_docs if num_docs else 0.0

        doc_containing: Dict[str, int] = Counter()
        for tokens in corpus_tokens:
            for token in set(tokens):
                doc_containing[token] += 1

        self.idf = {}
        for token, freq in doc_containing.items():
            idf_score = math.log(1 + (num_docs - freq + 0.5) / (freq + 0.5))
            self.idf[token] = idf_score

    def get_scores(self, query_tokens: List[str]) -> List[float]:
        scores = []
        for doc_idx, doc_tokens in enumerate(self.corpus_tokens):
            term_freqs = self.doc_freqs[doc_idx]
            doc_len = self.doc_lens[doc_idx]
            score = 0.0
            for query_token in query_tokens:
                if query_token not in term_freqs:
                    continue
                tf = term_freqs[query_token]
                idf_score = self.idf.get(query_token, 0.0)
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (
                    1 - self.b + self.b * doc_len / (self.avg_doc_len or 1)
                )
                score += idf_score * numerator / denominator
            scores.append(score)
        return scores

    def retrieve(
        self, query_tokens: List[str], k: int = 10
    ) -> Tuple[List[List[int]], List[List[float]]]:
        scores = self.get_scores(query_tokens)
        scored_docs = list(enumerate(scores))
        top_k = sorted(scored_docs, key=lambda x: x[1], reverse=True)[:k]

        doc_indices = [[idx for idx, _ in top_k]]
        doc_scores = [[score for _, score in top_k]]
        return doc_indices, doc_scores
