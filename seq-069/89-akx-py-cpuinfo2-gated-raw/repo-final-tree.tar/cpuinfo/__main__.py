import cpuinfo

cpuinfo.main()
