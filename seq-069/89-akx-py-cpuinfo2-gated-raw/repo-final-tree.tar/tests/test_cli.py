import json
import os
import re
import sys
from subprocess import PIPE, Popen

from cpuinfo import cpuinfo



def test_version():
	command = [sys.executable, 'cpuinfo/cpuinfo.py', '--version']
	p1 = Popen(command, stdout=PIPE, stderr=PIPE, stdin=PIPE)
	output = p1.communicate()[0]

	assert p1.returncode == 0

	output = output.decode(encoding='UTF-8')
	output = output.strip()

	assert output == cpuinfo.CPUINFO_VERSION_STRING



def test_default():
	command = [sys.executable, 'cpuinfo/cpuinfo.py']
	p1 = Popen(command, stdout=PIPE, stderr=PIPE, stdin=PIPE)
	output = p1.communicate()[0]

	assert p1.returncode == 0

	output = output.decode(encoding='UTF-8')

	version = output.split('Cpuinfo Version: ')[1].split('\n')[0].strip()

	assert version == cpuinfo.CPUINFO_VERSION_STRING
