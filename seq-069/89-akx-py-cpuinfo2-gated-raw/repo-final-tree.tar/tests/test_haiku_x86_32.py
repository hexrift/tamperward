import pytest

from cpuinfo import cpuinfo
from tests import helpers


class MockDataSource:
	bits = '32bit'
	cpu_count = 4
	is_windows = False
	arch_string_raw = 'BePC'
	uname_string_raw = 'x86_32'
	can_cpuid = False

	@staticmethod
	def has_sysinfo():
		return True

	@staticmethod
	def sysinfo_cpu():
		returncode = 0
		output = r'''
4 Intel Core i7, revision 46e5 running at 2928MHz (ID: 0x00000000 0x00000000)

CPU #0: "Intel(R) Core(TM) i7 CPU         870  @ 2.93GHz"
	Type 0, family 6, model 30, stepping 5, features 0x178bfbbf
		FPU VME DE PSE TSC MSR MCE CX8 APIC SEP MTRR PGE MCA CMOV PAT PSE36
		CFLUSH MMX FXSTR SSE SSE2 HTT
	Extended Intel: 0x00000201
		SSE3 SSSE3
	Extended AMD: type 0, family 0, model 0, stepping 0, features 0x08000000
		RDTSCP
	Power Management Features:

	L2 Data cache 8-way set associative, 1 lines/tag, 64 bytes/line
	L2 cache: 0 KB, 1-way set associative, 0 lines/tag, 63 bytes/line

	Data TLB: 2M/4M-bytes pages, 4-way set associative, 32 entries
	Data TLB: 4k-byte pages, 4-way set associative, 64 entries
	Inst TLB: 2M/4M-bytes pages, fully associative, 7 entries
	L3 cache: 8192 KB, 16-way set associative, 64-bytes/line
	Inst TLB: 4K-bytes pages, 4-way set associative, 128 entries
	64-byte Prefetching
	L1 data cache: 32 KB, 8-way set associative, 64 bytes/line
	L2 cache: 256 KB (MLC), 8-way set associative, 64-bytes/line
	Shared 2nd-level TLB: 4K, 4-way set associative, 512 entries
	Unknown cache descriptor 0x09
'''
		return returncode, output


@pytest.fixture(autouse=True)
def _setup(monkeypatch):
	helpers.monkey_patch_data_source(cpuinfo, MockDataSource, monkeypatch)


'''
Make sure calls return the expected number of fields.
'''



