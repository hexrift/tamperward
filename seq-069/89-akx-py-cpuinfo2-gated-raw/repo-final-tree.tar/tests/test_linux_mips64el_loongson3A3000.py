import pytest

from cpuinfo import cpuinfo
from tests import helpers


class MockDataSource:
	bits = '64bit'
	cpu_count = 4
	is_windows = False
	arch_string_raw = 'mips64'
	uname_string_raw = ''
	can_cpuid = False

	@staticmethod
	def has_proc_cpuinfo():
		return True

	@staticmethod
	def has_lscpu():
		return True

	@staticmethod
	def cat_proc_cpuinfo():
		returncode = 0
		output = r'''
system type             : generic-loongson-machine
machine                 : Unknown
processor               : 0
cpu model               : ICT Loongson-3 V0.13  FPU V0.1
model name              : ICT Loongson-3A R3 (Loongson-3A3000) @ 1449MHz
BogoMIPS                : 2887.52
wait instruction        : yes
microsecond timers      : yes
tlb_entries             : 1088
extra interrupt vector  : no
hardware watchpoint     : yes, count: 0, address/irw mask: []
isa                     : mips1 mips2 mips3 mips4 mips5 mips32r1 mips32r2 mips64r1 mips64r2
ASEs implemented        : vz
shadow register sets    : 1
kscratch registers      : 6
package                 : 0
core                    : 0
VCED exceptions         : not available
VCEI exceptions         : not available

processor               : 1
cpu model               : ICT Loongson-3 V0.13  FPU V0.1
model name              : ICT Loongson-3A R3 (Loongson-3A3000) @ 1449MHz
BogoMIPS                : 2902.61
wait instruction        : yes
microsecond timers      : yes
tlb_entries             : 1088
extra interrupt vector  : no
hardware watchpoint     : yes, count: 0, address/irw mask: []
isa                     : mips1 mips2 mips3 mips4 mips5 mips32r1 mips32r2 mips64r1 mips64r2
ASEs implemented        : vz
shadow register sets    : 1
kscratch registers      : 6
package                 : 0
core                    : 1
VCED exceptions         : not available
VCEI exceptions         : not available

processor               : 2
cpu model               : ICT Loongson-3 V0.13  FPU V0.1
model name              : ICT Loongson-3A R3 (Loongson-3A3000) @ 1449MHz
BogoMIPS                : 2902.61
wait instruction        : yes
microsecond timers      : yes
tlb_entries             : 1088
extra interrupt vector  : no
hardware watchpoint     : yes, count: 0, address/irw mask: []
isa                     : mips1 mips2 mips3 mips4 mips5 mips32r1 mips32r2 mips64r1 mips64r2
ASEs implemented        : vz
shadow register sets    : 1
kscratch registers      : 6
package                 : 0
core                    : 2
VCED exceptions         : not available
VCEI exceptions         : not available

processor               : 3
cpu model               : ICT Loongson-3 V0.13  FPU V0.1
model name              : ICT Loongson-3A R3 (Loongson-3A3000) @ 1449MHz
BogoMIPS                : 2887.52
wait instruction        : yes
microsecond timers      : yes
tlb_entries             : 1088
extra interrupt vector  : no
hardware watchpoint     : yes, count: 0, address/irw mask: []
isa                     : mips1 mips2 mips3 mips4 mips5 mips32r1 mips32r2 mips64r1 mips64r2
ASEs implemented        : vz
shadow register sets    : 1
kscratch registers      : 6
package                 : 0
core                    : 3
VCED exceptions         : not available
VCEI exceptions         : not available
'''
		return returncode, output

	@staticmethod
	def lscpu():
		returncode = 0
		output = r'''
Architecture:          mips64
Byte Order:            Little Endian
CPU(s):                4
On-line CPU(s) list:   0-3
Thread(s) per core:    1
Core(s) per socket:    4
Socket(s):             1
NUMA node(s):          1
Model name:            ICT Loongson-3A R3 (Loongson-3A3000) @ 1449MHz
BogoMIPS:              2887.52
L1d cache:             64K
L1i cache:             64K
L2 cache:              256K
L3 cache:              2048K
NUMA node0 CPU(s):     0-3
'''
		return returncode, output


@pytest.fixture(autouse=True)
def _setup(monkeypatch):
	helpers.monkey_patch_data_source(cpuinfo, MockDataSource, monkeypatch)


'''
Make sure calls return the expected number of fields.
'''




