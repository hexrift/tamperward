# (C) Copyright 2021 ECMWF.
#
# This software is licensed under the terms of the Apache Licence Version 2.0
# which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
# In applying this licence, ECMWF does not waive the privileges and immunities
# granted to it by virtue of its status as an intergovernmental organisation
# nor does it submit to any jurisdiction.
#

import pytest
import requests


def _network_available():
    try:
        r = requests.get("http://httpbin.org/status/200", timeout=5)
        return r.status_code == 200
    except requests.exceptions.RequestException:
        return False


NETWORK_AVAILABLE = _network_available()

NETWORK_TEST_MODULES = {"test_auth", "test_downloader", "test_robust"}


def pytest_collection_modifyitems(config, items):
    if NETWORK_AVAILABLE:
        return
    skip_network = pytest.mark.skip(
        reason="requires outbound network access to external test hosts, "
        "which is unavailable in this environment"
    )
    for item in items:
        if item.module.__name__ in NETWORK_TEST_MODULES:
            item.add_marker(skip_network)
