from __future__ import annotations

import pathlib
from typing import BinaryIO, Union

PathIn = Union[str, pathlib.Path]
PathOrFileIn = Union[str, pathlib.Path, BinaryIO]
