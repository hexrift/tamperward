# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.16.1](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.16.1) - 2026-04-07
-   Fix search methods not working correctly with relative paths.
-   Bump requirements and `pre-commit` hooks.

## [0.16.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.16.0) - 2026-01-08
-   Add `Python 3.14` support.
-   Fix atomic file operations support on Windows. #121
-   Normalize paths to use OS specific separators in `search_*` methods.
-   Bump requirements and `pre-commit` hooks.

## [0.15.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.15.0) - 2025-02-06
-   Split codebase into modules.
-   Convert tests to `pytest`.
-   Bump requirements and `pre-commit` hooks.

## [0.14.1](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.14.1) - 2024-03-19
-   Add `mypy` to `pre-commit`.
-   Add `transform_filepath` method. #12 #13
-   Fix `join_filename` return value when `basename` or `extension` are empty.
-   Fix `pyproject` `Ruff` conf warnings.
-   Bump requirements and `pre-commit` hooks.

## [0.13.1](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.13.1) - 2024-01-24
-   Fix permissions inheritance from existing file when using `write_file` with `atomic=True`. #94
-   Bump requirements and `pre-commit` hooks.

## [0.13.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.13.0) - 2023-12-19
-   Add `get_permissions` and `set_permissions` methods.
-   Fix permissions lost when using `write_file` with `atomic=True`. #94
-   Improve `write_file` with `atomic=True` atomicity. #91
-   Remove tests duplicated code.

## [0.12.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.12.0) - 2023-12-11
-   Add possibility to write files atomically (`fsutil.write_file(path, content, atomic=True)`). #91

## [0.11.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.11.0) - 2023-11-01
-   Add `Python 3.12` support. (#84)
-   Add `tar` files operations support. #48 (#87)
-   Switch from `setup.cfg` to `pyproject.toml`.
-   Replace `flake8` with `Ruff`.
-   Fix `tox` test command.
-   Upgrade syntax for `Python >= 3.8`.
-   Reformat tests code.
-   Set `Black` pre-commit hook `line-length` option value.
-   Add `fix-future-annotations` `pre-commit` hook.
-   Bump requirements and `pre-commit` hooks.

## [0.10.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.10.0) - 2023-02-01
-   Rename default branch from `master` to `main`.
-   Move `flake8` config to `setup.cfg`.
-   Increase `flake8` checks.
-   Add `mypy` to CI (strict mode).
-   Add `pre-commit` to CI.
-   Force keyword arguments .
-   Remove unused import.
-   Add type hints. #18
-   Bump requirements and `pre-commit` hooks.

## [0.9.3](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.9.3) - 2023-01-12
-   Remove `tests/` from dist.

## [0.9.2](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.9.2) - 2023-01-11
-   Fix `FileNotFoundError` when calling `make_dirs_for_file` with filename only.
-   Pin test requirements.
-   Bump test requirements.

## [0.9.1](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.9.1) - 2023-01-02
-   Fix `OSError` when downloading multiple files to the same temp dir.

## [0.9.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.9.0) - 2023-01-02
-   Drop old code targeting `Python < 3.8`.
-   Add `get_unique_name` method.
-   Add `replace_file` method.
-   Add `replace_dir` method.
-   Add `get_dir_hash` method. #10
-   Add support to `pathlib.Path` path arguments. #14
-   Add default value for `pattern` argument in `search_dirs` and `search_files` methods.
-   Add more assertions on path args.
-   Increase tests coverage.
-   Add `setup.cfg` (`setuptools` declarative syntax) generated using `setuptools-py2cfg`.
-   Add `pyupgrade` to `pre-commit` config.
-   Fix duplicated test name.
-   Remove unused variable in tests.

## [0.8.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.8.0) - 2022-12-09
-   Add `Python 3.11` support.
-   Drop `Python < 3.8` support. #17
-   Add `pypy` to CI.
-   Add `pre-commit`.
-   Add default json encoder to `write_file_json` for encoding also `datetime` and `set` objects by default.
-   Replace `str.format` with `f-strings`.
-   Make `dirpath` argument optional in `download_file` method.
-   Fix `download_file` `NameError` when `requests` is not installed.
-   Increase tests coverage.
-   Bump requirements and GitHub actions versions.

## [0.7.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.7.0) - 2022-09-13
-   Add `read_file_lines_count` method.
-   Update `read_file_lines` method with two new arguments: `line_start` and `line_end` *(for specifying the lines-range to read)*.

## [0.6.1](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.6.1) - 2022-05-20
-   Fixed `create_zip_file` content directory structure.

## [0.6.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.6.0) - 2022-01-25
-   Added `read_file_json` and `write_file_json` methods.
-   Removed `requests` requirement *(it's optional now)*.

## [0.5.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.5.0) - 2021-05-03
-   Added `get_parent_dir` method.
-   Updated `join_path` to force concatenation even with absolute paths.
-   Updated `join_path` to return a normalized path.
-   Updated `join_filepath` method to use `join_path`.

## [0.4.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.4.0) - 2020-12-23
-   Added `delete_dir_content` method (alias for `remove_dir_content` method).
-   Added `download_file` method.
-   Added `read_file_from_url` method.
-   Added `remove_dir_content` and method.

## [0.3.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.3.0) - 2020-11-04
-   Added `create_zip_file` method.
-   Added `extract_zip_file` method.
-   Added `get_dir_creation_date` method.
-   Added `get_dir_creation_date_formatted` method.
-   Added `get_dir_last_modified_date` method.
-   Added `get_dir_last_modified_date_formatted` method.
-   Added `get_file_creation_date` method.
-   Added `get_file_creation_date_formatted` method.
-   Added `get_file_last_modified_date` method.
-   Added `get_file_last_modified_date_formatted` method.
-   Added `read_file_lines` method.
-   Refactored tests.

## [0.2.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.2.0) - 2020-10-29
-   Added `convert_size_bytes_to_string` method.
-   Added `convert_size_string_to_bytes` method.
-   Added `get_dir_size` method.
-   Added `get_dir_size_formatted` method.
-   Added `get_file_size` method.
-   Added `get_file_size_formatted`.
-   Renamed `get_path` to `join_path`.
-   Renamed `get_hash` to `get_file_hash`.
-   Fixed `clean_dir` method and added relative tests.
-   Improved code quality and tests coverage.

## [0.1.0](https://github.com/fabiocaccamo/python-fsutil/releases/tag/0.1.0) - 2020-10-27
-   Released `python-fsutil`
