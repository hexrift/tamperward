.. contents:: **typepy**
   :backlinks: top
   :depth: 2

Summary
=========
`typepy <https://github.com/thombashi/typepy>`__ is a Python library for variable type checker/validator/converter at a run time.

.. image:: https://badge.fury.io/py/typepy.svg
    :target: https://badge.fury.io/py/typepy
    :alt: PyPI package version

.. image:: https://anaconda.org/conda-forge/typepy/badges/version.svg
    :target: https://anaconda.org/conda-forge/typepy
    :alt: conda-forge package version

.. image:: https://img.shields.io/pypi/pyversions/typepy.svg
    :target: https://pypi.org/project/typepy
    :alt: Supported Python versions

.. image:: https://img.shields.io/pypi/implementation/typepy.svg
    :target: https://pypi.org/project/typepy
    :alt: Supported Python implementations

.. image:: https://github.com/thombashi/typepy/workflows/Tests/badge.svg
    :target: https://github.com/thombashi/typepy/actions?query=workflow%3ATests
    :alt: Linux/macOS/Windows CI status

.. image:: https://coveralls.io/repos/github/thombashi/typepy/badge.svg?branch=master
    :target: https://coveralls.io/github/thombashi/typepy?branch=master
    :alt: Test coverage

.. image:: https://github.com/thombashi/typepy/actions/workflows/github-code-scanning/codeql/badge.svg
    :target: https://github.com/thombashi/typepy/actions/workflows/github-code-scanning/codeql
    :alt: CodeQL

Features
==========
- checking a value type
- validate a value for a type
- convert a value from one type to the other type

The correspondence between Python types and ``typepy`` classes are as follows:

.. table:: Supported Types

    ================================================  =======================================================================================================
    Python Type                                       typepy: Type Class
    ================================================  =======================================================================================================
    ``bool``                                          `Bool <https://typepy.rtfd.io/en/latest/pages/reference/type.html#bool-type>`__
    ``datetime``                                      `DateTime <https://typepy.rtfd.io/en/latest/pages/reference/type.html#datetime-type>`__
    ``dict``                                          `Dictionary <https://typepy.rtfd.io/en/latest/pages/reference/type.html#dictionary-type>`__
    ``float``/``decimal.Decimal`` (not infinity/NaN)  `RealNumber <https://typepy.rtfd.io/en/latest/pages/reference/type.html#real-number-type>`__
    ``float``/``decimal.Decimal`` (infinity)          `Infinity <https://typepy.rtfd.io/en/latest/pages/reference/type.html#infinity-type>`__
    ``float``/``decimal.Decimal`` (NaN)               `Nan <https://typepy.rtfd.io/en/latest/pages/reference/type.html#nan-type>`__
    ``int``                                           `Integer <https://typepy.rtfd.io/en/latest/pages/reference/type.html#integer-type>`__
    ``list``                                          `List <https://typepy.rtfd.io/en/latest/pages/reference/type.html#list-type>`__
    ``None``                                          `None <https://typepy.rtfd.io/en/latest/pages/reference/type.html#none-type>`__
    ``str`` (not null)                                `String <https://typepy.rtfd.io/en/latest/pages/reference/type.html#string-type>`__
    ``str`` (null)                                    `NullString <https://typepy.rtfd.io/en/latest/pages/reference/type.html#null-string-type>`__
    ``str`` (IP address)                              `IpAddress <https://typepy.rtfd.io/en/latest/pages/reference/type.html#ip-address-type>`__
    ================================================  =======================================================================================================

Installation
============

Installation: pip
------------------------------
::

    pip install typepy

Install additional dependency packages with the following command if using ``typepy.DateTime`` class

::

    pip install typepy[datetime]

Installation: conda
------------------------------
::

    conda install -c conda-forge typepy

Installation: apt
------------------------------
::

    sudo add-apt-repository ppa:thombashi/ppa
    sudo apt update
    sudo apt install python3-typepy


Dependencies
============
- Python 3.9+
- `Python package dependencies (automatically installed) <https://github.com/thombashi/typepy/network/dependencies>`__

Optional dependencies
----------------------------------
These packages can be installed via ``pip install typepy[datetime]``:

- `python-dateutil <https://dateutil.readthedocs.io/en/stable/>`__
- `pytz <https://pypi.org/project/pytz/>`__

Usage
=======
Type Check Method
----------------------
:Examples:
    .. code-block:: pycon

        >>> from typepy import Integer
        >>> Integer(1).is_type()
        True
        >>> Integer(1.1).is_type()
        False


Type Validation Method
--------------------------------------------
:Examples:
    .. code-block:: pycon

        >>> from typepy import Integer
        >>> Integer(1).validate()
        >>> try:
        ...     Integer(1.1).validate()
        ... except TypeError as e:
        ...     # validate() raised TypeError when the value unmatched the type class
        ...     print(e)
        ...
        invalid value type: expected=INTEGER, actual=<type 'float'>


Type Conversion Methods
--------------------------------------------

convert method
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
:Examples:
    .. code-block:: pycon

        >>> from typepy import Integer, TypeConversionError
        >>> Integer("1").convert()
        1
        >>> try:
        ...     Integer(1.1).convert()
        ... except TypeConversionError as e:
        ...     # convert() raised TypeConversionError when conversion failed
        ...     print(e)
        ...
        failed to convert from float to INTEGER

try_convert method
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
:Examples:
    .. code-block:: pycon

        >>> from typepy import Integer
        >>> Integer("1").try_convert()
        1
        >>> print(Integer(1.1).try_convert())  # try_convert() returned None when conversion failed
        None

force_convert
~~~~~~~~~~~~~~~~~~~~~~~~~~~~
:Examples:
    .. code-block:: pycon

        >>> from typepy import Integer, TypeConversionError
        >>> Integer("1").force_convert()  # force_convert() forcibly convert the value
        1
        >>> Integer(1.1).force_convert()
        1
        >>> try:
        ...     Integer("abc").force_convert()
        ... except TypeConversionError as e:
        ...     # force_convert() raised TypeConversionError when the value was not convertible
        ...     print(e)
        ...
        failed to force_convert to int: type=<class 'str'>


For more information
--------------------------------------------
Type check/validate/convert results differed according to
``strict_level`` value which can pass to typepy class constructors as an argument.
More information can be found in the
`API reference <https://typepy.rtfd.io/en/latest/pages/reference/index.html>`__.

Documentation
===============
https://typepy.rtfd.io/

