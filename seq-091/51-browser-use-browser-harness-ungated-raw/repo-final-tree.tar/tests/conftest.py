import base64
import io
import os
import tempfile

# browser_harness computes its home/tmp dirs at import time (see
# src/browser_harness/_ipc.py) and creates them eagerly. Point BH_HOME at a
# throwaway directory before anything imports the package, so tests never
# touch (or depend on the permissions of) the real user home directory.
os.environ.setdefault("BH_HOME", tempfile.mkdtemp(prefix="browser-harness-test-"))

import pytest
from PIL import Image


def make_png(width, height):
    buf = io.BytesIO()
    Image.new("RGB", (width, height), "white").save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


@pytest.fixture
def fake_png():
    return make_png
