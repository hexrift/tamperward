import base64
import io
import os
import tempfile

# Set before any test module imports browser_harness: paths.home_dir() otherwise
# falls back to the real XDG_CONFIG_HOME/HOME, which may not be writable in CI.
os.environ.setdefault("BH_HOME", tempfile.mkdtemp(prefix="bh-test-home-"))

import pytest
from PIL import Image


def make_png(width, height):
    buf = io.BytesIO()
    Image.new("RGB", (width, height), "white").save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


@pytest.fixture
def fake_png():
    return make_png
