"""
jinja_partials - Simple reuse of partial HTML page templates in the Jinja template language for Python web frameworks.
"""

import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager
from functools import partial
from importlib.metadata import PackageNotFoundError, version
from typing import TYPE_CHECKING, Any, AsyncIterator, Callable, Literal, Optional, Union, overload

from jinja2 import Environment
from jinja2.ext import Extension
from jinja2.utils import concat
from markupsafe import Markup as Markup

try:
    __version__ = version('jinja_partials')
except PackageNotFoundError:
    __version__ = '0.0.0'
__author__ = 'Michael Kennedy <michael@talkpython.fm>'
__all__ = [
    '__version__',
    'register_extensions',
    'register_quart_extensions',
    'register_fastapi_extensions',
    'register_starlette_extensions',
    'register_environment',
    'render_partial',
    'generate_render_partial',
    'PartialsException',
    'PartialsJinjaExtension',
]

# Thread pool for running async renders from sync context
_async_render_executor = ThreadPoolExecutor(max_workers=4)

try:
    import flask
except ImportError:
    flask = None

try:
    import quart
except ImportError:
    quart = None

try:
    import fastapi
except ImportError:
    fastapi = None

try:
    import starlette
except ImportError:
    starlette = None

if TYPE_CHECKING:
    if flask:
        from flask import Flask
    if quart:
        from quart import Quart
    if fastapi:
        from fastapi import FastAPI
        from fastapi.templating import Jinja2Templates as FastAPIJinja2Templates
    if starlette:
        from starlette.applications import Starlette
        from starlette.templating import Jinja2Templates


class PartialsException(Exception):
    """Raised when jinja_partials is misconfigured or a required web framework is not installed."""

    pass


class PartialsJinjaExtension(Extension):
    """Jinja2 extension that automatically registers render_partial functionality.

    The extension automatically makes render_partial available as a global
    function in templates. By default, markup is enabled.

    Note:
        Partials registered this way render directly through the Jinja2
        environment rather than flask.render_template, so Flask context
        processors do not apply inside partials. Flask apps that rely on
        context processors should use register_extensions instead.

    Args:
        environment: The Jinja2 environment the extension is loaded into.
            Jinja2 passes this automatically when the class is listed in
            extensions=[...].

    Example:
        Enable the extension on a Jinja2 environment:

            from jinja2 import Environment
            env = Environment(extensions=["jinja_partials.PartialsJinjaExtension"])
    """

    def __init__(self, environment: Environment) -> None:
        super().__init__(environment)
        # Use register_environment with markup=True to maintain same behavior
        register_environment(environment, markup=True)


@overload
def render_partial(
    template_name: str,
    renderer: Optional[Callable[..., Any]] = ...,
    markup: Literal[True] = ...,
    **data: Any,
) -> Markup: ...


@overload
def render_partial(
    template_name: str,
    renderer: Optional[Callable[..., Any]] = ...,
    *,
    markup: Literal[False],
    **data: Any,
) -> str: ...


@overload
def render_partial(
    template_name: str,
    renderer: Optional[Callable[..., Any]] = ...,
    markup: bool = ...,
    **data: Any,
) -> Union[Markup, str]: ...


def render_partial(
    template_name: str,
    renderer: Optional[Callable[..., Any]] = None,
    markup: bool = True,
    **data: Any,
) -> Union[Markup, str]:
    """Render a partial template and return the resulting HTML fragment.

    Args:
        template_name: Path of the template within the templates folder,
            e.g. `shared/partials/video_image.html`.
        renderer: Callable that renders the template with the given keyword
            arguments. Defaults to flask.render_template when Flask is installed.
        markup: When True (the default), wrap the result in markupsafe.Markup
            so it is not re-escaped when inserted into another template.
        **data: Model data passed to the template as keyword arguments.

    Returns:
        The rendered fragment as Markup, or str when markup=False.

    Raises:
        PartialsException: If no renderer is specified and Flask is not installed.
    """
    if renderer is None:
        if flask is None:
            raise PartialsException('No renderer specified')
        else:
            renderer = flask.render_template

    if markup:
        return Markup(renderer(template_name, **data))

    return renderer(template_name, **data)


@overload
def generate_render_partial(renderer: Callable[..., Any], markup: Literal[True] = ...) -> Callable[..., Markup]: ...


@overload
def generate_render_partial(renderer: Callable[..., Any], markup: Literal[False]) -> Callable[..., str]: ...


@overload
def generate_render_partial(renderer: Callable[..., Any], markup: bool) -> Callable[..., Union[Markup, str]]: ...


def generate_render_partial(renderer: Callable[..., Any], markup: bool = True) -> Callable[..., Union[Markup, str]]:
    """Create a render_partial function bound to a specific renderer.

    Args:
        renderer: Callable that renders a template name plus keyword arguments to a string.
        markup: When True (the default), results are wrapped in markupsafe.Markup.

    Returns:
        A callable with the same signature as render_partial that uses the bound renderer.
    """
    return partial(render_partial, renderer=renderer, markup=markup)


def register_extensions(app: 'Flask') -> None:
    """Register jinja_partials with a Flask application.

    Makes render_partial available as a global function in the app's Jinja
    templates, rendering with flask.render_template.

    Args:
        app: The Flask application instance.

    Raises:
        PartialsException: If Flask is not installed.
    """
    if flask is None:
        raise PartialsException('Install Flask to use `register_extensions`')

    app.jinja_env.globals.update(render_partial=generate_render_partial(flask.render_template))


def register_quart_extensions(app: 'Quart', max_workers: int = 4) -> None:
    """Register jinja_partials with a Quart application.

    This creates a dedicated ThreadPoolExecutor for rendering partials in async
    environments. The executor lifecycle is tied to the Quart app - it will be
    properly shut down when the app stops.

    Args:
        app: The Quart application instance.
        max_workers: Maximum number of worker threads for rendering partials.
                     Defaults to 4.

    Raises:
        PartialsException: If Quart is not installed.
    """
    if quart is None:
        raise PartialsException('Install Quart to use `register_quart_extensions`')

    # Fallback executor used for rendering outside of a serving cycle
    # (e.g. before the first startup, or after a clean shutdown).
    fallback = ThreadPoolExecutor(max_workers=max_workers)
    app.extensions['jinja_partials_executor'] = None  # type: ignore[index]

    @app.before_serving
    async def startup_executor():
        # If a previous cycle failed before after_serving could run, the slot
        # still holds an orphaned executor - shut it down before replacing it.
        stale = app.extensions.get('jinja_partials_executor')  # type: ignore[attr-defined]
        if stale is not None:
            stale.shutdown(wait=True)
        app.extensions['jinja_partials_executor'] = ThreadPoolExecutor(max_workers=max_workers)  # type: ignore[index]

    @app.after_serving
    async def shutdown_executor():
        executor = app.extensions.get('jinja_partials_executor')  # type: ignore[attr-defined]
        if executor is not None:
            executor.shutdown(wait=True)
        app.extensions['jinja_partials_executor'] = None  # type: ignore[index]

    def renderer(template_name: str, **data: Any) -> str:
        env = app.jinja_env
        template = env.get_template(template_name)

        if env.is_async:
            # Use the per-cycle executor while serving, falling back to the
            # per-registration executor otherwise.
            executor = app.extensions.get('jinja_partials_executor') or fallback  # type: ignore[attr-defined]
            future = executor.submit(_run_async_render, template, data)
            return future.result()

        # Sync environment - use direct rendering (unlikely for Quart)
        ctx = template.new_context(data)
        try:
            return concat(template.root_render_func(ctx))
        except Exception:
            return env.handle_exception()

    app.jinja_env.globals.update(render_partial=generate_render_partial(renderer, markup=True))


def register_fastapi_extensions(
    app: 'FastAPI',
    templates: 'FastAPIJinja2Templates',
    max_workers: int = 4,
) -> None:
    """Register jinja_partials with a FastAPI application.

    This creates a dedicated ThreadPoolExecutor for rendering partials in async
    environments. The executor lifecycle is tied to the FastAPI app via its
    lifespan - it is shut down when the lifespan exits normally (one
    startup/shutdown cycle per registration).

    Args:
        app: The FastAPI application instance.
        templates: The Jinja2Templates instance used for rendering.
        max_workers: Maximum number of worker threads for rendering partials.
                     Defaults to 4.

    Raises:
        PartialsException: If FastAPI is not installed.

    Example:
        Register during app setup:

            from fastapi import FastAPI
            from fastapi.templating import Jinja2Templates
            import jinja_partials

            app = FastAPI()
            templates = Jinja2Templates(directory="templates")
            jinja_partials.register_fastapi_extensions(app, templates)
    """
    if fastapi is None:
        raise PartialsException('Install FastAPI to use `register_fastapi_extensions`')

    # Fallback executor used for rendering outside of a lifespan cycle
    # (e.g. before the first startup).
    fallback = ThreadPoolExecutor(max_workers=max_workers)
    app.state.jinja_partials_executor = None

    # Wrap existing lifespan if present
    original_lifespan = app.router.lifespan_context

    @asynccontextmanager
    async def lifespan_wrapper(app_instance: 'FastAPI') -> AsyncIterator[dict[str, Any]]:
        executor = ThreadPoolExecutor(max_workers=max_workers)
        app_instance.state.jinja_partials_executor = executor
        try:
            # Run original lifespan startup
            if original_lifespan is not None:
                async with original_lifespan(app_instance) as state:
                    yield state if state else {}  # type: ignore
            else:
                yield {}
        finally:
            # Always shut down the executor, even if the wrapped lifespan
            # raises during startup or shutdown.
            executor.shutdown(wait=True)
            app_instance.state.jinja_partials_executor = None

    app.router.lifespan_context = lifespan_wrapper

    env = templates.env

    def renderer(template_name: str, **data: Any) -> str:
        template = env.get_template(template_name)

        if env.is_async:
            # Use the per-cycle executor while inside a lifespan, falling back
            # to the per-registration executor otherwise.
            executor = app.state.jinja_partials_executor or fallback
            future = executor.submit(_run_async_render, template, data)
            return future.result()

        # Sync environment - use direct rendering
        ctx = template.new_context(data)
        try:
            return concat(template.root_render_func(ctx))
        except Exception:
            return env.handle_exception()

    env.globals.update(render_partial=generate_render_partial(renderer, markup=True))


def register_starlette_extensions(
    templates: 'Jinja2Templates',
    app: Optional['Starlette'] = None,
    max_workers: int = 4,
) -> None:
    """Register jinja_partials with Starlette templates.

    If an app is provided, creates a dedicated ThreadPoolExecutor that is shut
    down when the app's lifespan exits normally (one startup/shutdown cycle per
    registration). Otherwise, falls back to the previous behavior: partials
    render directly for sync environments, or via a shared module-level
    executor for async (enable_async=True) environments.

    Args:
        templates: The Jinja2Templates instance used for rendering.
        app: Optional Starlette application instance for lifecycle management.
        max_workers: Maximum number of worker threads for rendering partials.
                     Only used when app is provided. Defaults to 4.

    Raises:
        PartialsException: If Starlette is not installed.

    Example:
        With lifecycle management:

            from starlette.applications import Starlette
            from starlette.templating import Jinja2Templates
            import jinja_partials

            templates = Jinja2Templates(directory="templates")
            app = Starlette(...)
            jinja_partials.register_starlette_extensions(templates, app=app)

        Without lifecycle management (backwards compatible):

            jinja_partials.register_starlette_extensions(templates)
    """
    if starlette is None:
        raise PartialsException('Install Starlette to use `register_starlette_extensions`')

    env = templates.env

    if app is not None:
        # Fallback executor used for rendering outside of a lifespan cycle
        # (e.g. before the first startup, or after a failed startup).
        fallback = ThreadPoolExecutor(max_workers=max_workers)
        app.state.jinja_partials_executor = None

        # Wrap existing lifespan if present
        original_lifespan = app.router.lifespan_context

        @asynccontextmanager
        async def lifespan_wrapper(app_instance: 'Starlette') -> AsyncIterator[dict[str, Any]]:
            executor = ThreadPoolExecutor(max_workers=max_workers)
            app_instance.state.jinja_partials_executor = executor
            try:
                # Run original lifespan startup
                if original_lifespan is not None:
                    async with original_lifespan(app_instance) as state:
                        yield state if state else {}  # type: ignore
                else:
                    yield {}
            finally:
                # Always shut down the executor, even if the wrapped lifespan
                # raises during startup or shutdown.
                executor.shutdown(wait=True)
                app_instance.state.jinja_partials_executor = None

        app.router.lifespan_context = lifespan_wrapper

        def renderer(template_name: str, **data: Any) -> str:
            template = env.get_template(template_name)

            if env.is_async:
                # Use the per-cycle executor while inside a lifespan, falling
                # back to the per-registration executor otherwise.
                executor = app.state.jinja_partials_executor or fallback
                future = executor.submit(_run_async_render, template, data)
                return future.result()

            ctx = template.new_context(data)
            try:
                return concat(template.root_render_func(ctx))
            except Exception:
                return env.handle_exception()

        env.globals.update(render_partial=generate_render_partial(renderer, markup=True))
    else:
        # Backwards compatible: use global executor
        def renderer(template_name: str, **data: Any) -> str:
            return _render_template_blocking(env, template_name, **data)  # type: ignore

        env.globals.update(render_partial=generate_render_partial(renderer))


def _run_async_render(template: Any, data: dict[str, Any]) -> str:
    """Run async template render in a new event loop (called from a thread)."""

    async def _do_render() -> str:
        return await template.render_async(**data)

    return asyncio.run(_do_render())


def _render_template_blocking(env: Environment, template_name: str, **data: Any) -> str:
    """Render a partial template, handling both sync and async Jinja environments.

    This function provides a synchronous interface for rendering partials, which is
    required because Jinja template expressions like {{ render_partial(...) }} cannot
    await async calls.

    For async environments (e.g., Quart with enable_async=True), we run the render
    in a separate thread with its own event loop to avoid the
    "cannot call asyncio.run() from running event loop" error.
    """
    template = env.get_template(template_name)

    # Check if templates are compiled for async (enable_async=True)
    if env.is_async:
        # Run async render in a separate thread with its own event loop
        future = _async_render_executor.submit(_run_async_render, template, data)
        return future.result()

    # Sync environment - use direct rendering
    ctx = template.new_context(data)
    try:
        return concat(template.root_render_func(ctx))
    except Exception:
        return env.handle_exception()


def register_environment(env: Environment, markup: bool = False) -> None:
    """Register jinja_partials with a plain Jinja2 environment.

    Use this for standalone Jinja2 usage or frameworks without dedicated support.
    Handles both sync and async (enable_async=True) environments.

    Args:
        env: The Jinja2 Environment to make render_partial available in.
        markup: When True, wrap rendered partials in markupsafe.Markup.
                Defaults to False.
    """

    def renderer(template_name: str, **data: Any) -> str:
        return _render_template_blocking(env, template_name, **data)

    env.globals.update(render_partial=generate_render_partial(renderer, markup=markup))
