class TimeoutException(BaseException):
    pass
