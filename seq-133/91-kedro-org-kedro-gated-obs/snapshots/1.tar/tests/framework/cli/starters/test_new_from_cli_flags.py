"""Tests for project creation through CLI flags."""

from __future__ import annotations

from pathlib import Path

import pytest
from click.testing import CliRunner

from kedro.framework.cli.starters import (
    TEMPLATE_PATH,
    _convert_tool_short_names_to_numbers,
)
from tests.framework.cli.starters.utils import (
    VALID_TOOLS_PARAMETERS,
    _assert_name_ok,
    _assert_requirements_ok,
    _assert_template_ok,
    _make_cli_prompt_input,
    _make_cli_prompt_input_without_name,
    _make_cli_prompt_input_without_tools,
)


@pytest.mark.usefixtures("chdir_to_tmp", "patch_cookiecutter_args")
class TestToolsAndExampleFromCLI:
    @pytest.mark.parametrize("tools", VALID_TOOLS_PARAMETERS)
    @pytest.mark.parametrize("example_pipeline", ["Yes", "No"])
    def test_valid_tools_flag(self, fake_kedro_cli, tools, example_pipeline):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--tools", tools, "--example", example_pipeline],
            input=_make_cli_prompt_input_without_tools(),
        )

        tools_normalized = _convert_tool_short_names_to_numbers(selected_tools=tools)
        tools_str = ",".join(tools_normalized) if tools_normalized else "none"

        _assert_template_ok(result, tools=tools_str, example_pipeline=example_pipeline)
        _assert_requirements_ok(result, tools=tools_str, repo_name="new-kedro-project")
        if tools_str != "none":
            assert "You have selected the following project tools:" in result.output
        else:
            assert "You have selected no project tools" in result.output
        assert (
            "To skip the interactive flow you can run `kedro new` with\n"
            "tool names for `--tools`, or `all`/`none`:\n"
            "kedro new --name=<your-project-name> "
            "--tools=lint,test,log,docs,data,pyspark --example=<yes/no>"
            in result.output
        )

    def test_docs_tool_generates_sphinx_build_files(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--tools", "docs", "--example", "no"],
            input=_make_cli_prompt_input_without_tools(),
        )

        _assert_template_ok(result, tools="4", example_pipeline="no")

        docs_path = Path("new-kedro-project") / "docs"
        gitignore = Path("new-kedro-project") / ".gitignore"
        makefile = docs_path / "Makefile"
        make_bat = docs_path / "make.bat"
        conf_py = docs_path / "source" / "conf.py"
        index_rst = docs_path / "source" / "index.rst"

        assert makefile.is_file()
        assert make_bat.is_file()
        assert "SPHINXAPIDOC  ?= sphinx-apidoc" in makefile.read_text()
        assert "html: apidoc" in makefile.read_text()
        assert "sphinx-apidoc" in make_bat.read_text()
        assert "new_kedro_project" in make_bat.read_text()
        assert "sys.path.insert" in conf_py.read_text()
        assert "   modules" in index_rst.read_text()
        assert "docs/build/" in gitignore.read_text()
        assert "docs/source/modules.rst" in gitignore.read_text()
        assert "docs/source/new_kedro_project*.rst" in gitignore.read_text()

    def test_invalid_tools_flag(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--tools", "bad_input"],
            input=_make_cli_prompt_input_without_tools(),
        )

        assert result.exit_code != 0
        assert (
            "Please select from the available tools: lint, test, log, docs, data, pyspark, all, none"
            in result.output
        )

    @pytest.mark.parametrize(
        "tools",
        ["lint,all", "test,none", "all,none"],
    )
    def test_invalid_tools_flag_combination(self, fake_kedro_cli, tools):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--tools", tools],
            input=_make_cli_prompt_input_without_tools(),
        )

        assert result.exit_code != 0
        assert (
            "Tools options 'all' and 'none' cannot be used with other options"
            in result.output
        )

    def test_flags_skip_interactive_flow(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            [
                "new",
                "--name",
                "New Kedro Project",
                "--tools",
                "none",
                "--example",
                "no",
            ],
        )

        assert result.exit_code == 0
        assert (
            "To skip the interactive flow you can run `kedro new` with\n"
            "tool names for `--tools`, or `all`/`none`:\n"
            "kedro new --name=<your-project-name> "
            "--tools=lint,test,log,docs,data,pyspark --example=<yes/no>"
            not in result.output
        )


@pytest.mark.usefixtures("chdir_to_tmp")
class TestNameFromCLI:
    @pytest.mark.parametrize(
        "name",
        [
            "readable_name",
            "Readable Name",
            "Readable-name",
            "readable_name_12233",
            "123ReadableName",
        ],
    )
    def test_valid_names(self, fake_kedro_cli, name):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--name", name],
            input=_make_cli_prompt_input_without_name(),
        )

        assert result.exit_code == 0
        _assert_name_ok(result, project_name=name)

    @pytest.mark.parametrize(
        "name",
        ["bad_name$%!", "Bad.Name", ""],
    )
    def test_invalid_names(self, fake_kedro_cli, name):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--name", name],
            input=_make_cli_prompt_input_without_name(),
        )

        assert result.exit_code != 0
        assert (
            "is an invalid value for project name. It must contain only alphanumeric symbols, spaces, underscores and hyphens and be at least 2 characters long"
            in result.output
        )

    @pytest.mark.parametrize(
        "name",
        ["email", "json", "string", "JSON", " email ", "import"],
    )
    def test_project_name_clashing_with_stdlib_or_keyword_is_rejected(
        self, fake_kedro_cli, name
    ):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--name", name],
            input=_make_cli_prompt_input_without_name(),
        )

        assert result.exit_code != 0
        assert (
            "clashes with a Python keyword or standard library module" in result.output
        )

    @pytest.mark.parametrize(
        "name",
        ["email-service", "my-json-app", "import_data"],
    )
    def test_project_name_containing_but_not_equal_to_stdlib_is_allowed(
        self, fake_kedro_cli, name
    ):
        """Names that merely contain a stdlib/keyword substring derive to a valid
        package name (e.g. 'email-service' -> 'email_service') and must be allowed."""
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--name", name],
            input=_make_cli_prompt_input_without_name(),
        )

        assert result.exit_code == 0
        _assert_name_ok(result, project_name=name)


@pytest.mark.usefixtures("chdir_to_tmp")
class TestTelemetryCLIFlag:
    @pytest.mark.parametrize(
        "input",
        ["yes", "YES", "y", "Y", "yEs"],
    )
    def test_flag_value_is_yes(self, fake_kedro_cli, input):
        result = CliRunner().invoke(
            fake_kedro_cli,
            [
                "new",
                "--name",
                "New Kedro Project",
                "--tools",
                "none",
                "--example",
                "no",
                "--telemetry",
                input,
            ],
        )

        repo_name = "new-kedro-project"
        assert result.exit_code == 0

        telemetry_file_path = Path(repo_name + "/.telemetry")
        assert telemetry_file_path.exists()

        with open(telemetry_file_path) as file:
            file_content = file.read()
            target_string = "consent: true"

        assert target_string in file_content

    @pytest.mark.parametrize(
        "input",
        ["no", "NO", "n", "N", "No"],
    )
    def test_flag_value_is_no(self, fake_kedro_cli, input):
        result = CliRunner().invoke(
            fake_kedro_cli,
            [
                "new",
                "--name",
                "New Kedro Project",
                "--tools",
                "none",
                "--example",
                "no",
                "--telemetry",
                input,
            ],
        )

        repo_name = "new-kedro-project"
        assert result.exit_code == 0

        telemetry_file_path = Path(repo_name + "/.telemetry")
        assert telemetry_file_path.exists()

        with open(telemetry_file_path) as file:
            file_content = file.read()
            target_string = "consent: false"

        assert target_string in file_content

    def test_flag_value_is_invalid(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            [
                "new",
                "--name",
                "New Kedro Project",
                "--tools",
                "none",
                "--example",
                "no",
                "--telemetry",
                "wrong",
            ],
        )

        repo_name = "new-kedro-project"
        assert result.exit_code == 2

        assert "'wrong' is not one of 'yes', 'no', 'y', 'n'" in result.output

        telemetry_file_path = Path(repo_name + "/.telemetry")
        assert not telemetry_file_path.exists()

    def test_flag_is_absent(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            [
                "new",
                "--name",
                "New Kedro Project",
                "--tools",
                "none",
                "--example",
                "no",
            ],
        )

        repo_name = "new-kedro-project"
        assert result.exit_code == 0

        telemetry_file_path = Path(repo_name + "/.telemetry")
        assert not telemetry_file_path.exists()


@pytest.mark.usefixtures("chdir_to_tmp")
class TestFlagsNotAllowed:
    def test_directory_flag_without_starter(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--directory", "some-directory"],
            input=_make_cli_prompt_input_without_tools(),
        )
        assert result.exit_code != 0
        assert (
            "Cannot use the --directory flag without a --starter value."
            in result.output
        )

    def test_directory_flag_with_starter_alias(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--starter", "spaceflights-pandas", "--directory", "some-dir"],
            input=_make_cli_prompt_input_without_tools(),
        )
        assert result.exit_code != 0
        assert "Cannot use the --directory flag with a --starter alias" in result.output

    def test_starter_flag_with_tools_flag(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--tools", "all", "--starter", "spaceflights-pandas"],
            input=_make_cli_prompt_input_without_tools(),
        )
        assert result.exit_code != 0
        assert (
            "Cannot use the --starter flag with the --example and/or --tools flag."
            in result.output
        )

    def test_starter_flag_with_example_flag(self, fake_kedro_cli):
        result = CliRunner().invoke(
            fake_kedro_cli,
            ["new", "--starter", "spaceflights-pandas", "--example", "no"],
            input=_make_cli_prompt_input_without_tools(),
        )
        assert result.exit_code != 0
        assert (
            "Cannot use the --starter flag with the --example and/or --tools flag."
            in result.output
        )


@pytest.mark.usefixtures("chdir_to_tmp")
class TestCheckoutWithoutStarter:
    def test_checkout_without_starter_tools_pyspark(
        self, fake_kedro_cli, mock_determine_repo_dir, mock_cookiecutter
    ):
        result = CliRunner().invoke(
            fake_kedro_cli,
            [
                "new",
                "--tools",
                "pyspark",
                "--example",
                "no",
                "--checkout",
                "my_checkout",
                "--name",
                "my-project",
            ],
        )
        assert result.exit_code == 0, result.output
        kwargs = {
            "template": "git+https://github.com/kedro-org/kedro-starters.git",
            "checkout": "my_checkout",
            "directory": "spaceflights-pyspark",
        }
        assert kwargs.items() <= mock_cookiecutter.call_args[1].items()

    def test_checkout_without_starter_example(
        self, fake_kedro_cli, mock_determine_repo_dir, mock_cookiecutter
    ):
        result = CliRunner().invoke(
            fake_kedro_cli,
            [
                "new",
                "--tools",
                "none",
                "--example",
                "yes",
                "--checkout",
                "my_checkout",
                "--name",
                "my-project",
            ],
        )
        assert result.exit_code == 0, result.output
        kwargs = {
            "template": "git+https://github.com/kedro-org/kedro-starters.git",
            "checkout": "my_checkout",
            "directory": "spaceflights-pandas",
        }
        assert kwargs.items() <= mock_cookiecutter.call_args[1].items()

    def test_checkout_without_starter_blank_template(
        self, fake_kedro_cli, mock_determine_repo_dir, mock_cookiecutter
    ):
        import warnings

        with warnings.catch_warnings(record=True) as caught_warnings:
            warnings.simplefilter("always")
            result = CliRunner().invoke(
                fake_kedro_cli,
                [
                    "new",
                    "--checkout",
                    "my_checkout",
                    "--name",
                    "my-project",
                    "--tools",
                    "none",
                    "--example",
                    "no",
                ],
            )
        assert result.exit_code == 0, result.output
        assert mock_cookiecutter.call_args[1]["template"] == str(TEMPLATE_PATH)
        assert mock_cookiecutter.call_args[1]["checkout"] == "my_checkout"
        assert any(
            "The --checkout flag has no effect" in str(w.message)
            for w in caught_warnings
            if issubclass(w.category, UserWarning)
        )

    def test_no_warning_when_starter_used_without_checkout(
        self, fake_kedro_cli, mock_determine_repo_dir, mock_cookiecutter
    ):
        """--starter without --checkout should not trigger the checkout warning.

        checkout is auto-set to the kedro version when using an official starter,
        which previously caused the warning to fire spuriously.
        """
        import warnings

        with warnings.catch_warnings(record=True) as caught_warnings:
            warnings.simplefilter("always")
            result = CliRunner().invoke(
                fake_kedro_cli,
                ["new", "--starter", "spaceflights-pandas"],
                input=_make_cli_prompt_input(),
            )
        assert result.exit_code == 0, result.output
        assert not any(
            "The --checkout flag has no effect" in str(w.message)
            for w in caught_warnings
            if issubclass(w.category, UserWarning)
        )

    def test_no_warning_when_starter_used_with_explicit_checkout(
        self, fake_kedro_cli, mock_determine_repo_dir, mock_cookiecutter
    ):
        """--starter with explicit --checkout should not trigger the checkout warning."""
        import warnings

        with warnings.catch_warnings(record=True) as caught_warnings:
            warnings.simplefilter("always")
            result = CliRunner().invoke(
                fake_kedro_cli,
                [
                    "new",
                    "--starter",
                    "spaceflights-pandas",
                    "--checkout",
                    "my_checkout",
                ],
                input=_make_cli_prompt_input(),
            )
        assert result.exit_code == 0, result.output
        assert not any(
            "The --checkout flag has no effect" in str(w.message)
            for w in caught_warnings
            if issubclass(w.category, UserWarning)
        )
