from __future__ import annotations

import configparser
import dataclasses
import json
import logging
import re
import textwrap
from pathlib import Path, PurePath, PurePosixPath, PureWindowsPath
from typing import Any
from unittest.mock import MagicMock

import pytest
import tomli_w
import yaml
from pandas.testing import assert_frame_equal
from pydantic import BaseModel

from kedro import __version__ as kedro_version
from kedro.config import MissingConfigException
from kedro.framework.context import KedroContext
from kedro.framework.context.context import (
    _convert_paths_to_absolute_posix,
    _is_relative_path,
)
from kedro.framework.hooks import _create_hook_manager
from kedro.framework.project import (
    ValidationError,
    _ProjectSettings,
    pipelines,
)
from kedro.framework.session import KedroSession
from kedro.framework.startup import bootstrap_project

MOCK_PACKAGE_NAME = "mock_package_name"


class BadCatalog:
    """
    Catalog class that doesn't subclass `DataCatalog`, for testing only.
    """


def _write_yaml(filepath: Path, config: dict):
    filepath.parent.mkdir(parents=True, exist_ok=True)
    yaml_str = yaml.dump(config)
    filepath.write_text(yaml_str)


def _write_toml(filepath: Path, config: dict):
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with filepath.open("wb") as f:
        tomli_w.dump(config, f)


def _write_json(filepath: Path, config: dict):
    filepath.parent.mkdir(parents=True, exist_ok=True)
    json_str = json.dumps(config)
    filepath.write_text(json_str)


def _write_dummy_ini(filepath: Path):
    filepath.parent.mkdir(parents=True, exist_ok=True)
    config = configparser.ConfigParser()
    config["prod"] = {"url": "postgresql://user:pass@url_prod/db"}
    config["staging"] = {"url": "postgresql://user:pass@url_staging/db"}
    with filepath.open("wt") as configfile:  # save
        config.write(configfile)


@pytest.fixture
def base_config(tmp_path):
    cars_filepath = (tmp_path / "cars.csv").as_posix()
    trains_filepath = (tmp_path / "trains.csv").as_posix()

    return {
        "trains": {"type": "pandas.CSVDataset", "filepath": trains_filepath},
        "cars": {
            "type": "pandas.CSVDataset",
            "filepath": cars_filepath,
            "save_args": {"index": True},
        },
    }


@pytest.fixture
def local_config(tmp_path):
    cars_filepath = (tmp_path / "cars.csv").as_posix()
    boats_filepath = (tmp_path / "boats.csv").as_posix()
    # use one dataset with a relative filepath
    horses_filepath = "horses.csv"
    return {
        "cars": {
            "type": "pandas.CSVDataset",
            "filepath": cars_filepath,
            "save_args": {"index": False},
            "versioned": True,
        },
        "boats": {
            "type": "pandas.CSVDataset",
            "filepath": boats_filepath,
            "versioned": True,
        },
        "horses": {
            "type": "pandas.CSVDataset",
            "filepath": horses_filepath,
            "versioned": True,
        },
    }


@pytest.fixture
def env(request):
    return getattr(request, "param", None)


@pytest.fixture
def prepare_project_dir(tmp_path, base_config, local_config, env):
    env = "local" if env is None else env
    proj_catalog = tmp_path / "conf" / "base" / "catalog.yml"
    env_catalog = tmp_path / "conf" / str(env) / "catalog.yml"
    env_credentials = tmp_path / "conf" / str(env) / "credentials.yml"
    parameters = tmp_path / "conf" / "base" / "parameters.json"
    project_parameters = {"param1": 1, "param2": 2, "param3": {"param4": 3}}

    # Create configurations
    _write_yaml(proj_catalog, base_config)
    _write_yaml(env_catalog, local_config)
    _write_yaml(env_credentials, local_config)
    _write_json(parameters, project_parameters)

    _write_toml(tmp_path / "pyproject.toml", pyproject_toml_payload)

    # Create the necessary files in src/
    (tmp_path / "src" / MOCK_PACKAGE_NAME).mkdir(parents=True, exist_ok=True)
    (tmp_path / "src" / MOCK_PACKAGE_NAME / "__init__.py").write_text(" ")


@pytest.fixture
def mock_settings_file_bad_data_catalog_class(tmpdir):
    mock_settings_file = tmpdir.join("mock_settings_file.py")
    mock_settings_file.write(
        textwrap.dedent(
            f"""
            from {__name__} import BadCatalog
            DATA_CATALOG_CLASS = BadCatalog
            """
        )
    )
    return mock_settings_file


@pytest.fixture(autouse=True)
def mock_settings(mocker):
    mocked_settings = _ProjectSettings()
    mocker.patch("kedro.framework.session.session.settings", mocked_settings)
    return mocker.patch("kedro.framework.project.settings", mocked_settings)


expected_message_middle = (
    "There are 2 nodes that have not run.\n"
    "You can resume the pipeline run by adding the following "
    "argument to your previous command:\n"
    '  --from-nodes "nodes3"'
)

expected_message_head = (
    "There are 4 nodes that have not run.\n"
    "You can resume the pipeline run by adding the following "
    "argument to your previous command:\n"
)

pyproject_toml_payload = {
    "tool": {
        "kedro": {
            "project_name": "mock_project_name",
            "kedro_init_version": kedro_version,
            "package_name": MOCK_PACKAGE_NAME,
        }
    }
}


@pytest.fixture
def runtime_params(request):
    return getattr(request, "param", None)


@pytest.fixture
def dummy_context(tmp_path, prepare_project_dir, env, runtime_params):
    bootstrap_project(tmp_path)

    session = KedroSession.create(
        project_path=tmp_path, env=env, runtime_params=runtime_params
    )
    context = session.load_context()
    config_loader = context.config_loader
    context = KedroContext(
        project_path=str(tmp_path),
        config_loader=config_loader,
        env=env,
        package_name=MOCK_PACKAGE_NAME,
        hook_manager=_create_hook_manager(),
        runtime_params=runtime_params,
    )

    yield context
    pipelines.configure()


class TestKedroContext:
    def test_attributes(self, tmp_path, dummy_context):
        assert isinstance(dummy_context.project_path, Path)
        assert dummy_context.project_path == tmp_path.resolve()

    def test_set_new_attribute(self, dummy_context):
        dummy_context.mlflow = 1
        assert dummy_context.mlflow == 1

    def test_get_catalog_always_using_absolute_path(self, dummy_context):
        config_loader = dummy_context.config_loader
        conf_catalog = config_loader["catalog"]

        # even though the raw configuration uses relative path
        assert conf_catalog["horses"]["filepath"] == "horses.csv"

        # the catalog and its dataset should be loaded using absolute path
        # based on the project path
        catalog = dummy_context._get_catalog()
        ds_path = catalog["horses"]._filepath
        assert PurePath(ds_path.as_posix()).is_absolute()
        assert (
            ds_path.as_posix() == (dummy_context.project_path / "horses.csv").as_posix()
        )

    def test_get_catalog_validates_transcoded_datasets(self, dummy_context, mocker):
        mock_transcode_split = mocker.patch(
            "kedro.framework.context.context._transcode_split"
        )
        catalog = dummy_context.catalog
        for dataset_name in catalog._datasets.keys():
            mock_transcode_split.assert_any_call(dataset_name)

        mock_validate = mocker.patch(
            "kedro.framework.context.context._validate_transcoded_datasets"
        )

        catalog = dummy_context.catalog

        mock_validate.assert_called_once_with(catalog)

    def test_catalog(self, dummy_context, dummy_dataframe):
        dummy_context.catalog.save("cars", dummy_dataframe)
        reloaded_df = dummy_context.catalog.load("cars")
        assert_frame_equal(reloaded_df, dummy_dataframe)

    def test_get_catalog_sets_validation_enabled_from_settings(self, dummy_context):
        catalog = dummy_context._get_catalog()
        assert catalog.validation_enabled is True

    def test_get_catalog_validation_disabled_via_settings(
        self, dummy_context, mock_settings
    ):
        mock_settings.set("DATASET_VALIDATION", False)
        catalog = dummy_context._get_catalog()
        assert catalog.validation_enabled is False

    def test_configure_dataset_validation_warns_for_unsupported_catalog(
        self, dummy_context, caplog
    ):
        class PlainCatalog:
            """Catalog without the validation funnel (no validation_enabled)."""

        conf_catalog = {
            "cars": {
                "type": "pandas.CSVDataset",
                "filepath": "cars.csv",
                "validator": "my_pkg.CarsSchema",
            },
            "boats": {"type": "pandas.CSVDataset", "filepath": "boats.csv"},
        }
        with caplog.at_level(logging.WARNING, logger="kedro.framework.context.context"):
            dummy_context._configure_dataset_validation(PlainCatalog(), conf_catalog)

        assert "cars" in caplog.text
        assert "boats" not in caplog.text
        assert "PlainCatalog" in caplog.text
        assert "ignored" in caplog.text

    def test_configure_dataset_validation_no_warning_when_disabled(
        self, dummy_context, mock_settings, caplog
    ):
        class PlainCatalog:
            """Catalog without the validation funnel (no validation_enabled)."""

        mock_settings.set("DATASET_VALIDATION", False)
        conf_catalog = {
            "cars": {
                "type": "pandas.CSVDataset",
                "filepath": "cars.csv",
                "validator": "my_pkg.CarsSchema",
            }
        }
        with caplog.at_level(logging.WARNING, logger="kedro.framework.context.context"):
            dummy_context._configure_dataset_validation(PlainCatalog(), conf_catalog)

        assert caplog.text == ""

    def test_configure_dataset_validation_preflight_warns_missing_package(
        self, dummy_context, caplog
    ):
        from kedro.io import DataCatalog

        catalog = DataCatalog.from_config(
            {
                "cars": {
                    "type": "pandas.CSVDataset",
                    "filepath": "cars.csv",
                    "validator": "definitely_not_installed_pkg.Schema",
                }
            }
        )
        with caplog.at_level(logging.WARNING, logger="kedro.framework.context.context"):
            dummy_context._configure_dataset_validation(catalog, {})

        assert "definitely_not_installed_pkg" in caplog.text

    def test_wrong_catalog_type(self, mock_settings_file_bad_data_catalog_class):
        pattern = (
            "Invalid value 'tests.framework.context.test_context.BadCatalog' received "
            "for setting 'DATA_CATALOG_CLASS'. "
            "It must implement 'kedro.io.core.CatalogProtocol'."
        )
        mock_settings = _ProjectSettings(
            settings_file=str(mock_settings_file_bad_data_catalog_class)
        )
        with pytest.raises(ValidationError, match=re.escape(pattern)):
            assert mock_settings.DATA_CATALOG_CLASS

    @pytest.mark.parametrize(
        "runtime_params",
        [None, {}, {"foo": "bar", "baz": [1, 2], "qux": None}],
        indirect=True,
    )
    def test_params(self, dummy_context, runtime_params):
        runtime_params = runtime_params or {}
        expected = {
            "param1": 1,
            "param2": 2,
            "param3": {"param4": 3},
            **runtime_params,
        }
        assert dummy_context.params == expected

    @pytest.mark.parametrize(
        "param,expected",
        [("params:param3", {"param4": 3}), ("params:param3.param4", 3)],
    )
    def test_nested_params(self, param, expected, dummy_context):
        param = dummy_context.catalog.load(param)
        assert param == expected

    @pytest.mark.parametrize(
        "runtime_params",
        [None, {}, {"foo": "bar", "baz": [1, 2], "qux": None}],
        indirect=True,
    )
    def test_params_missing(self, mocker, runtime_params, dummy_context):
        mock_config_loader = mocker.patch("kedro.config.OmegaConfigLoader.__getitem__")
        mock_config_loader.side_effect = MissingConfigException("nope")
        runtime_params = runtime_params or {}

        pattern = "Parameters not found in your Kedro project config"
        with pytest.warns(UserWarning, match=pattern):
            actual = dummy_context.params
        assert actual == runtime_params

    @pytest.mark.parametrize("env", ["custom_env"], indirect=True)
    def test_custom_env(self, dummy_context, env):
        assert dummy_context.env == env

    def test_missing_parameters(self, tmp_path, dummy_context):
        parameters = tmp_path / "conf" / "base" / "parameters.json"
        parameters.unlink()

        pattern = "Parameters not found in your Kedro project config."
        with pytest.warns(UserWarning, match=re.escape(pattern)):
            _ = dummy_context.catalog

    def test_missing_credentials(self, dummy_context, caplog):
        caplog.set_level(logging.DEBUG, logger="kedro")

        env_credentials = (
            dummy_context.project_path / "conf" / "local" / "credentials.yml"
        )
        env_credentials.unlink()

        _ = dummy_context.catalog

        # check the logs
        log_messages = [record.getMessage() for record in caplog.records]
        expected_msg = "Credentials not found in your Kedro project config."
        assert any(expected_msg in log_message for log_message in log_messages)

    def test_get_parameters_with_pydantic_model(self, dummy_context, mocker):
        """Verify Pydantic models are registered with nested paths preserved."""

        class ModelOptions(BaseModel):
            test_size: float
            random_state: int

        model_instance = ModelOptions(test_size=0.2, random_state=3)

        mocker.patch.object(
            dummy_context,
            "_get_validated_params",
            return_value={"model_options": model_instance},
        )

        result = dummy_context._get_parameters()

        assert result["params:model_options"] == model_instance
        assert result["params:model_options.test_size"] == 0.2
        assert result["params:model_options.random_state"] == 3

    def test_get_parameters_with_dataclass(self, dummy_context, mocker):
        """Verify dataclasses are registered with nested paths preserved."""

        @dataclasses.dataclass
        class EvalConfig:
            metric: str
            threshold: float

        dc_instance = EvalConfig(metric="rmse", threshold=0.5)

        mocker.patch.object(
            dummy_context,
            "_get_validated_params",
            return_value={"eval_config": dc_instance},
        )

        result = dummy_context._get_parameters()

        assert result["params:eval_config"] == dc_instance
        assert result["params:eval_config.metric"] == "rmse"
        assert result["params:eval_config.threshold"] == 0.5

    def test_get_parameters_with_nested_pydantic_preserves_types(
        self, dummy_context, mocker
    ):
        """Verify nested Pydantic sub-models are preserved, not flattened to dicts."""

        class InnerModel(BaseModel):
            value: int

        class OuterModel(BaseModel):
            inner: InnerModel

        outer = OuterModel(inner=InnerModel(value=42))

        mocker.patch.object(
            dummy_context,
            "_get_validated_params",
            return_value={"outer": outer},
        )

        result = dummy_context._get_parameters()

        assert result["params:outer"] == outer
        assert isinstance(result["params:outer.inner"], InnerModel)
        assert result["params:outer.inner"].value == 42
        assert result["params:outer.inner.value"] == 42

    def test_validated_params_cache(self, dummy_context):
        """Verify params are cached after first access."""
        assert dummy_context._validated_params_cache is None
        first = dummy_context.params
        assert dummy_context._validated_params_cache is not None
        second = dummy_context.params
        assert first is second

    def test_pipelines_to_validate_defaults_to_none(self, dummy_context):
        """``_pipelines_to_validate`` defaults to ``None`` (validate every
        registered pipeline)."""
        assert dummy_context._pipelines_to_validate is None

    def test_get_validated_params_scoped_to_set_pipelines(self, dummy_context, mocker):
        """When ``_pipelines_to_validate`` is set, only those pipelines are
        forwarded to ``ParameterValidator``."""
        from kedro.framework import project

        fake_pipeline_a = MagicMock()
        fake_pipeline_a.nodes = []
        fake_pipeline_b = MagicMock()
        fake_pipeline_b.nodes = []
        # Bypass the lazy registry load by populating ``_content`` directly;
        # ``mocker.patch.dict`` would itself trigger ``_load_data``.
        mocker.patch.object(
            project.pipelines,
            "_content",
            {
                "data_science": fake_pipeline_a,
                "data_engineering": fake_pipeline_b,
                "other": MagicMock(),
            },
        )
        mocker.patch.object(project.pipelines, "_is_data_loaded", True)
        validator_cls = mocker.patch(
            "kedro.validation.parameter_validator.ParameterValidator"
        )
        validator_cls.return_value.validate_raw_params.return_value = {"foo": "bar"}

        dummy_context._pipelines_to_validate = ["data_science", "data_engineering"]
        result = dummy_context._get_validated_params()

        assert result == {"foo": "bar"}
        # Validator was constructed with only the requested pipelines —
        # ``other`` is excluded even though it is registered.
        validator_cls.assert_called_once_with(
            {
                "data_science": fake_pipeline_a,
                "data_engineering": fake_pipeline_b,
            }
        )

    def test_cache_invalidates_when_scope_changes(self, dummy_context, mocker):
        """A cached unscoped read (e.g. from an ``after_context_created``
        hook reading ``context.params``) must not be reused once the session
        sets ``_pipelines_to_validate``."""
        from kedro.framework import project

        scoped_pipeline = MagicMock()
        scoped_pipeline.nodes = []
        mocker.patch.object(
            project.pipelines, "_content", {"data_science": scoped_pipeline}
        )
        mocker.patch.object(project.pipelines, "_is_data_loaded", True)
        validator_cls = mocker.patch(
            "kedro.validation.parameter_validator.ParameterValidator"
        )
        validator_cls.return_value.validate_raw_params.side_effect = [
            {"unscoped": True},
            {"scoped": True},
        ]

        # 1) Unscoped read (simulating a hook touching ``context.params``).
        first = dummy_context._get_validated_params()
        assert first == {"unscoped": True}

        # 2) Session sets the scope and re-reads — the cache from (1) must
        # not be returned.
        dummy_context._pipelines_to_validate = ["data_science"]
        second = dummy_context._get_validated_params()
        assert second == {"scoped": True}
        assert validator_cls.return_value.validate_raw_params.call_count == 2


@pytest.mark.parametrize(
    "path_string,expected",
    [
        # remote paths shouldn't be relative paths
        ("s3://", False),
        ("gcp://path/to/file.json", False),
        # windows absolute path shouldn't relative paths
        ("C:\\path\\to\\file.json", False),
        ("C:", False),
        ("C:/Windows/", False),
        # posix absolute path shouldn't be relative paths
        ("/tmp/logs/info.log", False),
        ("/usr/share", False),
        # test relative paths
        ("data/01_raw/data.json", True),
        ("logs/info.log", True),
        ("logs\\error.txt", True),
        ("data", True),
    ],
)
def test_is_relative_path(path_string: str, expected: bool):
    assert _is_relative_path(path_string) == expected


def test_convert_paths_raises_error_on_relative_project_path():
    path = Path("relative") / "path"

    pattern = f"project_path must be an absolute path. Received: {path}"
    with pytest.raises(ValueError, match=re.escape(pattern)):
        _convert_paths_to_absolute_posix(project_path=path, conf_dictionary={})


@pytest.mark.parametrize(
    "project_path,input_conf,expected",
    [
        (
            PurePosixPath("/tmp"),
            {"handler": {"filename": "logs/info.log"}},
            {"handler": {"filename": "/tmp/logs/info.log"}},
        ),
        (
            PurePosixPath("/User/kedro"),
            {"my_dataset": {"filepath": "data/01_raw/dataset.json"}},
            {"my_dataset": {"filepath": "/User/kedro/data/01_raw/dataset.json"}},
        ),
        (
            PureWindowsPath("C:\\kedro"),
            {"my_dataset": {"path": "data/01_raw/dataset.json"}},
            {"my_dataset": {"path": "C:/kedro/data/01_raw/dataset.json"}},
        ),
        # test: the function shouldn't modify paths for key not associated with filepath
        (
            PurePosixPath("/User/kedro"),
            {"my_dataset": {"fileurl": "relative/url"}},
            {"my_dataset": {"fileurl": "relative/url"}},
        ),
    ],
)
def test_convert_paths_to_absolute_posix_for_all_known_filepath_keys(
    project_path: Path, input_conf: dict[str, Any], expected: dict[str, Any]
):
    assert _convert_paths_to_absolute_posix(project_path, input_conf) == expected


@pytest.mark.parametrize(
    "project_path,input_conf,expected",
    [
        (
            PurePosixPath("/tmp"),
            {"handler": {"filename": "/usr/local/logs/info.log"}},
            {"handler": {"filename": "/usr/local/logs/info.log"}},
        ),
        (
            PurePosixPath("/User/kedro"),
            {"my_dataset": {"filepath": "s3://data/01_raw/dataset.json"}},
            {"my_dataset": {"filepath": "s3://data/01_raw/dataset.json"}},
        ),
    ],
)
def test_convert_paths_to_absolute_posix_not_changing_non_relative_path(
    project_path: Path, input_conf: dict[str, Any], expected: dict[str, Any]
):
    assert _convert_paths_to_absolute_posix(project_path, input_conf) == expected


@pytest.mark.parametrize(
    "project_path,input_conf,expected",
    [
        (
            PureWindowsPath("D:\\kedro"),
            {"my_dataset": {"path": r"C:\data\01_raw\dataset.json"}},
            {"my_dataset": {"path": "C:/data/01_raw/dataset.json"}},
        )
    ],
)
def test_convert_paths_to_absolute_posix_converts_full_windows_path_to_posix(
    project_path: Path, input_conf: dict[str, Any], expected: dict[str, Any]
):
    assert _convert_paths_to_absolute_posix(project_path, input_conf) == expected
