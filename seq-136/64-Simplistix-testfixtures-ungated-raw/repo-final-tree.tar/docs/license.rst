=======
License
=======

.. literalinclude:: ../LICENSE.txt
