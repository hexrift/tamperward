class singleton:

    def __init__(self, name: str) -> None:
        self.name = name

    def __repr__(self) -> str:
        return '<%s>' % self.name

    __str__ = __repr__


not_there: singleton = singleton('not_there')


from testfixtures.comparers import diff, safe_pformat, safe_repr
from testfixtures.comparing import compare, register
from testfixtures.comparison import (
    Comparison, TextComparison, StringComparison, RoundComparison,
    RangeComparison, ReprComparison, StrComparison, SequenceComparison, Subset,
    Permutation, MappingComparison, like, repr_like, str_like, sequence,
    contains, unordered, mapping
)
from testfixtures.command import Command, Run
from testfixtures.datetime import mock_datetime, mock_date, mock_time
from testfixtures.logcapture import LogCapture, log_capture, LoggingSource
from testfixtures.outputcapture import OutputCapture
from testfixtures.resolve import resolve
from testfixtures.replace import (
    Replacer,
    Replace,
    replace,
    replace_in_environ,
    replace_on_class,
    replace_in_module,
)
from testfixtures.shouldraise import ShouldRaise, should_raise, ShouldAssert
from testfixtures.shouldwarn import ShouldWarn, ShouldNotWarn
from testfixtures.tempdirectory import TempDir, TempDirectory, tempdir
from testfixtures.utils import wrap, generator


# backwards compatibility for the old names
test_datetime = mock_datetime
test_datetime.__test__ = False  # type: ignore[attr-defined]
test_date = mock_date
test_date.__test__ = False  # type: ignore[attr-defined]
test_time = mock_time
test_time.__test__ = False  # type: ignore[attr-defined]

__all__ = [
    'Command',
    'Comparison',
    'LogCapture',
    'LoggingSource',
    'MappingComparison',
    'OutputCapture',
    'Permutation',
    'RangeComparison',
    'ReprComparison',
    'Replace',
    'Replacer',
    'Run',
    'RoundComparison',
    'SequenceComparison',
    'ShouldAssert',
    'ShouldRaise',
    'ShouldNotWarn',
    'ShouldWarn',
    'Subset',
    'StrComparison',
    'StringComparison',
    'TextComparison',
    'TempDirectory',
    'TempDir',
    'compare',
    'contains',
    'diff',
    'generator',
    'like',
    'log_capture',
    'mapping',
    'mock_date',
    'mock_datetime',
    'mock_time',
    'not_there',
    'register',
    'replace',
    'replace_in_environ',
    'replace_on_class',
    'replace_in_module',
    'repr_like',
    'resolve',
    'safe_pformat',
    'safe_repr',
    'sequence',
    'should_raise',
    'singleton',
    'str_like',
    'tempdir',
    'test_date',
    'test_datetime',
    'test_time',
    'unordered',
    'wrap',
]
