from typing import Literal

from pydantic import Field

from .base_model import BaseModel


class FragmentWithSingleField(BaseModel):
    query_unwrap_fragment: "FragmentWithSingleFieldQueryUnwrapFragment" = Field(
        alias="queryUnwrapFragment"
    )


class FragmentWithSingleFieldQueryUnwrapFragment(BaseModel):
    id: int


class ListAnimalsFragment(BaseModel):
    list_animals: list["ListAnimalsFragmentListAnimals"] = Field(alias="listAnimals")


class ListAnimalsFragmentListAnimals(BaseModel):
    typename__: Literal["Animal", "Cat", "Dog"] = Field(alias="__typename")
    name: str


FragmentWithSingleField.model_rebuild()
ListAnimalsFragment.model_rebuild()
