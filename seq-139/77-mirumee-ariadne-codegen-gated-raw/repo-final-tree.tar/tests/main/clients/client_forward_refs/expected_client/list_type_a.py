from typing import Optional

from pydantic import Field

from .base_model import BaseModel


class ListTypeA(BaseModel):
    list_optional_type_a: list[Optional["ListTypeAListOptionalTypeA"]] = Field(
        alias="listOptionalTypeA"
    )


class ListTypeAListOptionalTypeA(BaseModel):
    id: int


ListTypeA.model_rebuild()
