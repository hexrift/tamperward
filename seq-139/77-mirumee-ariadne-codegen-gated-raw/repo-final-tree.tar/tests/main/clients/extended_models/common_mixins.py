class CommonMixin:
    pass
