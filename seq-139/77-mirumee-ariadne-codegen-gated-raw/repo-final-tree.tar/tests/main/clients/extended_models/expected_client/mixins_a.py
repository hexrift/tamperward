class MixinA:
    pass
