class MixinB:
    pass
