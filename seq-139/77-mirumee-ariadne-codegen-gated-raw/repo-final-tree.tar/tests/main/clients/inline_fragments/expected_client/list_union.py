from typing import Annotated, Literal, Union

from pydantic import Field

from .base_model import BaseModel


class ListUnion(BaseModel):
    query_list_u: list[
        Annotated[
            Union[
                "ListUnionQueryListUTypeA",
                "ListUnionQueryListUTypeB",
                "ListUnionQueryListUTypeC",
            ],
            Field(discriminator="typename__"),
        ]
    ] = Field(alias="queryListU")


class ListUnionQueryListUTypeA(BaseModel):
    typename__: Literal["TypeA"] = Field(alias="__typename")
    id: str
    field_a: str = Field(alias="fieldA")


class ListUnionQueryListUTypeB(BaseModel):
    typename__: Literal["TypeB"] = Field(alias="__typename")
    id: str
    field_b: str = Field(alias="fieldB")


class ListUnionQueryListUTypeC(BaseModel):
    typename__: Literal["TypeC"] = Field(alias="__typename")


ListUnion.model_rebuild()
