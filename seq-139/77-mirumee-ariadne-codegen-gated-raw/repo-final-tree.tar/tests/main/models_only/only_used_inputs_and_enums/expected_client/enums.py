from enum import Enum


class EnumE(str, Enum):
    E1 = "E1"
    E2 = "E2"


class EnumEE(str, Enum):
    EE1 = "EE1"
    EE2 = "EE2"


class EnumF(str, Enum):
    F1 = "F1"
    F2 = "F2"


class EnumG(str, Enum):
    G1 = "G1"
    G2 = "G2"


class EnumGG(str, Enum):
    GG1 = "GG1"
    GG2 = "GG2"
