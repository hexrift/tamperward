from typing import Optional

from pydantic import Field

from .base_model import BaseModel
from .enums import EnumE, EnumEE


class InputA(BaseModel):
    value_aa: "InputAA" = Field(alias="valueAA")
    value_ab: Optional["InputAB"] = Field(alias="valueAB", default=None)


class InputAA(BaseModel):
    value_aaa: "InputAAA" = Field(alias="valueAAA")


class InputAAA(BaseModel):
    val: str


class InputAB(BaseModel):
    val: str
    value_a: Optional["InputA"] = Field(alias="valueA", default=None)


class InputX(BaseModel):
    value_y: Optional["InputY"] = Field(alias="valueY", default=None)


class InputY(BaseModel):
    value_z: Optional["InputZ"] = Field(alias="valueZ", default=None)


class InputZ(BaseModel):
    val: Optional[str] = None


class InputE(BaseModel):
    val: EnumE


class InputEE(BaseModel):
    val: EnumEE


InputA.model_rebuild()
InputAA.model_rebuild()
InputAB.model_rebuild()
InputX.model_rebuild()
InputY.model_rebuild()
