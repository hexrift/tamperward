import os

from .utils import is_interactive_session, is_stdout_only_session

_FORCE = os.environ.get("TQDM_LOGGABLE_FORCE")

if _FORCE == "stdout":
    from tqdm import tqdm
    INTERACTIVE_TQDM = False
elif _FORCE == "interactive":
    from tqdm.auto import tqdm
    INTERACTIVE_TQDM = True
elif _FORCE == "logging":
    from .tqdm_logging import tqdm_logging as tqdm
    INTERACTIVE_TQDM = False
elif is_interactive_session() and not is_stdout_only_session():
    from tqdm.auto import tqdm
    INTERACTIVE_TQDM = True
elif is_stdout_only_session():
    from tqdm import tqdm
    INTERACTIVE_TQDM = False
else:
    from .tqdm_logging import tqdm_logging as tqdm
    INTERACTIVE_TQDM = False

__all__ = ["tqdm"]