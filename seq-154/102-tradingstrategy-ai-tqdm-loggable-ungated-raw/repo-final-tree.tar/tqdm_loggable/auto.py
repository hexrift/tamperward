import os

from .utils import is_interactive_session, is_stdout_only_session

_FORCE_MODE = os.environ.get("TQDM_LOGGABLE_FORCE", None)

if _FORCE_MODE == "stdout":
    from tqdm import tqdm
    INTERACTIVE_TQDM = False
elif _FORCE_MODE == "notebook":
    from tqdm.auto import tqdm
    INTERACTIVE_TQDM = True
elif _FORCE_MODE == "logging":
    from .tqdm_logging import tqdm_logging as tqdm
    INTERACTIVE_TQDM = False
elif is_interactive_session() and not is_stdout_only_session():
    from tqdm.auto import tqdm
    INTERACTIVE_TQDM = True
elif is_stdout_only_session():
    from tqdm import tqdm
    INTERACTIVE_TQDM = False
else:
    from .tqdm_logging import tqdm_logging as tqdm
    INTERACTIVE_TQDM = False

__all__ = ["tqdm"]