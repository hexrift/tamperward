import os
import sys

import pytest


TESTS_DIR = os.path.abspath(os.path.dirname(__file__))
SRC_DIR = os.path.abspath(os.path.join(TESTS_DIR, '..', 'src'))
for d in (SRC_DIR, TESTS_DIR):
    if d not in sys.path:
        sys.path.insert(0, d)

from mkdocs_include_markdown_plugin import IncludeMarkdownPlugin  # noqa: E402


@pytest.fixture(autouse=True)
def _isolated_home(tmp_path_factory, monkeypatch):
    """Redirect platformdirs' cache/data lookups away from the real home dir.

    Tests that exercise the default (unconfigured) cache directory must
    not depend on `$HOME` being writable on the machine running the suite.
    """
    home = tmp_path_factory.mktemp('home')
    monkeypatch.setenv('HOME', str(home))
    monkeypatch.setenv('XDG_DATA_HOME', str(home / '.local' / 'share'))
    monkeypatch.setenv('XDG_CACHE_HOME', str(home / '.cache'))


@pytest.fixture
def page():
    """Fake mkdocs page object."""
    def _page(file_path):
        return type(
            'FakeMkdocsPage', (), {
                'file': type(
                    'FakeMdocsPageFile', (), {
                        'abs_src_path': file_path,
                    },
                ),
            },
        )
    return _page


@pytest.fixture
def plugin(request):
    """Populate a plugin, with optional indirect config parameter."""
    plugin = IncludeMarkdownPlugin()
    errors, warnings = plugin.load_config(getattr(request, 'param', {}))
    assert errors == []
    assert warnings == []
    return plugin
