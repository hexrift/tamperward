import os
import socket
import sys

import pytest


TESTS_DIR = os.path.abspath(os.path.dirname(__file__))
SRC_DIR = os.path.abspath(os.path.join(TESTS_DIR, '..', 'src'))
for d in (SRC_DIR, TESTS_DIR):
    if d not in sys.path:
        sys.path.insert(0, d)

from mkdocs_include_markdown_plugin import IncludeMarkdownPlugin  # noqa: E402


def _network_available() -> bool:
    try:
        socket.create_connection(
            ('raw.githubusercontent.com', 443), timeout=3,
        ).close()
        return True
    except OSError:
        return False


HAS_NETWORK = _network_available()

requires_network = pytest.mark.skipif(
    not HAS_NETWORK, reason='requires network access',
)


@pytest.fixture(autouse=True)
def _isolated_home(tmp_path, monkeypatch):
    """Redirect HOME/XDG dirs so tests never touch the real user cache."""
    monkeypatch.setenv('HOME', str(tmp_path))
    monkeypatch.setenv('XDG_CACHE_HOME', str(tmp_path / '.cache'))
    monkeypatch.setenv('XDG_DATA_HOME', str(tmp_path / '.local' / 'share'))


@pytest.fixture
def page():
    """Fake mkdocs page object."""
    def _page(file_path):
        return type(
            'FakeMkdocsPage', (), {
                'file': type(
                    'FakeMdocsPageFile', (), {
                        'abs_src_path': file_path,
                    },
                ),
            },
        )
    return _page


@pytest.fixture
def plugin(request):
    """Populate a plugin, with optional indirect config parameter."""
    plugin = IncludeMarkdownPlugin()
    errors, warnings = plugin.load_config(getattr(request, 'param', {}))
    assert errors == []
    assert warnings == []
    return plugin
