<!--
Thank you for contributing! If you enjoy this project, please consider:
- ⭐ Starring it on GitHub: https://github.com/mauvilsa/jsonargparse
- 🩷 Sponsoring it: https://github.com/sponsors/mauvilsa

Even small donations are greatly appreciated and help sustain the project.
-->

<!--
Note: it is fine to create a pull request without the need to have a
corresponding issue. In fact, if the issue would describe essentially the same
as the pull request, please don't create an issue to avoid duplication.
-->

## What does this PR do?

<!--
Concisely describe what this pull request does. If available, include links to
issues web pages where the need for this change has been motivated. If you
opted for creating a pull request without an issue, still have a look at the
issue templates to include more information depending on the type.
-->

## Before submitting

<!--
Use the following list as tasks to be completed before marking a pull request as
"Ready for review". Fill with an "x" all tasks done. Use "n/a" if you think a
task is not relevant or leave empty when in doubt.
-->

- [ ] Did you read the [contributing guideline](https://github.com/mauvilsa/jsonargparse/blob/main/CONTRIBUTING.rst)?
- [ ] If you used a **coding agent**, did you fully understand and validate all generated code and ensure it follows the contributing guidelines?
- [ ] Did you update **the documentation**? (readme and public docstrings)
- [ ] Did you write **unit tests** such that there is 100% coverage on related code? (required for bug fixes and new features)
- [ ] Did you verify that new and existing **tests pass locally**?
- [ ] If this is a **bug fix**, did you verify that the **tests fail without the code fix**?
- [ ] Did you make sure that all changes preserve **backward compatibility**?
- [ ] Did you update **the CHANGELOG** including a pull request link? (not for typos, docs, test updates, or minor internal changes/refactors)
