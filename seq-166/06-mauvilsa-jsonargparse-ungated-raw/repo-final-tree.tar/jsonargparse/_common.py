import abc
import argparse
import dataclasses
import inspect
import logging
import os
from collections.abc import Callable
from contextlib import contextmanager
from contextvars import ContextVar
from typing import (  # type: ignore[attr-defined]
    Generic,
    Protocol,
    TypeVar,
    _GenericAlias,
)

from ._namespace import Namespace
from ._optionals import (
    _set_config_read_mode,
    _set_docstring_parse_options,
    capture_typing_extension_shadows,
    get_alias_target,
    get_annotated_base_type,
    get_new_type_supertype,
    is_alias_type,
    is_annotated,
    is_attrs_class,
    is_literal_string,
    is_new_type,
    is_pydantic_model,
    typing_extensions_import,
)
from ._type_checking import ActionsContainer, ArgumentParser, docstring_parser

__all__ = [
    "Unset",
    "set_parsing_settings",
]

ClassType = TypeVar("ClassType")

_UnpackGenericAlias = typing_extensions_import("_UnpackAlias")

unpack_meta_types = set()
if _UnpackGenericAlias:
    unpack_meta_types.add(_UnpackGenericAlias)
capture_typing_extension_shadows(_UnpackGenericAlias, "_UnpackGenericAlias", unpack_meta_types)


class _UnsetType:
    """Sentinel class for unset argument values."""

    _instance = None
    _SERIALIZED = "==UNSET=="

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __repr__(self):
        return "Unset"

    def __bool__(self):
        return False


Unset = _UnsetType()


class InstantiatorCallable(Protocol):
    def __call__(self, class_type: type[ClassType], *args, **kwargs) -> ClassType:
        pass  # pragma: no cover


InstantiatorsDictType = dict[tuple[type, bool], InstantiatorCallable]


parent_parser: ContextVar[ArgumentParser | None] = ContextVar("parent_parser", default=None)
parser_capture: ContextVar[bool] = ContextVar("parser_capture", default=False)
defaults_cache: ContextVar[Namespace | None] = ContextVar("defaults_cache", default=None)
lenient_check: ContextVar[bool | str] = ContextVar("lenient_check", default=False)
parsing_defaults: ContextVar[bool] = ContextVar("parsing_defaults", default=False)
single_subcommand: ContextVar[bool] = ContextVar("single_subcommand", default=True)
validating_defaults: ContextVar[bool] = ContextVar("validating_defaults", default=False)
load_value_mode: ContextVar[str | None] = ContextVar("load_value_mode", default=None)
class_instantiators: ContextVar[InstantiatorsDictType | None] = ContextVar("class_instantiators", default=None)
nested_links: ContextVar[list[dict]] = ContextVar("nested_links", default=[])
applied_instantiation_links: ContextVar[set | None] = ContextVar("applied_instantiation_links", default=None)
path_dump_preserve_relative: ContextVar[bool] = ContextVar("path_dump_preserve_relative", default=False)


parser_context_vars = {
    "parent_parser": parent_parser,
    "parser_capture": parser_capture,
    "defaults_cache": defaults_cache,
    "lenient_check": lenient_check,
    "parsing_defaults": parsing_defaults,
    "single_subcommand": single_subcommand,
    "validating_defaults": validating_defaults,
    "load_value_mode": load_value_mode,
    "class_instantiators": class_instantiators,
    "nested_links": nested_links,
    "applied_instantiation_links": applied_instantiation_links,
    "path_dump_preserve_relative": path_dump_preserve_relative,
}


@contextmanager
def parser_context(**kwargs):
    context_var_tokens = []
    for name, value in kwargs.items():
        context_var = parser_context_vars[name]
        token = context_var.set(value)
        context_var_tokens.append((context_var, token))
    try:
        yield
    finally:
        for context_var, token in context_var_tokens:
            context_var.reset(token)


class ImportDenied(ImportError, ValueError):
    """Raised when an import path given as a value is not allowed.

    Both bases are needed so that the existing handlers report it as a parsing
    error: subclass specs catch ``ImportError`` and typehint checking catches
    ``ValueError``.
    """


# Import paths denied by default. Only checked for paths that come from parsed
# values, i.e. class paths, callables, types and modules given in configs, the
# command line or environment variables. Paths that come from code, e.g. type
# annotations and defaults, are never checked. Groups from higher to lower risk.
# Entries such as posix and _pickle are the C implementations that objects are
# defined in, e.g. os.system is defined in posix. They are next to the module
# that exposes them and both are needed, since a pure Python implementation is
# used when the C one is unavailable.
default_import_path_denylist = (
    # Policy self-modification. Naming jsonargparse itself would give a value a
    # way to change the settings that decide what values are allowed, which is
    # why it is also not accepted in import_path_allowlist.
    "jsonargparse",
    # Command and code execution. Instantiation is the execution, so a class
    # path plus init_args suffices to run arbitrary code or shell commands.
    "builtins.eval",
    "builtins.exec",
    "builtins.compile",
    "builtins.__import__",
    "os",
    "posix",
    "nt",
    "subprocess",
    "_posixsubprocess",
    "_winapi",
    "multiprocessing",
    "_multiprocessing",
    "ctypes",
    "_ctypes",
    "runpy",
    "code",
    "codeop",
    "pty",
    "timeit",
    "pdb",
    "bdb",
    "builtins.breakpoint",
    "trace",
    "cProfile",
    "profile",
    "doctest",
    # Untrusted deserialization. Loading attacker influenced bytes is execution,
    # and only a loader plus a file path is needed, not the payload itself.
    "pickle",
    "_pickle",
    "marshal",
    "shelve",
    "dbm",
    # Import machinery and package installation. Resolve or install code by name
    # at runtime, which would reopen everything the other groups deny.
    "importlib",
    "_frozen_importlib",
    "_frozen_importlib_external",
    "_imp",
    "pkgutil",
    "zipimport",
    "pydoc",
    "builtins.help",
    "unittest",
    "sys",
    "site",
    "pip",
    "pkg_resources",
    "setuptools",
    "distutils",
    "venv",
    "ensurepip",
    "sysconfig",
    # Callable adapters and reflection. Wrap or synthesize a callable so that the
    # call happens later in code that receives it, where no type check applies.
    "functools",
    "_functools",
    "operator",
    "_operator",
    "inspect",
    "types",
    "ast",
    "py_compile",
    "compileall",
    "builtins.getattr",
    "builtins.setattr",
    "builtins.delattr",
    "builtins.vars",
    "builtins.globals",
    # Filesystem and process lifetime. Destructive or disruptive instead of
    # executing, e.g. deleting trees, signals or deferring a call to exit.
    "shutil",
    "tempfile",
    "pathlib",
    "signal",
    "_signal",
    "atexit",
    "gc",
    "resource",
    "faulthandler",
    "builtins.exit",
    "builtins.quit",
    "_sitebuiltins",
    # File access. Opening a path for writing truncates or creates it, and the
    # archive and database openers do the same, so only a path is needed to
    # destroy or plant a file, not any payload. builtins.open and the io classes
    # are the primitives, the rest wrap them.
    "builtins.open",
    "codecs.open",
    "io",
    "_io",
    "fileinput",
    "mmap",
    "fcntl",
    "gzip",
    "bz2",
    "lzma",
    "zipfile",
    "tarfile",
    "sqlite3",
    "_sqlite3",
    "logging.config",
    "logging.handlers",
    "logging.FileHandler",
    "winreg",
    # Network and external launch. Exfiltration primitives and launching an
    # external program with an argument that the config decides. The client and
    # server modules connect or listen with a destination the config decides.
    "socket",
    "_socket",
    "ssl",
    "webbrowser",
    "antigravity",
    "asyncio",
    "urllib",
    "http",
    "ftplib",
    "smtplib",
    "poplib",
    "imaplib",
    "nntplib",
    "telnetlib",
    "socketserver",
    "xml",
    "xmlrpc",
    "wsgiref",
)


# key that configs may have to point to a JSON Schema, only for editor support, so ignored when parsing
config_schema_key = "$schema"


parsing_settings: dict = {
    "validate_defaults": False,
    "validate_subclass_spec_in_any": False,
    "instantiate_subclass_spec_in_any": None,  # v5.0.0: change default to False
    "parse_optionals_as_positionals": False,
    "add_print_completion_argument": False,
    "stubs_resolver_allow_py_files": False,
    "omegaconf_absolute_to_relative_paths": False,
    "unset_sentinel": None,
    "import_path_verdicts": {entry: False for entry in default_import_path_denylist},
    "import_paths_enforced": False,  # v5.0.0: change default to True
}


def get_settings_logger() -> logging.Logger:
    """Returns the logger for parsing settings, which being global have no parser to take one from."""
    return parse_logger({"level": "DEBUG"} if debug_mode_active() else False, "set_parsing_settings")


def set_import_path_verdicts(denylist: list[str] | None, allowlist: list[str] | None) -> None:
    """Adds entries to the import path policy, allowlist taking precedence."""
    logger = get_settings_logger()
    verdicts = dict(parsing_settings["import_path_verdicts"])
    for entries, allowed in [(denylist, False), (allowlist, True)]:
        state = "allowed" if allowed else "denied"
        for entry in entries or []:
            if entry == "*" and allowed:
                raise ValueError("'*' is only accepted in import_path_denylist, to deny all not allowed paths.")
            if not isinstance(entry, str) or (entry != "*" and not all(p.isidentifier() for p in entry.split("."))):
                raise ValueError(f"Expected import path entries to be dot import paths or '*', but got {entry!r}.")
            if allowed and (entry == "jsonargparse" or entry.startswith("jsonargparse.")):
                raise ValueError(
                    "Import paths under 'jsonargparse' can't be allowed, since a value that names them "
                    "would be able to change the import path policy itself."
                )
            previous = verdicts.get(entry)
            verdicts[entry] = allowed
            if previous is None:
                logger.debug(f"Import path {entry!r} added as {state}")
            elif previous == allowed:
                logger.debug(f"Import path {entry!r} already {state}")
            else:
                logger.debug(f"Import path {entry!r} changed to {state}")
    parsing_settings["import_path_verdicts"] = verdicts
    parsing_settings["import_paths_enforced"] = True


def denying_import_path_entry(path: str) -> str | None:
    """Returns the most specific entry that denies an import path, if any."""
    verdicts = get_parsing_setting("import_path_verdicts")
    parts = path.split(".")
    for num in range(len(parts), 0, -1):
        entry = ".".join(parts[:num])
        if entry in verdicts:
            return None if verdicts[entry] else entry
    return "*" if "*" in verdicts else None  # '*' is only accepted as a denylist entry


def check_import_path(path: str) -> None:
    """Fails or warns when an import path given as a value is denied."""
    entry = denying_import_path_entry(path)
    if entry is None:
        return
    message = (
        f"Importing '{path}' is not allowed, denied by the {entry!r} entry of the import path denylist. "
        "Add the import path to import_path_allowlist in set_parsing_settings to allow it."
    )
    if get_parsing_setting("import_paths_enforced"):
        raise ImportDenied(message)
    from ._deprecated import import_paths_not_enforced

    import_paths_not_enforced(path, message)


def get_env_var_bool(name: str) -> bool:
    raw_value = os.getenv(name, "")
    value = raw_value.lower()
    if value not in {"true", "false", ""}:
        raise ValueError(f"Invalid boolean value for environment variable {name}: {raw_value}")
    return value == "true"


def set_parsing_settings(
    *,
    validate_defaults: bool | None = None,
    validate_subclass_spec_in_any: bool | None = None,
    instantiate_subclass_spec_in_any: bool | None = None,
    config_read_mode_urls_enabled: bool | None = None,
    config_read_mode_fsspec_enabled: bool | None = None,
    docstring_parse_style: "docstring_parser.DocstringStyle | None" = None,
    docstring_parse_attribute_docstrings: bool | None = None,
    parse_optionals_as_positionals: bool | None = None,
    add_print_completion_argument: bool | None = None,
    stubs_resolver_allow_py_files: bool | None = None,
    omegaconf_absolute_to_relative_paths: bool | None = None,
    unset_sentinel: bool | None = None,
    subclasses_disabled: list[type | Callable[[type], bool]] | None = None,
    subclasses_enabled: list[type | str] | None = None,
    import_path_denylist: list[str] | None = None,
    import_path_allowlist: list[str] | None = None,
) -> None:
    """
    Modify global parser settings that affect parser creation and parsing behavior.

    Args:
        validate_defaults: Whether default values must be valid according to the
            argument type. The default is ``False``, meaning no default
            validation, like in argparse.
        validate_subclass_spec_in_any: If ``True``, when a value for a type that
            accepts any value, i.e. ``Any``, ``object``, ``Unvalidated<...>`` or
            a dict that doesn't validate its values, looks like a subclass spec
            (i.e. a dict with a ``class_path`` key), it is required to be a
            valid one, otherwise the parsing fails. For dicts the spec is only
            validated, since the value is kept as a dict. By default, this is
            ``False``, meaning that an invalid subclass spec is ignored (a debug
            log is emitted) and the original value is kept.
        instantiate_subclass_spec_in_any: Whether ``instantiate`` builds the
            class when a value for a type that accepts any value, i.e. ``Any``,
            ``object`` or ``Unvalidated<...>``, is a valid subclass spec. If
            ``False``, the value is kept as a subclass spec, which the code that
            receives it can instantiate itself if desired. Currently the default
            is ``True`` and a deprecation warning is emitted, since from v5.0.0
            the default will be ``False``. Enabling it is discouraged because it
            means that any class can be instantiated, so only do it for trusted
            configs.
        config_read_mode_urls_enabled: Whether to read config files from URLs
            using requests package. Default is ``False``.
        config_read_mode_fsspec_enabled: Whether to read config files from
            fsspec supported file systems. Default is ``False``.
        docstring_parse_style: The docstring style to expect. Default is
            ``DocstringStyle.AUTO``.
        docstring_parse_attribute_docstrings: Whether to parse attribute
            docstrings (slower). Default is ``False``.
        parse_optionals_as_positionals: If ``True``, the parser will take extra
            positional command line arguments as values for optional arguments.
            This means that optional arguments can be given by name
            ``--key=value`` as usual, but also as positional. The extra
            positionals are applied to optionals in the order that they were
            added to the parser. By default, this is ``False``.
        add_print_completion_argument: If ``True``, top-level parsers
            automatically include a ``--print_completion`` argument. Its
            accepted values are ``jsonschema`` and, when ``shtab`` is installed,
            one ``shtab-*`` value per supported shell.
        stubs_resolver_allow_py_files: Whether the stubs resolver should search
            in ``.py`` files in addition to ``.pyi`` files.
        omegaconf_absolute_to_relative_paths: If ``True``, when loading configs
            with ``omegaconf+`` parser mode, absolute interpolation paths are
            converted to relative. This is only intended for backward
            compatibility with ``omegaconf`` parser mode.
        unset_sentinel: If ``True``, parsers will use the :obj:`.Unset` sentinel
            for arguments that have not been given a value (instead of
            ``None``). This allows distinguishing between ``None`` as an
            explicitly given value and an argument that was not provided at
            all. If ``False``, uses ``None`` (the default, argparse-compatible
            behavior) unless overridden by ``argument_default``.
        subclasses_disabled: List of types or functions, so that when parsing
            only the exact type hints (not their subclasses) are accepted.
            Descendants of the configured types are also disabled. Functions
            should return ``True`` for types to disable.
        subclasses_enabled: List of types or disable function names, so that
            subclasses are accepted. Types given here have precedence over those
            in ``subclasses_disabled``. Giving a function name removes the
            corresponding function from ``subclasses_disabled``. By default, the
            following disable functions are registered: ``is_pure_dataclass``,
            ``is_pydantic_model``, ``is_attrs_class`` and ``is_final_class``.
        import_path_denylist: Import paths that a value is not allowed to name,
            added to the ones denied by default. An entry denies a dot import
            path and everything under it, e.g. ``os`` also denies ``os.system``.
            The entry ``*`` denies everything, so that only what the allowlist
            permits is importable.
        import_path_allowlist: Import paths that a value is allowed to name,
            taking precedence over the denylist for the same entry. The most
            specific entry decides, so ``functools.partial`` here allows only
            that path out of a denied ``functools``. Paths under ``jsonargparse``
            are not accepted, since a value that names them would be able to
            change these settings.
    """
    # validate_defaults
    if isinstance(validate_defaults, bool):
        parsing_settings["validate_defaults"] = validate_defaults
    elif validate_defaults is not None:
        raise ValueError(f"validate_defaults must be a boolean, but got {validate_defaults}.")
    # validate_subclass_spec_in_any
    if isinstance(validate_subclass_spec_in_any, bool):
        parsing_settings["validate_subclass_spec_in_any"] = validate_subclass_spec_in_any
    elif validate_subclass_spec_in_any is not None:
        raise ValueError(f"validate_subclass_spec_in_any must be a boolean, but got {validate_subclass_spec_in_any}.")
    # instantiate_subclass_spec_in_any
    if isinstance(instantiate_subclass_spec_in_any, bool):
        parsing_settings["instantiate_subclass_spec_in_any"] = instantiate_subclass_spec_in_any
    elif instantiate_subclass_spec_in_any is not None:
        raise ValueError(
            f"instantiate_subclass_spec_in_any must be a boolean, but got {instantiate_subclass_spec_in_any}."
        )
    # config_read_mode
    if config_read_mode_urls_enabled is not None:
        _set_config_read_mode(urls_enabled=config_read_mode_urls_enabled)
    if config_read_mode_fsspec_enabled is not None:
        _set_config_read_mode(fsspec_enabled=config_read_mode_fsspec_enabled)
    # docstring_parse
    if docstring_parse_style is not None:
        _set_docstring_parse_options(style=docstring_parse_style)
    if docstring_parse_attribute_docstrings is not None:
        _set_docstring_parse_options(attribute_docstrings=docstring_parse_attribute_docstrings)
    # parse_optionals_as_positionals
    if isinstance(parse_optionals_as_positionals, bool):
        parsing_settings["parse_optionals_as_positionals"] = parse_optionals_as_positionals
    elif parse_optionals_as_positionals is not None:
        raise ValueError(f"parse_optionals_as_positionals must be a boolean, but got {parse_optionals_as_positionals}.")
    # add_print_completion_argument
    if isinstance(add_print_completion_argument, bool):
        parsing_settings["add_print_completion_argument"] = add_print_completion_argument
    elif add_print_completion_argument is not None:
        raise ValueError(f"add_print_completion_argument must be a boolean, but got {add_print_completion_argument}.")
    # stubs resolver
    if isinstance(stubs_resolver_allow_py_files, bool):
        parsing_settings["stubs_resolver_allow_py_files"] = stubs_resolver_allow_py_files
    elif stubs_resolver_allow_py_files is not None:
        raise ValueError(f"stubs_resolver_allow_py_files must be a boolean, but got {stubs_resolver_allow_py_files}.")
    # omegaconf_absolute_to_relative_paths
    if isinstance(omegaconf_absolute_to_relative_paths, bool):
        parsing_settings["omegaconf_absolute_to_relative_paths"] = omegaconf_absolute_to_relative_paths
    elif omegaconf_absolute_to_relative_paths is not None:
        raise ValueError(
            f"omegaconf_absolute_to_relative_paths must be a boolean, but got {omegaconf_absolute_to_relative_paths}."
        )
    # unset_sentinel
    if isinstance(unset_sentinel, bool):
        parsing_settings["unset_sentinel"] = Unset if unset_sentinel else None
    elif unset_sentinel is not None:
        raise ValueError(f"unset_sentinel must be a boolean, but got {unset_sentinel}.")
    # import paths
    if import_path_denylist is not None or import_path_allowlist is not None:
        set_import_path_verdicts(import_path_denylist, import_path_allowlist)
    # subclass behavior
    if subclasses_disabled or subclasses_enabled:
        subclass_type_behavior(
            subclasses_disabled=subclasses_disabled,
            subclasses_enabled=subclasses_enabled,
        )


def get_parsing_setting(name: str):
    if name not in parsing_settings:
        raise ValueError(f"Unknown parsing setting {name}.")
    if name == "add_print_completion_argument":
        var_name = "JSONARGPARSE_ADD_PRINT_COMPLETION_ARGUMENT"
        if var_name in os.environ:
            return get_env_var_bool(var_name)
    return parsing_settings[name]


def validate_default(container: ActionsContainer, action: argparse.Action):
    if (
        action.default is get_parsing_setting("unset_sentinel")
        or not get_parsing_setting("validate_defaults")
        or not hasattr(action, "_check_type")
    ):
        return
    try:
        from ._core import ArgumentGroup

        if isinstance(container, ArgumentGroup):
            container = container.parser
        with parser_context(parent_parser=container, validating_defaults=True):
            default = action.default
            action.default = None
            action.default = action._check_type_(default)  # type: ignore[attr-defined]
    except Exception as ex:
        raise ValueError(f"Default value is not valid: {ex}") from ex


def get_optionals_as_positionals_actions(parser, include_positionals=False):
    from jsonargparse._actions import ActionConfigFile, ActionFail, _ActionConfigLoad, filter_non_parsing_actions
    from jsonargparse._completions import PrintCompletionAction
    from jsonargparse._typehints import ActionTypeHint

    actions = []
    for action in filter_non_parsing_actions(parser._actions):
        if isinstance(action, (_ActionConfigLoad, ActionConfigFile, ActionFail, PrintCompletionAction)):
            continue
        if ActionTypeHint.is_subclass_typehint(action, all_subtypes=False):
            continue
        if action.nargs not in {1, None}:
            continue
        if not include_positionals and action.option_strings == []:
            continue
        actions.append(action)

    return actions


def supports_optionals_as_positionals(parser):
    return (
        get_parsing_setting("parse_optionals_as_positionals")
        and not parser._subcommands_action
        and not getattr(parser, "_inner_parser", False)
    )


def is_subclass(cls, class_or_tuple) -> bool:
    """Extension of issubclass that supports non-class arguments and generics."""
    try:
        class_or_tuple = get_generic_origins(class_or_tuple)
        if inspect.isclass(cls):
            return issubclass(cls, class_or_tuple)
        elif is_generic_class(cls):
            return issubclass(cls.__origin__, class_or_tuple)
    except TypeError:
        pass  # TypeError means that cls is not a class
    return False


def is_instance(obj, class_or_tuple) -> bool:
    """Extension of isinstance that supports generics."""
    class_or_tuple = get_generic_origins(class_or_tuple)
    return isinstance(obj, class_or_tuple)


def is_final_class(cls) -> bool:
    """Checks whether a class is final, i.e. decorated with ``typing.final``."""
    return getattr(cls, "__final__", False)


def is_abstract_class(cls) -> bool:
    """Checks whether a class has abstract methods or is explicitly declared as an abstract base class."""
    return inspect.isabstract(cls) or abc.ABC in getattr(cls, "__bases__", ())


def is_generic_class(cls) -> bool:
    return isinstance(cls, _GenericAlias) and getattr(cls, "__module__", "") != "typing"


def is_unpack_typehint(cls) -> bool:
    return any(isinstance(cls, unpack_type) for unpack_type in unpack_meta_types)


def get_generic_origin(cls):
    return cls.__origin__ if is_generic_class(cls) else cls


def get_generic_origins(class_or_tuple):
    if isinstance(class_or_tuple, tuple):
        return tuple(get_generic_origin(cls) for cls in class_or_tuple)
    return get_generic_origin(class_or_tuple)


def get_unsubscripted_alias_origin(typehint):
    """Origin class of an unsubscripted typing alias, e.g. typing.List -> list, else None."""
    if isinstance(typehint, type) or hasattr(typehint, "__args__"):
        return None
    origin = getattr(typehint, "__origin__", None)
    return origin if isinstance(origin, type) else None


def get_unaliased_type(cls):
    new_cls = cls
    while True:
        cur_cls = new_cls
        if is_annotated(new_cls):
            new_cls = get_annotated_base_type(new_cls)
        if is_alias_type(new_cls):
            new_cls = get_alias_target(new_cls)
        if is_new_type(new_cls):
            new_cls = get_new_type_supertype(new_cls)
        if is_literal_string(new_cls):
            new_cls = str
        origin = get_unsubscripted_alias_origin(new_cls)
        if origin is not None:
            new_cls = origin
        if new_cls == cur_cls:
            break
    return cur_cls


def is_pure_dataclass(cls) -> bool:
    classes = [c for c in inspect.getmro(cls) if c not in {object, Generic}]
    # bool(classes) since e.g. object itself has no class in its mro that could be a dataclass
    return bool(classes) and all(dataclasses.is_dataclass(c) for c in classes)


subclasses_enabled_types: set[type] = set()
subclasses_disabled_types: set[type] = set()
subclasses_disabled_selectors: dict[str, Callable[[type], bool | int]] = {
    "is_pure_dataclass": is_pure_dataclass,
    "is_pydantic_model": is_pydantic_model,
    "is_attrs_class": is_attrs_class,
    "is_final_class": is_final_class,
}


def is_subclasses_disabled(cls) -> bool:
    if is_generic_class(cls):
        return is_subclasses_disabled(cls.__origin__)
    if not inspect.isclass(cls):
        return False
    # abstract classes are not intended to be instantiated from their own fields, so only subclasses make sense
    subclass_disabled = not is_abstract_class(cls) and any(
        selector(cls) for selector in subclasses_disabled_selectors.values()
    )
    if not subclass_disabled:
        subclass_disabled = any(issubclass(cls, disable_type) for disable_type in subclasses_disabled_types)
    if subclass_disabled:
        subclass_disabled = not any(issubclass(cls, enable_type) for enable_type in subclasses_enabled_types)
    return subclass_disabled


def subclass_type_behavior(
    subclasses_disabled: list[type | Callable[[type], bool]] | None = None,
    subclasses_enabled: list[type | str] | None = None,
) -> None:
    """Configures whether class types accept or not subclasses."""
    for enable_item in subclasses_enabled or []:
        if isinstance(enable_item, str):
            if enable_item not in subclasses_disabled_selectors:
                raise ValueError(f"There is no function '{enable_item}' registered in subclasses_disabled")
            subclasses_disabled_selectors.pop(enable_item)
        elif inspect.isclass(enable_item):
            subclasses_enabled_types.add(enable_item)
        else:
            raise ValueError(
                f"Expected 'subclasses_enabled' list items to be types or strings, but got {enable_item!r}"
            )

    for disable_item in subclasses_disabled or []:
        if inspect.isclass(disable_item):
            subclasses_disabled_types.add(disable_item)
        elif inspect.isfunction(disable_item):
            subclasses_disabled_selectors[disable_item.__name__] = disable_item
        else:
            raise ValueError(
                f"Expected 'subclasses_disabled' list items to be types or functions, but got {disable_item!r}"
            )


# logging

logging_levels = {"CRITICAL", "ERROR", "WARNING", "INFO", "DEBUG"}
null_logger = logging.getLogger("jsonargparse_null_logger")
null_logger.addHandler(logging.NullHandler())
null_logger.parent = None


def setup_default_logger(data, level, caller):
    name = caller
    if isinstance(data, str):
        name = data
    elif isinstance(data, dict) and "name" in data:
        name = data["name"]
    logger = logging.getLogger(name)
    logger.parent = None
    if len(logger.handlers) == 0:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
        logger.addHandler(handler)
    level = getattr(logging, level)
    for handler in logger.handlers:
        handler.setLevel(level)
    return logger


def parse_logger(logger: bool | str | dict | logging.Logger, caller):
    if not isinstance(logger, (bool, str, dict, logging.Logger)):
        raise ValueError(f"Expected logger to be an instance of (bool, str, dict, logging.Logger), but got {logger}.")
    if isinstance(logger, dict) and len(set(logger) - {"name", "level"}) > 0:
        value = {k: v for k, v in logger.items() if k not in {"name", "level"}}
        raise ValueError(f"Unexpected data to configure logger: {value}.")
    if logger is False:
        return null_logger
    level = "WARNING"
    if isinstance(logger, dict) and "level" in logger:
        level = logger["level"]
    if level not in logging_levels:
        raise ValueError(f"Got logger level {level!r} but must be one of {logging_levels}.")
    if not isinstance(logger, logging.Logger):
        logger = setup_default_logger(logger, level, caller)
    return logger


class LoggerProperty:
    """Class designed to be inherited by other classes to add a logger property."""

    def __init__(self, *args, logger: bool | str | dict | logging.Logger = False, **kwargs):
        self.logger = logger
        super().__init__(*args, **kwargs)

    @property
    def logger(self) -> logging.Logger:
        """The logger property for the class.

        :getter: Returns the current logger.
        :setter: Sets the given logging.Logger as logger or sets the default logger
                 if given True/str(logger name)/dict(name, level), or disables logging
                 if given False.

        Raises:
            ValueError: If an invalid logger value is given.
        """
        return self._logger

    @logger.setter
    def logger(self, logger: bool | str | dict | logging.Logger):
        if logger is None:
            from ._deprecated import deprecation_warning, logger_property_none_message

            deprecation_warning((LoggerProperty.logger, None), logger_property_none_message, stacklevel=6)
            logger = False
        if not logger and debug_mode_active():
            logger = {"level": "DEBUG"}
        self._logger = parse_logger(logger, type(self).__name__)


def debug_mode_active() -> bool:
    return get_env_var_bool("JSONARGPARSE_DEBUG")


# base classes


class Action(LoggerProperty, argparse.Action):
    """Base for jsonargparse Action classes."""

    def _check_type_(self, value, **kwargs):
        if not hasattr(self, "_check_type_kwargs"):
            self._check_type_kwargs = set(inspect.signature(self._check_type).parameters)
        kwargs = {k: v for k, v in kwargs.items() if k in self._check_type_kwargs}
        return self._check_type(value, **kwargs)


class NonParsingAction(Action):
    """Base for jsonargparse utility Action classes."""
