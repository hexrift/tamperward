# Examples of Designed Experiments

*Three detailed examples*

Perhaps one of the best ways to illustrate how to analyze data from a designed experiment is to work through a detailed example, explaining each step in the analysis.

Detailed analyses are presented for three basic types of designed experiments:

- [A full factorial experiment](full-factorial-example.md)
- [A fractional factorial experiment](fractional-factorial-example.md)
- [A response surface experiment](response-surface-example.md)

*Software*

Most analyses of designed experiments are performed by statistical software packages. Good statistical software enables the analyst to view graphical displays, build models, and test assumptions. Occasionally, the goals of the experiment can be achieved by simply examining appropriate graphical displays of the experimental responses. In other cases, a satisfactory model has to be fit in order to determine the most significant factors or the optimal contours of the response surface. In any case, the software will perform the appropriate calculations as long as the analyst knows what to request and how to interpret the program outputs.
