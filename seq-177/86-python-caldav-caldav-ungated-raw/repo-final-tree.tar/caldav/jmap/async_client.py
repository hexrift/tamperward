"""
Asynchronous JMAP client.

Mirrors JMAPClient with all public methods as coroutines.
Uses niquests.AsyncSession for HTTP — niquests is a core dependency.

All response-parsing logic lives in _JMAPClientBase (client.py); each method
here is a ~3-line async wrapper: get session, send request, delegate to parser.
"""

from __future__ import annotations

import logging
import uuid
import warnings

from niquests import AsyncSession

from caldav.jmap._methods.calendar import build_calendar_get
from caldav.jmap._methods.event import (
    build_event_changes,
    build_event_get,
    build_event_set_create,
    build_event_set_destroy,
    build_event_set_update,
)
from caldav.jmap._methods.task import (
    build_task_get,
    build_task_list_get,
    build_task_set_create,
    build_task_set_destroy,
    build_task_set_update,
)
from caldav.jmap.client import _DEFAULT_USING, _TASK_USING, _JMAPClientBase
from caldav.jmap.convert import ical_to_jscal
from caldav.jmap.error import JMAPAuthError, JMAPMethodError
from caldav.jmap.objects.calendar import JMAPCalendar
from caldav.jmap.objects.calendar_object import JMAPCalendarObject
from caldav.jmap.session import Session, async_fetch_session

log = logging.getLogger("caldav.jmap")


class AsyncJMAPClient(_JMAPClientBase):
    """Asynchronous JMAP client for calendar operations.

    **The JMAP support is experimental, the API may change in minor-releases**

    Usage::

        from caldav.jmap import get_async_jmap_client
        async with get_async_jmap_client(url="https://jmap.example.com/.well-known/jmap",
                                          username="alice", password="secret") as client:
            calendars = await client.get_calendars()

    Args:
        url: URL of the JMAP session endpoint (``/.well-known/jmap``).
        username: Username for Basic auth.
        password: Password for Basic auth, or bearer token if no username.
        auth: A pre-built niquests-compatible auth object. Takes precedence
              over username/password if provided.
        auth_type: Force a specific auth type: ``"basic"`` or ``"bearer"``.
        timeout: HTTP request timeout in seconds.
    """

    def _get_http_session(self) -> AsyncSession:
        """Return the persistent async HTTP session, creating it on first call."""
        if self._http_session is None:
            sess = AsyncSession()
            sess.auth = self._auth
            sess.headers.update({"Content-Type": "application/json", "Accept": "application/json"})
            self._http_session = sess
        return self._http_session

    async def aclose(self) -> None:
        """Release the persistent HTTP session and its connection pool.

        Only needed when the client was not used as an async context manager
        -- the documented Quick Start builds one directly.  Idempotent; the
        session is recreated on the next request.
        """
        if self._http_session is not None:
            await self._http_session.close()
            self._http_session = None

    async def __aenter__(self) -> AsyncJMAPClient:
        self._get_http_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.aclose()

    def __del__(self) -> None:
        ## Closing an async session needs an event loop, which is long gone by the
        ## time __del__ runs, so all we can do is say so.  getattr() rather than
        ## attribute access: __init__ may have raised before setting it, and an
        ## AttributeError here would be reported as "exception ignored in __del__"
        ## on top of whatever actually went wrong.
        if getattr(self, "_http_session", None) is None:
            return
        try:
            warnings.warn(
                f"{type(self).__name__} was garbage collected with an open HTTP "
                "session; use 'async with' or await aclose()",
                ResourceWarning,
                ## stacklevel=1 on purpose, and explicitly because ruff's B028
                ## wants it stated: pointing any higher is a lie in __del__, where
                ## the caller is the garbage collector.  source= is what makes the
                ## warning actionable instead - with `python -X tracemalloc` it
                ## reports where the leaked client was allocated.
                stacklevel=1,
                source=self,
            )
        except Exception:
            ## __del__ must not raise.  At interpreter shutdown the warnings
            ## machinery may already be torn down and stderr may be closed, and
            ## there is neither anything to recover nor anywhere to report it.
            pass

    async def _get_session(self) -> Session:
        """Return the cached Session, fetching it on first call."""
        if self._session_cache is None:
            self._session_cache = await async_fetch_session(
                self.url, auth=self._auth, timeout=self.timeout
            )
        return self._session_cache

    async def _request(self, method_calls: list[tuple], using: list[str] | None = None) -> list:
        """POST a batch of JMAP method calls and return the methodResponses.

        Args:
            method_calls: List of 3-tuples ``(method_name, args_dict, call_id)``.
            using: Capability URN list for the ``using`` field. Defaults to
                ``_DEFAULT_USING`` (core + calendars).

        Returns:
            List of 3-tuples ``(method_name, response_args, call_id)`` from
            the server's ``methodResponses`` array.

        Raises:
            JMAPAuthError: On HTTP 401 or 403.
            JMAPMethodError: If any methodResponse is an ``error`` response.
        """
        session = await self._get_session()

        payload = {
            "using": using if using is not None else _DEFAULT_USING,
            "methodCalls": list(method_calls),
        }

        log.debug("JMAP POST to %s: %d method call(s)", session.api_url, len(method_calls))

        response = await self._get_http_session().post(
            session.api_url,
            json=payload,
            timeout=self.timeout,
        )

        if response.status_code in (401, 403):
            raise JMAPAuthError(
                url=session.api_url,
                reason=f"HTTP {response.status_code} from API endpoint",
            )

        response.raise_for_status()

        data = response.json()
        method_responses = data.get("methodResponses", [])

        for resp in method_responses:
            method_name, resp_args, call_id = resp
            if method_name == "error":
                error_type = resp_args.get("type", "serverError")
                raise JMAPMethodError(
                    url=session.api_url,
                    reason=f"Method call failed: {resp_args}",
                    error_type=error_type,
                )

        return method_responses

    async def get_calendars(self) -> list[JMAPCalendar]:
        """Fetch all calendars for the authenticated account.

        Returns:
            List of :class:`~caldav.jmap.objects.calendar.JMAPCalendar` objects.
        """
        session = await self._get_session()
        responses = await self._request([build_calendar_get(session.account_id)])
        return self._parse_get_calendars(responses, self, True)

    async def create_event(self, calendar_id: str, ical_str: str) -> str:
        """Create a calendar event from an iCalendar string.

        Args:
            calendar_id: The JMAP calendar ID to create the event in.
            ical_str: A VCALENDAR string representing the event.

        Returns:
            The server-assigned JMAP event ID.

        Raises:
            JMAPMethodError: If the server rejects the create request.
        """
        session = await self._get_session()
        jscal = ical_to_jscal(ical_str, calendar_id=calendar_id)
        call = build_event_set_create(session.account_id, {"new-0": jscal})
        responses = await self._request([call])
        return self._parse_create_event_response(responses, session.api_url)

    async def get_event(self, event_id: str) -> JMAPCalendarObject:
        """Fetch a calendar event as an iCalendar string.

        Args:
            event_id: The JMAP event ID to retrieve.

        Returns:
            A :class:`~caldav.jmap.objects.calendar_object.JMAPCalendarObject`
            wrapping the raw JSCalendar dict.  ``parent`` is ``None`` since
            no :class:`~caldav.jmap.objects.calendar.JMAPCalendar` is available
            at the client level.

        Raises:
            JMAPMethodError: If the event is not found.
        """
        session = await self._get_session()
        responses = await self._request([build_event_get(session.account_id, ids=[event_id])])
        return self._parse_get_event_response(responses, session.api_url, event_id)

    async def update_event(self, event_id: str, ical_str: str) -> None:
        """Update a calendar event from an iCalendar string.

        Args:
            event_id: The JMAP event ID to update.
            ical_str: A VCALENDAR string with the updated event data.

        Raises:
            JMAPMethodError: If the server rejects the update.
        """
        session = await self._get_session()
        patch, nulled = self._build_event_update_patch(ical_str)
        while True:
            responses = await self._request(
                [build_event_set_update(session.account_id, {event_id: patch})]
            )
            drop = self._unsupported_null_keys(responses, event_id, patch, nulled)
            if not drop:
                break
            for key in drop:
                patch.pop(key, None)
        self._parse_update_event_response(responses, session.api_url, event_id)

    async def _search(
        self,
        calendar_id: str | None = None,
        start: str | None = None,
        end: str | None = None,
        text: str | None = None,
        parent: JMAPCalendar | None = None,
    ) -> list[JMAPCalendarObject]:
        session = await self._get_session()
        calls = self._build_event_search_calls(session.account_id, calendar_id, start, end, text)
        responses = await self._request(calls)
        return self._parse_search_response(responses, parent)

    async def search_events(
        self,
        calendar_id: str | None = None,
        start: str | None = None,
        end: str | None = None,
        text: str | None = None,
    ) -> list[JMAPCalendarObject]:
        """Search for calendar events.

        All parameters are optional; omitting all returns every event in the account.
        Results are fetched in a single batched JMAP request using a result reference
        from ``CalendarEvent/query`` into ``CalendarEvent/get``.

        Args:
            calendar_id: Limit results to this calendar.
            start: Only events ending after this datetime (``YYYY-MM-DDTHH:MM:SS``).
            end: Only events starting before this datetime (``YYYY-MM-DDTHH:MM:SS``).
            text: Free-text search across title, description, locations, and participants.

        Returns:
            List of :class:`~caldav.jmap.objects.calendar_object.JMAPCalendarObject`
            instances.  ``parent`` is ``None`` on these objects; use
            :meth:`JMAPCalendar.search` if you need ``parent`` set.
        """
        return await self._search(calendar_id=calendar_id, start=start, end=end, text=text)

    async def get_sync_token(self) -> str:
        """Return the current CalendarEvent state string for use as a sync token.

        Calls ``CalendarEvent/get`` with an empty ID list — no event data is
        transferred, only the ``state`` field from the response.

        Returns:
            Opaque state string. Pass to :meth:`get_objects_by_sync_token` to
            retrieve only what changed since this point.
        """
        session = await self._get_session()
        responses = await self._request([build_event_get(session.account_id, ids=[])])
        return self._parse_get_sync_token_response(responses, session.api_url)

    async def get_objects_by_sync_token(
        self, sync_token: str
    ) -> tuple[list[JMAPCalendarObject], list[JMAPCalendarObject], list[str], str]:
        """Fetch events changed since a previous sync token.

        Calls ``CalendarEvent/changes`` to discover which events were created,
        modified, or destroyed since ``sync_token`` was issued. Created and
        modified events are returned as
        :class:`~caldav.jmap.objects.calendar_object.JMAPCalendarObject` instances;
        destroyed events are returned as IDs (the objects no longer exist on the server).

        Args:
            sync_token: A state string previously returned by :meth:`get_sync_token`
                or by a prior call to this method.

        Returns:
            A 4-tuple ``(added, modified, deleted, new_sync_token)``:

            - ``added``: objects for newly created events (``parent`` is ``None``).
            - ``modified``: objects for updated events (``parent`` is ``None``).
            - ``deleted``: Event IDs that were destroyed.
            - ``new_sync_token``: Pass to the next call to this method as ``sync_token``.

        Raises:
            JMAPMethodError: If the server reports ``hasMoreChanges: true``.
        """
        session = await self._get_session()
        responses = await self._request([build_event_changes(session.account_id, sync_token)])
        created_ids, updated_ids, destroyed, new_sync_token = self._parse_event_changes_response(
            responses, session.api_url
        )
        fetch_ids = created_ids + updated_ids
        if not fetch_ids:
            return [], [], destroyed, new_sync_token
        get_responses = await self._request([build_event_get(session.account_id, ids=fetch_ids)])
        return self._assemble_sync_token_result(
            get_responses, created_ids, updated_ids, destroyed, new_sync_token
        )

    async def delete_event(self, event_id: str) -> None:
        """Delete a calendar event.

        Args:
            event_id: The JMAP event ID to delete.

        Raises:
            JMAPMethodError: If the server rejects the delete.
        """
        session = await self._get_session()
        responses = await self._request([build_event_set_destroy(session.account_id, [event_id])])
        self._parse_delete_event_response(responses, session.api_url, event_id)

    async def _get_object_by_uid(
        self, uid: str, calendar_id: str | None = None, parent: JMAPCalendar | None = None
    ) -> JMAPCalendarObject:
        # RFC 8984 FilterCondition has no uid field; UID matching is done client-side.
        for obj in await self._search(calendar_id=calendar_id, parent=parent):
            if obj.data.get("uid") == uid:
                return obj
        session = await self._get_session()
        raise JMAPMethodError(
            url=session.api_url, reason=f"No calendar object found with UID: {uid}"
        )

    async def get_task_lists(self) -> list[dict]:
        """Fetch all task lists for the authenticated account.

        Returns:
            List of raw JMAP TaskList dicts as returned by the server.
        """
        session = await self._get_session()
        responses = await self._request(
            [build_task_list_get(session.account_id)], using=_TASK_USING
        )
        return self._parse_get_task_lists_response(responses)

    async def create_task(self, task_list_id: str, title: str, **kwargs) -> str:
        """Create a task in a task list.

        Args:
            task_list_id: The JMAP task list ID to create the task in.
            title: Task title (maps to VTODO ``SUMMARY``).
            **kwargs: Optional JMAP Task fields using wire names: ``description``,
                ``due``, ``start``, ``timeZone``, ``estimatedDuration``,
                ``percentComplete``, ``progress``, ``priority``.

        Returns:
            The server-assigned JMAP task ID.

        Raises:
            JMAPMethodError: If the server rejects the create request.
        """
        session = await self._get_session()
        task_dict = {
            "@type": "Task",
            "uid": str(uuid.uuid4()),
            "taskListId": task_list_id,
            "title": title,
            "percentComplete": 0,
            "progress": "needs-action",
            "priority": 0,
        }
        task_dict.update(kwargs)
        call = build_task_set_create(session.account_id, {"new-0": task_dict})
        responses = await self._request([call], using=_TASK_USING)
        return self._parse_create_task_response(responses, session.api_url)

    async def get_task(self, task_id: str) -> dict:
        """Fetch a task by ID.

        Args:
            task_id: The JMAP task ID to retrieve.

        Returns:
            Raw JMAP Task dict as returned by the server.

        Raises:
            JMAPMethodError: If the task is not found.
        """
        session = await self._get_session()
        responses = await self._request(
            [build_task_get(session.account_id, ids=[task_id])], using=_TASK_USING
        )
        return self._parse_get_task_response(responses, session.api_url, task_id)

    async def update_task(self, task_id: str, patch: dict) -> None:
        """Update a task with a partial patch.

        Args:
            task_id: The JMAP task ID to update.
            patch: Partial patch dict mapping property names to new values.

        Raises:
            JMAPMethodError: If the server rejects the update.
        """
        session = await self._get_session()
        call = build_task_set_update(session.account_id, {task_id: patch})
        responses = await self._request([call], using=_TASK_USING)
        self._parse_update_task_response(responses, session.api_url, task_id)

    async def delete_task(self, task_id: str) -> None:
        """Delete a task.

        Args:
            task_id: The JMAP task ID to delete.

        Raises:
            JMAPMethodError: If the server rejects the delete.
        """
        session = await self._get_session()
        responses = await self._request(
            [build_task_set_destroy(session.account_id, [task_id])], using=_TASK_USING
        )
        self._parse_delete_task_response(responses, session.api_url, task_id)
