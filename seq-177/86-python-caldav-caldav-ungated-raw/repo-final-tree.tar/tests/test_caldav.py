#!/usr/bin/env python
"""
Tests here communicate with third party servers and/or
internal ad-hoc instances of Xandikos and Radicale, dependent on the
configuration in caldav_test_servers.yaml (see caldav_test_servers.yaml.example).
Tests that do not require communication with a working caldav server
belong in test_caldav_unit.py
"""

import codecs
import json
import logging
import os
import random
import re
import sys
import tempfile
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from unittest import mock
from urllib.parse import urlparse

import icalendar
import proxy
import pytest
import vobject
from proxy.http.proxy import HttpProxyBasePlugin

from caldav import get_davclient

from .test_servers import get_registry
from .test_servers.config_loader import load_test_server_config

# Get server configuration from the test_servers framework
_registry = get_registry()
caldav_servers = _registry.get_caldav_servers_list()

# Check which embedded servers are available
_radicale_server = _registry.get("Radicale")
_xandikos_server = _registry.get("Xandikos")

test_radicale = _radicale_server is not None
test_xandikos = _xandikos_server is not None

radicale_host = _radicale_server.host if _radicale_server else "localhost"
radicale_port = _radicale_server.port if _radicale_server else 5232
xandikos_host = _xandikos_server.host if _xandikos_server else "localhost"
xandikos_port = _xandikos_server.port if _xandikos_server else 8993

# RFC6638 users for scheduling tests - loaded from config file
_config = load_test_server_config()
rfc6638_users = _config.get("rfc6638_users", [])
from caldav import Calendar, DAVObject, Event, FreeBusy, Principal, Todo
from caldav.compatibility_hints import (
    incompatibility_description,
)  ## TEMP - should be removed in the future
from caldav.davclient import CONNKEYS, DAVClient, DAVResponse
from caldav.elements import cdav, dav, ical
from caldav.lib import error
from caldav.lib.python_utilities import to_local, to_str
from caldav.search import CalDAVSearcher

log = logging.getLogger("caldav")


def _make_client(
    idx=None, name=None, setup=lambda conn: None, teardown=lambda conn: None, **kwargs
):
    """
    Create a DAVClient from server parameters.

    This is a test helper that creates a DAVClient instance from either:
    - An index into caldav_servers list
    - A server name to look up in caldav_servers
    - Direct connection parameters

    It filters out non-connection parameters and attaches setup/teardown
    callbacks to the client.
    """
    kwargs_ = kwargs.copy()
    no_args = not any(x for x in kwargs if kwargs[x] is not None)

    if idx is None and name is None and no_args and caldav_servers:
        return _make_client(idx=0)
    elif idx is not None and no_args and caldav_servers:
        return _make_client(**caldav_servers[idx])
    elif name is not None and no_args and caldav_servers:
        for s in caldav_servers:
            if s["name"] == name:
                return _make_client(**s)
        return None
    elif no_args:
        return None

    # Filter out non-connection parameters
    for bad_param in (
        "incompatibilities",
        "backwards_compatibility_url",
        "principal_url",
        "enable",
    ):
        kwargs_.pop(bad_param, None)

    for kw in list(kwargs_.keys()):
        if kw not in CONNKEYS:
            log.debug(f"Ignoring non-connection parameter: {kw}")
            kwargs_.pop(kw)

    conn = DAVClient(**kwargs_)
    conn.setup = setup
    conn.teardown = teardown
    conn.server_name = name
    return conn


# Alias for backward compatibility within tests
client = _make_client


ev1 = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:20010712T182145Z-123401@example.com
DTSTAMP:20060712T182145Z
DTSTART:20060714T170000Z
DTEND:20060715T040000Z
SUMMARY:Bastille Day Party
END:VEVENT
END:VCALENDAR
"""

broken_ev1 = """BEGIN:VEVENT
UID:20010712T182145Z-123401@example.com
DTSTART:20060714T170000Z
DTEND:20060715T040000Z
SUMMARY:Bastille Day Party
END:VEVENT
"""


def near_now_ics(ics, days=30, hours=11):
    """Return a copy of an ical event string with DTSTART/DTEND shifted to ~now.

    Some servers (e.g. OX App Suite) only return objects within a sliding ~±1
    year window from REPORT-based lookups (ref search.unlimited-time-range), so
    an event with a static historic date (the year-2006 dates in ev1/broken_ev1)
    is invisible to get_events()/get_event_by_uid() even though it was stored
    correctly.  Using a near-now date keeps these save-then-search tests
    meaningful on such servers.  Only plain "DTSTART:"/"DTEND:" properties are
    shifted; recurring all-day templates (DTSTART;VALUE=DATE:) are left alone.
    """
    start = datetime.now() + timedelta(days=days)
    end = start + timedelta(hours=hours)
    ics = re.sub(r"DTSTART:[0-9T]+Z?", start.strftime("DTSTART:%Y%m%dT%H%M%SZ"), ics)
    ics = re.sub(r"DTEND:[0-9T]+Z?", end.strftime("DTEND:%Y%m%dT%H%M%SZ"), ics)
    return ics


def next_anniversary_windows(month=11, day=2, hour=17):
    """Search windows around the next future anniversary of (month, day).

    A FREQ=YEARLY event (e.g. evr, anchored at 1997-11-02) recurs forever, so
    historic search windows like 2008-11 are arbitrary.  Servers with a sliding
    REPORT window (e.g. OX App Suite, ref search.time-range.event.old-dates) can
    only serve time ranges near now, so we search the next future occurrence
    instead.  Returns (year, narrow_start, narrow_end, wide_end): a ±1-day window
    catching one occurrence in `year`, plus a wide_end one year later so that
    [narrow_start, wide_end] catches two consecutive occurrences.
    """
    now = datetime.now()
    year = now.year if (now.month, now.day) <= (month, day) else now.year + 1
    narrow_start = datetime(year, month, day - 1, hour, 0, 0)
    narrow_end = datetime(year, month, day + 1, hour, 0, 0)
    wide_end = datetime(year + 1, month, day + 1, hour, 0, 0)
    return year, narrow_start, narrow_end, wide_end


ev2 = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:20010712T182145Z-123401@example.com
DTSTAMP:20070712T182145Z
DTSTART:20070714T170000Z
DTEND:20070715T040000Z
SUMMARY:Bastille Day Party +1year
END:VEVENT
END:VCALENDAR
"""

ev3 = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:20080712T182145Z-123401@example.com
DTSTAMP:20210712T182145Z
DTSTART:20210714T170000Z
DTEND:20210715T040000Z
SUMMARY:Bastille Day Jitsi Party
END:VEVENT
END:VCALENDAR
"""

# example from https://datatracker.ietf.org/doc/html/rfc5545
evr = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:19970901T130000Z-123403@example.com
DTSTAMP:19970901T130000Z
DTSTART;VALUE=DATE:19971102
SUMMARY:Our Blissful Anniversary
TRANSP:TRANSPARENT
CLASS:CONFIDENTIAL
CATEGORIES:ANNIVERSARY,PERSONAL,SPECIAL OCCASION
RRULE:FREQ=YEARLY
END:VEVENT
END:VCALENDAR"""

# example created by editing a specific occurrence of a recurrent event via Thunderbird
evr2 = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Mozilla.org/NONSGML Mozilla Calendar V1.1//EN
BEGIN:VEVENT
UID:c26921f4-0653-11ef-b756-58ce2a14e2e5
DTSTART:20240411T123000Z
DTEND:20240412T123000Z
DTSTAMP:20240429T181103Z
LAST-MODIFIED:20240429T181103Z
RRULE:FREQ=WEEKLY;INTERVAL=2
SEQUENCE:1
SUMMARY:Test
X-MOZ-GENERATION:1
END:VEVENT
BEGIN:VEVENT
UID:c26921f4-0653-11ef-b756-58ce2a14e2e5
RECURRENCE-ID:20240425T123000Z
DTSTART:20240425T123000Z
DTEND:20240426T123000Z
CREATED:20240429T181031Z
DTSTAMP:20240429T181103Z
LAST-MODIFIED:20240429T181103Z
SEQUENCE:1
SUMMARY:Test (edited)
X-MOZ-GENERATION:1
END:VEVENT
END:VCALENDAR"""

# example from https://datatracker.ietf.org/doc/html/rfc5545
todo = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:20070313T123432Z-456553@example.com
DTSTAMP:20070313T123432Z
DUE;VALUE=DATE:20070501
SUMMARY:Submit Quebec Income Tax Return for 2006
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
STATUS:NEEDS-ACTION
END:VTODO
END:VCALENDAR"""

# example from RFC2445, 4.6.2
todo2 = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:19970901T130000Z-123404@host.com
DTSTAMP:19970901T130000Z
DTSTART:19970415T133000Z
DUE:19970416T045959Z
SUMMARY:1996 Income Tax Preparation
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
PRIORITY:2
STATUS:NEEDS-ACTION
END:VTODO
END:VCALENDAR"""

todo3 = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:19970901T130000Z-123405@host.com
DTSTAMP:19970901T130000Z
DTSTART:19970415T133000Z
DUE:19970516T045959Z
SUMMARY:1996 Income Tax Preparation
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
PRIORITY:1
END:VTODO
END:VCALENDAR"""

todo4 = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:19970901T130000Z-123406@host.com
DTSTAMP:19970901T130000Z
SUMMARY:1996 Income Tax Preparation
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
PRIORITY:1
STATUS:NEEDS-ACTION
END:VTODO
END:VCALENDAR"""

todo5 = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:19920901T130000Z-123407@host.com
DTSTAMP:19920901T130000Z
DTSTART:19920415T133000Z
DUE:19920516T045959Z
SUMMARY:1992 Income Tax Preparation
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
PRIORITY:1
END:VTODO
END:VCALENDAR"""

todo6 = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:19920901T130000Z-123408@host.com
DTSTAMP:19920901T130000Z
DTSTART:19920415T133000Z
DUE:19920516T045959Z
SUMMARY:Yearly Income Tax Preparation
RRULE:FREQ=YEARLY
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
PRIORITY:1
END:VTODO
END:VCALENDAR"""

## a todo without uid.  Should it be possible to store it at all?
todo7 = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
DTSTAMP:19980101T130000Z
DTSTART:19980415T133000Z
DUE:19980516T045959Z
STATUS:NEEDS-ACTION
SUMMARY:Get stuck with Netfix and forget about the tax income declaration
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY
PRIORITY:1
END:VTODO
END:VCALENDAR"""

## It may be that I'm trying to stretch the caldav standards too
## much.  my idea is that with i.e. BYHOUR specified in the RRULE, it
## shall mean that "all recurrences has to be done before some exact
## due time" for quite a lot of chores, the due date of the next
## recurrence would depend on the completed timestamp of the previous
## task.  I think it's not a breach of the standard to have BYHOUR
## specified on a weekly task, but some servers may have issues
## with it.
todo8 = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:takeoutthethrash
DTSTAMP:20221013T151313Z
DTSTART:20221017T065500Z
STATUS:NEEDS-ACTION
DURATION:PT10M
SUMMARY:Take out the thrash before the collectors come.
RRULE:FREQ=WEEKLY;BYDAY=MO;BYHOUR=6;BYMINUTE=55;COUNT=3
CATEGORIES:CHORE
PRIORITY:3
END:VTODO
END:VCALENDAR"""

# example from http://www.kanzaki.com/docs/ical/vjournal.html
journal = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VJOURNAL
UID:19970901T130000Z-123405@example.com
DTSTAMP:19970901T130000Z
DTSTART;VALUE=DATE:19970317
SUMMARY:Staff meeting minutes
DESCRIPTION:1. Staff meeting: Participants include Joe\\, Lisa
  and Bob. Aurora project plans were reviewed. There is currently
  no budget reserves for this project. Lisa will escalate to
  management. Next meeting on Tuesday.\n
END:VJOURNAL
END:VCALENDAR
"""

## From RFC4438 examples, with some modifications
sched_template = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:%s
SEQUENCE:0
DTSTAMP:20210206T%sZ
DTSTART:203206%02iT%sZ
DURATION:PT1H
TRANSP:OPAQUE
SUMMARY:Lunch or something
END:VEVENT
END:VCALENDAR
"""

attendee1 = """
BEGIN:VCALENDAR
PRODID:-//Example Corp.//CalDAV Client//EN
VERSION:2.0
BEGIN:VEVENT
STATUS:CANCELLED
UID:test-attendee1
X-MICROSOFT-DISALLOW-COUNTER:true
DTSTART;TZID=Europe/Moscow:20240607T100000
DTEND;TZID=Europe/Moscow:20240607T103000
LAST-MODIFIED:20240610T063933Z
DTSTAMP:20240618T063824Z
CREATED:00010101T000000Z
SUMMARY:test
SEQUENCE:0
TRANSP:OPAQUE
X-MOZ-LASTACK:20240610T063933Z
ORGANIZER;CN=:mailto:t-caldav-test-att1@tobixen.no
ATTENDEE;PARTSTAT=ACCEPTED;RSVP=true;ROLE=REQ-PARTICIPANT:mailto:t-test-attendee1@tobixen.no
ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=DECLINED:mailto:testemail2024@list.ru
END:VEVENT
BEGIN:VTIMEZONE
TZID:Europe/Moscow
TZURL:http://tzurl.org/zoneinfo-outlook/Europe/Moscow
X-LIC-LOCATION:Europe/Moscow
BEGIN:STANDARD
TZNAME:MSK
TZOFFSETFROM:+0300
TZOFFSETTO:+0300
DTSTART:19700101T000000
END:STANDARD
END:VTIMEZONE
END:VCALENDAR
"""

attendee2 = """
BEGIN:VCALENDAR
PRODID:-//MailRu//MailRu Calendar API -//EN
VERSION:2.0
BEGIN:VEVENT
STATUS:CANCELLED
UID:EB424921-C4D3-46A6-B827-9A92A90D6788
X-MICROSOFT-DISALLOW-COUNTER:true
DTSTART;TZID=Europe/Moscow:20240607T100000
DTEND;TZID=Europe/Moscow:20240607T103000
LAST-MODIFIED:20240610T063933Z
DTSTAMP:20240618T064033Z
CREATED:00010101T000000Z
SUMMARY:test
SEQUENCE:0
TRANSP:OPAQUE
X-MOZ-LASTACK:20240610T063933Z
ORGANIZER;CN=:mailto:knazarov@i-core.ru
ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=ACCEPTED;RSVP=true:mailto:knazarov@i
 -core.ru
ATTENDEE;ROLE=REQ-PARTICIPANT;PARTSTAT=DECLINED:mailto:testemail2024@list.r
 u
END:VEVENT
BEGIN:VTIMEZONE
TZID:Europe/Moscow
TZURL:http://tzurl.org/zoneinfo-outlook/Europe/Moscow
X-LIC-LOCATION:Europe/Moscow
BEGIN:STANDARD
TZNAME:MSK
TZOFFSETFROM:+0300
TZOFFSETTO:+0300
DTSTART:19700101T000000
END:STANDARD
END:VTIMEZONE
END:VCALENDAR
"""


sched = sched_template % (
    str(uuid.uuid4()),
    "%2i%2i%2i" % (random.randint(0, 23), random.randint(0, 59), random.randint(0, 59)),
    random.randint(1, 28),
    "%2i%2i%2i" % (random.randint(0, 23), random.randint(0, 59), random.randint(0, 59)),
)


@pytest.mark.skipif(
    not caldav_servers,
    reason="Requirement: at least one working server configured. The highest-priority server (index 0) will be used, typically Xandikos or Radicale.",
)
class TestGetDAVClient:
    """
    Tests for get_davclient and auto_calendars.

    """

    def testTestConfig(self):
        """Test that get_davclient(testconfig=True) finds config with testing_allowed."""
        # Start a test server using test_servers framework
        server_params = caldav_servers[0]
        with client(**server_params) as conn:
            # Create a config file with testing_allowed: true
            config = {"testing_allowed": True}
            for key in ("username", "password", "proxy"):
                if key in server_params:
                    config[f"caldav_{key}"] = server_params[key]
            config["caldav_url"] = str(conn.url)

            with tempfile.NamedTemporaryFile(
                delete=True, encoding="utf-8", mode="w", suffix=".json"
            ) as tmp:
                json.dump({"test_server": config}, tmp)
                tmp.flush()
                os.fsync(tmp.fileno())
                # Test that get_davclient finds it with testconfig=True
                with get_davclient(
                    config_file=tmp.name, testconfig=True, environment=False
                ) as conn2:
                    assert conn2.principal()

    def testEnvironment(self):
        """Test that get_davclient() reads from environment variables."""
        # Start a test server using test_servers framework
        server_params = caldav_servers[0]
        with client(**server_params) as conn:
            # Set environment variables (only if value is not None)
            for key in ("username", "password", "proxy"):
                if key in server_params and server_params[key] is not None:
                    os.environ[f"CALDAV_{key.upper()}"] = server_params[key]
            os.environ["CALDAV_URL"] = str(conn.url)
            try:
                # Test that get_davclient finds it via environment
                with get_davclient(
                    testconfig=False, environment=True, check_config_file=False
                ) as conn2:
                    assert conn2.principal()
            finally:
                # Clean up environment variables
                for key in ("URL", "USERNAME", "PASSWORD", "PROXY"):
                    os.environ.pop(f"CALDAV_{key}", None)

    def testConfigfile(self):
        """Test that get_davclient() reads from config file."""
        # Start a test server using test_servers framework
        server_params = caldav_servers[0]
        with client(**server_params) as conn:
            config = {}
            for key in ("username", "password", "proxy"):
                if key in server_params:
                    config[f"caldav_{key}"] = server_params[key]
            config["caldav_url"] = str(conn.url)

            with tempfile.NamedTemporaryFile(delete=True, encoding="utf-8", mode="w") as tmp:
                json.dump({"default": config}, tmp)
                tmp.flush()
                os.fsync(tmp.fileno())
                with get_davclient(
                    config_file=tmp.name, testconfig=False, environment=False
                ) as conn2:
                    assert conn2.principal()

    def testAutoEmbeddedServer(self) -> None:
        """Test that get_davclient(testconfig=True) auto-starts xandikos when no config file server found."""
        pytest.importorskip("xandikos")
        with get_davclient(testconfig=True, check_config_file=False, environment=False) as conn:
            assert hasattr(conn, "server_name")
            assert "xandikos" in conn.server_name.lower()
            conn.principal()

    def testNoConfigfile(self, fs):
        """This is actually a unit test, not a functional test.
        Should move it to another file probably, and make more unit
        tests covering the config file parsing
        """
        assert get_davclient(testconfig=False, environment=False) is None
        HOME = os.environ["HOME"]
        fs.create_dir(f"{HOME}/.config/caldav")
        fs.create_file(
            f"{HOME}/.config/caldav/calendar.conf",
            contents=json.dumps(
                {
                    "default": {
                        "caldav_url": "https://caldav.example.com/dav",
                        "caldav_username": "karl",
                        "caldav_password": "hunter2",
                    }
                }
            ),
        )
        client = get_davclient(testconfig=False, environment=False)
        assert client.url == "https://caldav.example.com/dav"


def test_get_davclient_returns_none_without_env_or_config(fs) -> None:
    """get_davclient() must return None when PYTHON_CALDAV_USE_TEST_SERVER is not set
    and no config file is present."""
    from unittest.mock import patch

    with patch.dict(os.environ, {}, clear=True):
        result = get_davclient()
    assert result is None


@pytest.mark.skipif(not caldav_servers, reason="need at least one test server")
class TestGetCalendarsConfig:
    """
    Tests for caldav.get_calendars() config-file integration:
    - calendar_name / calendar_url in a config section filter the returned calendars
    - meta-sections (contains: [...]) aggregate calendars from multiple servers
    """

    def _server_config(self, conn, server) -> dict:
        """Build a caldav config dict for a running server connection."""
        cfg: dict = {"caldav_url": str(conn.url)}
        if server and server.username:
            cfg["caldav_username"] = server.username
        if server and server.password is not None:
            cfg["caldav_password"] = server.password
        return cfg

    def test_calendar_name_from_config_filters(self) -> None:
        """calendar_name in a config section must restrict which calendar is returned."""
        from caldav import get_calendars

        from .test_servers.helpers import client_context

        with client_context(server_index=0) as conn:
            principal = conn.principal()
            principal.make_calendar(name="CalConfigA")
            principal.make_calendar(name="CalConfigB")

            server = _registry.get(conn.server_name)
            cfg_section = self._server_config(conn, server)
            cfg_section["calendar_name"] = "CalConfigA"

            with tempfile.NamedTemporaryFile(delete=True, mode="w", suffix=".json") as tmp:
                json.dump({"default": cfg_section}, tmp)
                tmp.flush()
                os.fsync(tmp.fileno())
                with get_calendars(
                    config_file=tmp.name,
                    config_section="default",
                    testconfig=False,
                    environment=False,
                ) as calendars:
                    names = [c.get_display_name() for c in calendars]
                    assert "CalConfigA" in names
                    assert "CalConfigB" not in names

    @pytest.mark.skipif(
        not (test_radicale and test_xandikos),
        reason="need both Xandikos and Radicale for multi-server test",
    )
    def test_multi_server_meta_section(self) -> None:
        """A meta-section (contains: [...]) must aggregate calendars from multiple servers."""
        from caldav import get_calendars

        from .test_servers.helpers import client_context

        with (
            client_context(server_name="Xandikos") as x_conn,
            client_context(server_name="Radicale") as r_conn,
        ):
            x_conn.principal().make_calendar(name="XandikosMetaCal")
            r_conn.principal().make_calendar(name="RadicaleMetaCal")

            x_cfg = self._server_config(x_conn, _xandikos_server)
            x_cfg["calendar_name"] = "XandikosMetaCal"
            r_cfg = self._server_config(r_conn, _radicale_server)
            r_cfg["calendar_name"] = "RadicaleMetaCal"

            config = {
                "xandikos": x_cfg,
                "radicale": r_cfg,
                "both": {"contains": ["xandikos", "radicale"]},
            }
            with tempfile.NamedTemporaryFile(delete=True, mode="w", suffix=".json") as tmp:
                json.dump(config, tmp)
                tmp.flush()
                os.fsync(tmp.fileno())
                with get_calendars(
                    config_file=tmp.name,
                    config_section="both",
                    testconfig=False,
                    environment=False,
                ) as calendars:
                    names = {c.get_display_name() for c in calendars}
                    assert "XandikosMetaCal" in names
                    assert "RadicaleMetaCal" in names
                    # calendars came from two distinct DAVClient instances
                    clients = {id(c.client) for c in calendars}
                    assert len(clients) == 2


class _TestSchedulingBase:
    """
    Base class for RFC6638 scheduling tests.  Not collected directly by
    pytest (no ``Test`` prefix); concrete subclasses supply ``_users``.

    Concrete subclasses are generated dynamically in the module epilogue,
    one per server that has ``scheduling_users`` configured (see
    ``caldav_test_servers.yaml.example`` for setup instructions).
    Docker test servers (Baikal, Nextcloud, Cyrus, SOGo, DAViCal, Davis,
    CCS, Zimbra, Stalwart) pre-create multiple users for this purpose.
    """

    ## Subclasses set this to the list of user connection dicts to use.
    _users: list[dict] = []
    ## Server-level feature dict/FeatureSet; set by dynamic class generation.
    _server_features: object = None

    def _skip_unless_support(self, feature: str) -> None:
        """Skip the test if the server does not declare support for *feature*."""
        from caldav.compatibility_hints import FeatureSet

        if not self._server_features:
            pytest.skip(f"No feature information available, skipping {feature} test")
        fs = (
            self._server_features
            if isinstance(self._server_features, FeatureSet)
            else FeatureSet(self._server_features)
        )
        if not fs.is_supported(feature):
            msg = fs.find_feature(feature).get("description", feature)
            pytest.skip("Test skipped due to server incompatibility issue: " + msg)

    def _getCalendar(self, i):
        calendar_id = "schedulingnosetestcalendar%i" % i
        calendar_name = "caldav scheduling test %i" % i
        try:
            cal = self.principals[i].calendar(name=calendar_name)
            ## Calendar already exists — clear its contents rather than delete+recreate,
            ## since some servers (e.g. Nextcloud) move deleted calendars to a trash bin
            ## and block re-creation with the same cal_id.
            for obj in cal.objects():
                obj.delete()
            return cal
        except error.NotFoundError:
            return self.principals[i].make_calendar(name=calendar_name, cal_id=calendar_id)

    def setup_method(self):
        self.clients = []
        self.principals = []
        self._auto_scheduled_event_uids = []
        for foo in self._users:
            c = client(**foo)
            if not c.check_scheduling_support():
                continue  ## ignoring user because server does not support scheduling.
            self.clients.append(c)
            self.principals.append(c.principal())

    def teardown_method(self):
        for i in range(0, len(self.principals)):
            calendar_name = "caldav scheduling test %i" % i
            try:
                cal = self.principals[i].calendar(name=calendar_name)
                ## Clear events rather than deleting the calendar: some servers
                ## (e.g. Nextcloud) soft-delete calendars to a trash bin, blocking
                ## re-creation with the same cal_id on the next test run.
                for obj in cal.objects():
                    try:
                        obj.delete()
                    except Exception:
                        pass
            except error.NotFoundError:
                pass
        ## Clean up any auto-scheduled events that the server placed in non-test
        ## calendars (e.g. Cyrus delivers to the Default calendar).
        if self._auto_scheduled_event_uids:
            for principal in self.principals:
                for cal in principal.calendars():
                    for event in cal.get_events():
                        try:
                            if event.id in self._auto_scheduled_event_uids:
                                event.delete()
                        except Exception:
                            pass
        for c in self.clients:
            c.__exit__()

    def testFreeBusy(self):
        """Test RFC6638 freebusy query via the schedule outbox (Principal.freebusy_request)."""
        if len(self.principals) < 1:
            pytest.skip("need at least 1 principal")
        self._skip_unless_support("scheduling.freebusy-query")

        dtstart = (datetime.now() + timedelta(days=1)).replace(
            hour=9, minute=0, second=0, microsecond=0
        )
        dtend = (datetime.now() + timedelta(days=1)).replace(
            hour=18, minute=0, second=0, microsecond=0
        )
        attendees = [self.principals[0].get_vcal_address()]
        ## Just verify the call completes without raising.
        ## The response format varies per server.
        self.principals[0].freebusy_request(dtstart, dtend, attendees)

    def testInviteAndRespond(self):
        ## Look through inboxes of principals[0] and principals[1] so we can sort
        ## out existing stuff from new stuff
        if len(self.principals) < 2:
            pytest.skip("need 2 principals to do the invite and respond test")
        inbox_items = set([x.url for x in self.principals[0].schedule_inbox().get_items()])
        inbox_items.update(set([x.url for x in self.principals[1].schedule_inbox().get_items()]))

        ## self.principal[0] is the organizer, and invites self.principal[1]
        organizers_calendar = self._getCalendar(0)
        attendee_calendar = self._getCalendar(1)
        saved_event = organizers_calendar.save_with_invites(
            sched, [self.principals[0], self.principals[1].get_vcal_address()]
        )
        event_uid = saved_event.id
        self._auto_scheduled_event_uids.append(event_uid)
        assert len(organizers_calendar.get_events()) == 1

        ## Check attendee's inbox and calendars.  Some servers (e.g. Zimbra, CCS)
        ## process scheduling asynchronously, so poll with backoff before giving up.
        new_attendee_inbox_items = []
        auto_scheduled = False
        last_scan_error = None
        for _ in range(30):
            try:
                ## Correlate by UID: a late METHOD:CANCEL from another scheduling
                ## test's teardown can otherwise land here as a stray "new" item
                ## (see testAcceptInviteUsernameEmailFallback).
                new_attendee_inbox_items = [
                    item
                    for item in self.principals[1].schedule_inbox().get_items()
                    if item.url not in inbox_items and item.id == event_uid
                ]
                ## Check whether the server auto-scheduled the event directly into
                ## the attendee's calendar (server-side automatic scheduling).
                ## The event may land in any calendar (e.g. Cyrus uses Default, not the
                ## test calendar), so search all attendee calendars for the event UID.
                auto_scheduled = any(
                    event.id == event_uid
                    for cal in self.principals[1].calendars()
                    for event in cal.get_events()
                )
            except (error.ResponseError, ValueError) as scan_error:
                ## Same as the async twin: a scheduling object that is present but
                ## not yet readable is what the poll is here to wait out.
                last_scan_error = scan_error
                new_attendee_inbox_items = []
            if new_attendee_inbox_items or auto_scheduled:
                break
            time.sleep(1)
        else:
            if last_scan_error is not None:
                pytest.fail(
                    "scheduling data never became readable within 30s; last error: "
                    f"{last_scan_error!r}"
                )

        if len(new_attendee_inbox_items) == 0 or auto_scheduled:
            ## Server implements automatic scheduling.  Some servers (e.g.
            ## Cyrus) may additionally deliver an iTIP copy to the inbox as
            ## a notification, but the acceptance is already done.
            assert auto_scheduled, (
                "Expected invite in attendee inbox OR event auto-added to attendee calendar, got neither"
            )
            return

        ## Normal inbox-delivery flow (RFC6638 section 4.1).

        ## no new inbox items expected for principals[0] yet
        for item in self.principals[0].schedule_inbox().get_items():
            assert item.url in inbox_items

        assert len(new_attendee_inbox_items) == 1
        ## ... and the new inbox item should be an invite request
        assert new_attendee_inbox_items[0].is_invite_request()

        ## Approving the invite
        new_attendee_inbox_items[0].accept_invite(calendar=attendee_calendar)
        ## (now, this item should probably appear on a calendar somewhere ...
        ## TODO: make asserts on that)
        ## TODO: what happens if we delete that invite request now?

        ## principals[0] should now have a notification in the inbox that the
        ## calendar invite was accepted
        new_organizer_inbox_items = [
            item
            for item in self.principals[0].schedule_inbox().get_items()
            if item.url not in inbox_items
        ]
        assert len(new_organizer_inbox_items) == 1
        assert new_organizer_inbox_items[0].is_invite_reply()
        new_organizer_inbox_items[0].delete()

    def testAcceptInviteUsernameEmailFallback(self):
        """accept_invite() works when the invite was built with username-as-email (issue #399).

        The invite is constructed using the attendee's login username directly
        instead of get_vcal_address(), mirroring what a client must do when the
        server does not expose calendar-user-address-set.

        On servers that expose calendar-user-address-set the normal code path
        runs inside accept_invite(); on servers that do not, the username-email
        fallback introduced by the fix kicks in.  Both paths produce the same
        observable outcome (PARTSTAT updated, invite accepted), so this test is
        valid regardless of whether calendar-user-address-set is available.

        Only runs when:
        - two principals are available
        - the server delivers iTIP requests to the inbox
        - the attendee's login username is an email address
        """
        if len(self.principals) < 2:
            pytest.skip("need 2 principals to do the invite and respond test")

        attendee_client = self.clients[1]
        if not attendee_client.features.is_supported("scheduling.mailbox.inbox-delivery"):
            pytest.skip("server does not deliver iTIP requests to the inbox")
        attendee_username = getattr(attendee_client, "username", None)
        if not attendee_username or "@" not in str(attendee_username):
            pytest.skip(
                "Attendee username %r is not an email address; "
                "cannot build a matching ATTENDEE line" % attendee_username
            )
        attendee_email = "mailto:" + attendee_username

        inbox_items = set(x.url for x in self.principals[0].schedule_inbox().get_items())
        inbox_items.update(x.url for x in self.principals[1].schedule_inbox().get_items())

        organizers_calendar = self._getCalendar(0)
        attendee_calendar = self._getCalendar(1)
        ## Build the invite using the attendee's email directly, since
        ## get_vcal_address() would also fail without calendar-user-address-set.
        ## Use a fresh UUID so Zimbra (and other servers) don't treat this as a
        ## duplicate of the event sent by testInviteAndRespond.  Both tests use
        ## the module-level `sched` which has the same UID for the whole test
        ## session, so reusing it causes Zimbra to silently skip inbox delivery.
        fresh_sched = sched_template % (
            str(uuid.uuid4()),
            "%2i%2i%2i" % (random.randint(0, 23), random.randint(0, 59), random.randint(0, 59)),
            random.randint(1, 28),
            "%2i%2i%2i" % (random.randint(0, 23), random.randint(0, 59), random.randint(0, 59)),
        )
        saved_event = organizers_calendar.save_with_invites(
            fresh_sched, [self.principals[0], attendee_email]
        )
        self._auto_scheduled_event_uids.append(saved_event.id)

        ## Correlate the inbox item to THIS invite by UID.  Picking the first
        ## arbitrary "new" item is flaky: deleting an organizer event (e.g. a
        ## previous scheduling test's teardown) makes Zimbra deliver a late
        ## METHOD:CANCEL for the old UID, which can land in this test's poll
        ## window before our own REQUEST arrives.  We match on UID (not method)
        ## so that a wrongly-delivered non-REQUEST for our own UID still fails
        ## the is_invite_request() assertion below rather than being hidden.
        new_attendee_inbox_items = []
        for _ in range(30):
            new_attendee_inbox_items = [
                item
                for item in self.principals[1].schedule_inbox().get_items()
                if item.url not in inbox_items and item.id == saved_event.id
            ]
            if new_attendee_inbox_items:
                break
            time.sleep(1)

        assert len(new_attendee_inbox_items) == 1, (
            "expected exactly one new inbox item for attendee"
        )
        assert new_attendee_inbox_items[0].is_invite_request()

        ## accept_invite() must work via the username-email fallback.
        new_attendee_inbox_items[0].accept_invite(calendar=attendee_calendar)

    ## TODO.  Invite two principals, let both of them load the
    ## invitation, and then let them respond in order.  Lacks both
    ## tests and the implementation also apparently doesn't work as
    ## for now (perhaps I misunderstood the RFC).
    # def testAcceptedInviteRaceCondition(self):
    # pass

    ## TODO: more testing ... what happens if deleting things from the
    ## inbox/outbox?

    # ------------------------------------------------------------------ #
    # Schedule-Tag tests (RFC 6638 section 3.2–3.3)                      #
    # Implemented in v3.2.0, see                                         #
    # https://github.com/python-caldav/caldav/issues/660                 #
    # ------------------------------------------------------------------ #

    def testScheduleTagReturnedOnSave(self):
        """
        Saving a scheduling object (one with ORGANIZER/ATTENDEE) to the server
        should return a Schedule-Tag header.  After save() the tag must be
        accessible via event.schedule_tag and stored in event.props.

        RFC 6638 section 3.2: the server MUST return Schedule-Tag on
        responses to PUT requests for scheduling object resources.
        """
        self._skip_unless_support("scheduling.schedule-tag")
        if len(self.principals) < 2:
            pytest.skip("need at least 1 principal")

        cal = self._getCalendar(0)
        addr = self.principals[0].get_vcal_address()
        addr2 = self.principals[1].get_vcal_address()
        uid = str(uuid.uuid4())
        ical = (
            "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Test//Test//EN\r\n"
            "BEGIN:VEVENT\r\n"
            f"UID:{uid}\r\n"
            "DTSTAMP:20260101T000000Z\r\n"
            "DTSTART:20320601T100000Z\r\nDURATION:PT1H\r\n"
            "SUMMARY:Schedule-Tag test\r\n"
            f"ORGANIZER:{addr}\r\n"
            f"ATTENDEE;RSVP=TRUE;PARTSTAT=NEEDS-ACTION:{addr}\r\n"
            f"ATTENDEE;RSVP=TRUE;PARTSTAT=NEEDS-ACTION:{addr2}\r\n"
            "END:VEVENT\r\nEND:VCALENDAR\r\n"
        )
        event = cal.save_event(ical)

        assert event.schedule_tag is not None, (
            "Server did not return Schedule-Tag header after PUT; "
            "either the server does not support it or event.schedule_tag "
            "property is not implemented"
        )

    def testScheduleTagStableOnPartstateUpdate(self):
        """
        RFC 6638 section 3.2: when an attendee updates only their PARTSTAT
        (participation status) the server MUST NOT change the Schedule-Tag.

        The tag before and after a PARTSTAT-only PUT must be identical.
        """
        self._skip_unless_support("scheduling.schedule-tag")
        self._skip_unless_support("scheduling.schedule-tag.stable-partstat")
        if len(self.principals) < 2:
            pytest.skip("need 2 principals")
        if not self.clients[1].features.is_supported("scheduling.mailbox.inbox-delivery"):
            pytest.skip("server does not deliver iTIP requests to the inbox")

        organizer_cal = self._getCalendar(0)
        attendee_cal = self._getCalendar(1)

        fresh_sched = sched_template % (
            str(uuid.uuid4()),
            "%2i%2i%2i" % (random.randint(0, 23), random.randint(0, 59), random.randint(0, 59)),
            random.randint(1, 28),
            "%2i%2i%2i" % (random.randint(0, 23), random.randint(0, 59), random.randint(0, 59)),
        )
        saved_event = organizer_cal.save_with_invites(
            fresh_sched, [self.principals[0], self.principals[1].get_vcal_address()]
        )
        self._auto_scheduled_event_uids.append(saved_event.id)

        ## Wait for the REQUEST invite (matching our UID) to land in attendee's inbox
        invite = None
        for _ in range(30):
            for item in self.principals[1].schedule_inbox().get_items():
                item.load()
                if item.is_invite_request() and item.id == saved_event.id:
                    invite = item
                    break
            if invite:
                break
            time.sleep(1)

        if not invite:
            pytest.skip("Invite not delivered to attendee inbox; cannot test PARTSTAT stability")

        ## Accept the invite — places the event in the attendee's calendar.
        ## On auto-scheduling servers the event may already exist; _reply_to_invite_request
        ## handles that by finding and updating it in place.
        invite.accept_invite(calendar=attendee_cal)

        ## Find the event across all attendee calendars; on auto-scheduling servers it may be
        ## in the default calendar rather than attendee_cal.  Retry briefly for async servers.
        attendee_event = None
        for _ in range(5):
            for cal in self.principals[1].calendars():
                try:
                    attendee_event = cal.event_by_uid(saved_event.id)
                    break
                except error.NotFoundError:
                    pass
            if attendee_event:
                break
            time.sleep(1)

        assert attendee_event is not None, "Event not found in any attendee calendar after accept"
        attendee_event.load()
        tag_before = attendee_event.schedule_tag
        assert tag_before is not None, "No Schedule-Tag on attendee's calendar event after accept"

        ## Do a second PARTSTAT-only change (ACCEPTED → TENTATIVE) and compare tags
        attendee_event.change_attendee_status(partstat="TENTATIVE")
        attendee_event.save()
        attendee_event.load()
        tag_after = attendee_event.schedule_tag

        assert tag_after is not None, "No Schedule-Tag on attendee's event after PARTSTAT update"
        assert tag_before == tag_after, (
            f"Schedule-Tag changed after PARTSTAT-only update: "
            f"{tag_before!r} → {tag_after!r}; "
            "RFC 6638 section 3.2 requires the tag to be stable across "
            "participation-status-only updates"
        )

    def testScheduleTagChangesOnOrganizerUpdate(self):
        """
        RFC 6638 section 3.2: when the organizer sends a substantive update,
        the server MUST update the Schedule-Tag on the attendee's copy.

        The tag on the attendee's resource before and after an organizer PUT
        must differ.
        """
        self._skip_unless_support("scheduling.schedule-tag")
        if len(self.principals) < 2:
            pytest.skip("need 2 principals")

        organizer_cal = self._getCalendar(0)

        uid = str(uuid.uuid4())
        attendee_addr = self.principals[1].get_vcal_address()
        organizer_addr = self.principals[0].get_vcal_address()

        seqno = 0

        def _make_ical(summary):
            nonlocal seqno
            s = seqno
            seqno += 1
            return (
                "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Test//Test//EN\r\n"
                "BEGIN:VEVENT\r\n"
                f"UID:{uid}\r\n"
                f"SEQUENCE:{s}\r\n"
                "DTSTAMP:20260101T000000Z\r\n"
                "DTSTART:20320601T100000Z\r\nDURATION:PT1H\r\n"
                f"SUMMARY:{summary}\r\n"
                f"ORGANIZER:{organizer_addr}\r\n"
                f"ATTENDEE;RSVP=TRUE;PARTSTAT=NEEDS-ACTION:{attendee_addr}\r\n"
                "END:VEVENT\r\nEND:VCALENDAR\r\n"
            )

        saved = organizer_cal.save_with_invites(
            _make_ical("Original summary"),
            [self.principals[0], attendee_addr],
        )
        assert saved is not None
        self._auto_scheduled_event_uids.append(uid)

        ## Find the attendee's copy and record the tag
        attendee_event = None
        for _ in range(30):
            for cal in self.principals[1].calendars():
                for ev in cal.get_events():
                    if ev.id == uid:
                        attendee_event = ev
                        break
                if attendee_event:
                    break
            if attendee_event:
                break
            time.sleep(1)

        if attendee_event is None:
            pytest.skip("Event not delivered to attendee; cannot test tag change")

        attendee_event.load()
        tag_before = attendee_event.schedule_tag
        assert tag_before is not None, "No Schedule-Tag on attendee's copy before organizer update"

        ## Organizer sends a substantive update (changed summary)
        organizer_cal.save_with_invites(
            _make_ical("Updated summary"),
            [self.principals[0], attendee_addr],
        )

        ## Poll until the attendee's copy reflects the update
        for _ in range(30):
            attendee_event.load()
            if attendee_event.schedule_tag != tag_before:
                break
            time.sleep(1)

        tag_after = attendee_event.schedule_tag
        assert tag_after != tag_before, (
            f"Schedule-Tag did not change after organizer update: still {tag_before!r}; "
            "RFC 6638 section 3.2.10 requires the attendees tag to change after organizer PUT"
        )

    def testScheduleTagMismatchRaisesError(self):
        """
        save() with a stale Schedule-Tag must raise ScheduleTagMismatchError
        when the server returns 412.

        _put() sends If-Schedule-Tag-Match whenever self.schedule_tag is set.
        We fetch the event (tag=1), make a local conflicting edit, then a
        concurrent organizer PUT advances the server-side tag to 2 with a
        different edit on the same field.  The resulting divergence cannot be
        auto-merged, so the server must reject with 412.
        """
        self._skip_unless_support("scheduling.schedule-tag")
        if len(self.principals) < 2:
            pytest.skip("need 2 principals to cause a server-side tag advance")

        organizer_cal = self._getCalendar(0)
        attendee_addr = self.principals[1].get_vcal_address()
        organizer_addr = self.principals[0].get_vcal_address()
        uid = str(uuid.uuid4())

        def _make_ical(summary, seq):
            return (
                "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Test//Test//EN\r\n"
                "BEGIN:VEVENT\r\n"
                f"UID:{uid}\r\n"
                f"SEQUENCE:{seq}\r\n"
                "DTSTAMP:20260101T000000Z\r\n"
                "DTSTART:20320601T100000Z\r\nDURATION:PT1H\r\n"
                f"SUMMARY:{summary}\r\n"
                f"ORGANIZER:{organizer_addr}\r\n"
                f"ATTENDEE;RSVP=TRUE;PARTSTAT=NEEDS-ACTION:{attendee_addr}\r\n"
                "END:VEVENT\r\nEND:VCALENDAR\r\n"
            )

        ## Create the event and load it; event now holds original content + tag=1
        event = organizer_cal.save_event(_make_ical("Original", 0))
        self._auto_scheduled_event_uids.append(uid)
        event.load()
        assert event.schedule_tag is not None, (
            "server did not return Schedule-Tag after initial save"
        )

        ## Make a local conflicting edit (simulating a client that diverges from
        ## the server before a concurrent organizer update arrives).
        event.icalendar_component["SUMMARY"] = "Conflicting client change"

        ## Concurrent organizer PUT advances the server-side tag; the two edits
        ## now conflict on SUMMARY and cannot be auto-merged.
        organizer_cal.save_event(_make_ical("Organizer update", 1))

        ## PUT the locally-modified stale version; server must reject with 412
        ## because the conflicting changes cannot be safely merged.
        with pytest.raises(error.ScheduleTagMismatchError):
            event.save(increase_seqno=False)

    def testScheduleTagMatchSucceeds(self):
        """
        save() with the correct (current) tag must
        succeed and the updated tag must be stored in event.props afterwards.

        Requires 2 principals: servers only assign a Schedule-Tag to events
        that have external attendees (i.e. real scheduling objects).
        """
        self._skip_unless_support("scheduling.schedule-tag")
        if len(self.principals) < 2:
            pytest.skip("need 2 principals for Schedule-Tag to be assigned")

        cal = self._getCalendar(0)
        addr = self.principals[0].get_vcal_address()
        addr2 = self.principals[1].get_vcal_address()
        uid = str(uuid.uuid4())
        ical = (
            "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//Test//Test//EN\r\n"
            "BEGIN:VEVENT\r\n"
            f"UID:{uid}\r\n"
            "DTSTAMP:20260101T000000Z\r\n"
            "DTSTART:20320601T100000Z\r\nDURATION:PT1H\r\n"
            "SUMMARY:Correct-tag test\r\n"
            f"ORGANIZER:{addr}\r\n"
            f"ATTENDEE;RSVP=TRUE;PARTSTAT=NEEDS-ACTION:{addr}\r\n"
            f"ATTENDEE;RSVP=TRUE;PARTSTAT=NEEDS-ACTION:{addr2}\r\n"
            "END:VEVENT\r\nEND:VCALENDAR\r\n"
        )
        event = cal.save_event(ical)
        self._auto_scheduled_event_uids.append(uid)
        event.load()

        tag_before = event.schedule_tag
        assert tag_before is not None, "Server did not return Schedule-Tag"

        ## Modify something minor and save with the correct tag
        event.icalendar_component["SUMMARY"] = "Correct-tag test (updated)"
        event.save(increase_seqno=False)

        ## Must not have raised; tag in props must be present (may have changed)
        assert event.schedule_tag is not None, (
            "schedule_tag property disappeared after conditional save"
        )


## Legacy: run TestScheduling against the top-level rfc6638_users config.
if rfc6638_users:
    TestScheduling = type(
        "TestScheduling",
        (_TestSchedulingBase,),
        {"_users": rfc6638_users},
    )


def _delay_decorator(f, t=20):
    def foo(*a, **kwa):
        time.sleep(t)
        return f(*a, **kwa)

    return foo


## HTTP methods that change server state.  A "write-delay" server settles each of
## these asynchronously, so we sleep AFTER every such request to let the change
## become visible before the test reads it back (the general, write-side
## counterpart of the search-cache delay, which only delays searches).
_WRITE_HTTP_METHODS = frozenset(
    {"PUT", "DELETE", "MKCALENDAR", "MKCOL", "PROPPATCH", "MOVE", "COPY", "POST"}
)


def _write_delay_decorator(f, t=10):
    def foo(url, method="GET", *a, **kwa):
        response = f(url, method, *a, **kwa)
        if str(method).upper() in _WRITE_HTTP_METHODS:
            time.sleep(t)
        return response

    return foo


class RepeatedFunctionalTestsBaseClass:
    """This is a class with functional tests (tests that goes through
    basic functionality and actively communicates with third parties)
    that we want to repeat for all configured caldav_servers.
    (what a truly ugly name for this class - any better ideas?)
    NOTE: this tests relies heavily on the assumption that we can create
    calendars on the remote caldav server, but the RFC says ...
       Support for MKCALENDAR on the server is only RECOMMENDED and not
       REQUIRED because some calendar stores only support one calendar per
       user (or principal), and those are typically pre-created for each
       account.
    We've had some problems with iCloud and Radicale earlier.  Google
    still does not support mkcalendar.
    """

    _default_calendar = None

    ## TODO: move to davclient or compatibility_hints
    def is_supported(self, feature, return_type=bool, accept_fragile=False):
        """
        New-style.  It will replace check_compatibility_flag.

        TODO: write a better docstring
        """
        return self.caldav.features.is_supported(
            feature, return_type, accept_fragile=accept_fragile
        )

    def check_compatibility_flag(self, flag):
        ## yield an assertion error if checking for the wrong thig
        assert flag in incompatibility_description
        return flag in self.old_features

    def skip_on_compatibility_flag(self, flag):
        if self.check_compatibility_flag(flag):
            msg = incompatibility_description[flag]
            pytest.skip("Test skipped due to server incompatibility issue: " + msg)

    def skip_unless_support(self, feature):
        if not self.is_supported(feature):
            msg = self.caldav.features.find_feature(feature).get("description", feature)
            pytest.skip("Test skipped due to server incompatibility issue: " + msg)

    def setup_method(self):
        logging.debug("############## test setup")
        self.calendars_used = []
        self._preconfigured_calendar_urls = set()

        self.caldav = client(**self.server_params)
        self.caldav.__enter__()

        ## Temp thing
        self.old_features = self.caldav.features._old_flags

        calendar_info = self.is_supported("test-calendar", dict)
        self.cleanup_regime = calendar_info.get("cleanup-regime", "light")

        if "cleanup" in self.server_params:
            self.cleanup_regime = self.server_params["cleanup"]

        ## verify that all old flags are valid
        for flag in self.old_features:
            assert flag in incompatibility_description

        self.testcal_id = "pythoncaldav-test"
        self.testcal_id2 = "pythoncaldav-test2"

        foo = self.is_supported("rate-limit", dict)
        if foo.get("enable"):
            rate_delay = foo.get("interval", 0) / foo.get("count", 1)
            self.caldav.request = _delay_decorator(self.caldav.request, t=rate_delay)
        foo = self.is_supported("search-cache", dict)
        if foo.get("behaviour") == "delay":
            Calendar._search = Calendar.search
            Calendar.search = _delay_decorator(Calendar.search, t=foo["delay"])
        foo = self.is_supported("write-delay", dict)
        if foo.get("behaviour") == "delay":
            ## Every write goes through the client request(); sleep after the
            ## write verbs so the asynchronous change has settled before read-back.
            ## Instance-level wrap (like rate-limit), torn down with the client.
            self.caldav.request = _write_delay_decorator(self.caldav.request, t=foo["delay"])

        if False and self.check_compatibility_flag("no-current-user-principal"):
            self.principal = Principal(client=self.caldav, url=self.server_params["principal_url"])
        else:
            self.principal = self.caldav.principal()

        # if self.check_compatibility_flag('delete_calendar_on_startup'):
        # for x in self._fixCalendar().search():
        # x.delete()

        self._cleanup("pre")

        logging.debug("##############################")
        logging.debug("############## test setup done")
        logging.debug("##############################")

    def teardown_method(self):
        if self.is_supported("search-cache", dict).get("behaviour", "normal") != "normal":
            Calendar.search = Calendar._search
        logging.debug("############################")
        logging.debug("############## test teardown_method")
        logging.debug("############################")
        self._cleanup("post")
        logging.debug("############## test teardown_method almost done")
        try:
            self.caldav.teardown()
        except TypeError:
            self.caldav.teardown(self.caldav)
        # Close the client to release resources (event loop, connections)
        self.caldav.__exit__(None, None, None)

    def _track_calendar(self, cal, was_created=True):
        """Track a calendar for cleanup, noting if it's preconfigured (should not be deleted)."""
        if cal is None:
            return
        cal_url = str(cal.url)
        if cal_url not in {str(c.url) for c in self.calendars_used}:
            self.calendars_used.append(cal)
        if not was_created:
            self._preconfigured_calendar_urls.add(cal_url)

    def _delete_used_calendar(self, cal, wipe):
        """Clean up one tracked calendar, tolerating one the test already deleted.

        A test that deletes a calendar it created (testSetCalendarProperties
        does, with testcal_id2) leaves it in ``calendars_used``, so this
        addresses a collection that is no longer there.  Most servers answer
        the wipe's REPORT with 404 and `_post_delete()` accepts a 404 as
        success, but Robur answers 403 - see the
        ``non-existing-raises-not-found.collection`` feature, which is why the
        tolerated exception comes from ``_notFound()`` rather than being
        NotFoundError outright.  A NotFoundError is tolerated silently; on the
        servers where ``_notFound()`` widens to DAVError, anything else that is
        caught is logged, so a genuine delete failure is still visible in the
        test output.
        """
        try:
            cal.delete(wipe=wipe)
        except self._notFound(collection=True) as e:
            if not isinstance(e, error.NotFoundError):
                ## On a server that answers 403 rather than 404 for a missing
                ## collection (Robur), _notFound() widens to DAVError - which
                ## would also swallow a real failure to delete a calendar that
                ## is still there.  Tolerate it, but do not let it be silent:
                ## leftover calendars accumulating unnoticed is what the Robur
                ## profile refresh in this series had to undo.
                logging.warning(
                    "cleanup: tolerated %s while deleting %s: %s", type(e).__name__, cal.url, e
                )

    def _cleanup(self, mode=None):
        if self.cleanup_regime == "none":
            return  ## no cleanup for ephemeral servers
        if self.cleanup_regime in ("pre", "post") and self.cleanup_regime != mode:
            return
        if not self.is_supported("save-load"):
            return  ## no cleanup needed
        if self.cleanup_regime == "wipe-calendar":
            for cal in self.calendars_used:
                self._delete_used_calendar(cal, wipe=True)
            return  ## keep calendar alive; don't fall through to cal.delete() below
        elif not self.is_supported("create-calendar") or self.cleanup_regime == "thorough":
            for cal in self.calendars_used:
                self._delete_used_calendar(cal, wipe=True)
            return
        for cal in self.calendars_used:
            if str(cal.url) in self._preconfigured_calendar_urls:
                ## Pre-configured calendar: wipe objects, don't delete the calendar
                self._delete_used_calendar(cal, wipe=True)
            else:
                self._delete_used_calendar(cal, wipe=None)
        for calid in (
            self.testcal_id,
            self.testcal_id2,
            self.testcal_id + "-tasks",
            self.testcal_id + "-journals",
        ):
            self._teardownCalendar(cal_id=calid)
        if self.cleanup_regime == "thorough":
            for name in (
                "Yep",
                "Yapp",
                "Yølp",
                self.testcal_id,
                self.testcal_id2,
                self.testcal_id + "-tasks",
                self.testcal_id + "-journals",
            ):
                self._teardownCalendar(name=name)
                self._teardownCalendar(cal_id=name)

    def _teardownCalendar(self, name=None, cal_id=None):
        try:
            cal = self.principal.calendar(name=name, cal_id=cal_id)
            if self.check_compatibility_flag("sticky_events"):
                for goo in cal.objects():
                    try:
                        goo.delete()
                    except:
                        pass
            cal.delete()
        except:
            pass
        try:
            cal.delete()
        except:
            pass

    def _fixCalendar(self, **kwargs):
        cal = self._fixCalendar_(**kwargs)
        if self.cleanup_regime == "wipe-calendar":
            cal.delete(wipe=True)
        return cal

    def _fixCalendar_(self, **kwargs):
        """
        Should ideally return a new calendar, if that's not possible it
        should see if there exists a test calendar, if that's not
        possible, give up and return the primary calendar.

        Delegates core create-or-find logic to fixture_helpers.get_or_create_test_calendar,
        handling test-infrastructure concerns (caching, cleanup, cal_id defaults) here.
        """
        from .fixture_helpers import get_or_create_test_calendar

        if not self.is_supported("create-calendar"):
            if not self._default_calendar:
                self._default_calendar, was_created = get_or_create_test_calendar(
                    self.caldav, self.principal
                )
                self._track_calendar(self._default_calendar, was_created)
            return self._default_calendar

        # Pre-processing: set up defaults for name and cal_id
        comp_set = kwargs.get("supported_calendar_component_set", [])
        # A component-restricted fixture (VTODO-only / VJOURNAL-only) is always
        # looked up by cal_id, never by display name.
        restricted = bool(comp_set) and "VEVENT" not in comp_set
        if "name" not in kwargs:
            if self.cleanup_regime in ("light", "pre"):
                self._teardownCalendar(cal_id=self.testcal_id)
            # Only give a display name when the server accepts one and keeps the
            # calendar at the requested cal_id URL.  On servers that assign a
            # different canonical URL when a name is set (create-calendar.stable-url
            # unsupported: Zimbra relocates, OX uses an opaque id) the library
            # re-points to the canonical URL, so a named fixture would still work -
            # but we keep the fixture nameless there so the bulk of the suite keeps
            # addressing the fixture by its cal_id (simpler, and avoids the
            # name-ambiguity issues below).  Component-restricted fixtures also stay
            # nameless: they are only ever found by cal_id, and giving them the same
            # "Yep" name as the primary fixture would make principal.calendar(
            # name="Yep") ambiguous and, on servers enforcing per-principal unique
            # calendar names (SOGo), block the primary calendar from being (re)named.
            if (
                restricted
                or not self.is_supported("create-calendar.set-displayname")
                or not self.is_supported("create-calendar.stable-url")
            ):
                kwargs["name"] = None
            else:
                kwargs["name"] = "Yep"
        if "cal_id" not in kwargs:
            # Use distinct cal_ids for different component-set-restricted calendars so
            # that a VTODO-only calendar and a VJOURNAL-only calendar don't share the
            # same slot and cause MKCALENDAR failures (and wrong-type PUT errors) when
            # the calendar persists across tests under wipe-calendar cleanup regime.
            if comp_set and "VJOURNAL" in comp_set and "VEVENT" not in comp_set:
                kwargs["cal_id"] = self.testcal_id + "-journals"
            elif restricted:
                kwargs["cal_id"] = self.testcal_id + "-tasks"
            else:
                kwargs["cal_id"] = self.testcal_id

        ret, was_created = get_or_create_test_calendar(
            self.caldav,
            self.principal,
            calendar_name=kwargs.get("name", "pythoncaldav-test"),
            cal_id=kwargs.get("cal_id"),
            supported_calendar_component_set=kwargs.get("supported_calendar_component_set"),
        )

        self._track_calendar(ret, was_created)
        return ret

    def testCheckCompatibility(self, request) -> None:
        try:
            from caldav_server_tester import ServerQuirkChecker
        except ImportError:
            ## Not in the test extra on purpose - see tests/README.md,
            ## "testCheckCompatibility does not run in CI".  Install a
            ## caldav-server-tester checkout that matches this branch and this
            ## test starts working.
            pytest.skip(
                "caldav_server_tester is not installed - install it to run this test, "
                "see tests/README.md"
            )

        # Use pdb debug mode if pytest was run with --pdb, otherwise use logging
        debug_mode = "pdb" if request.config.option.usepdb else "logging"

        ## Build extra clients from scheduling_users (skip index 0; main client covers that user)
        extra_clients = []
        for user_params in self.server_params.get("scheduling_users", [])[1:]:
            params = {
                k: v for k, v in user_params.items() if k not in ("name", "setup", "teardown")
            }
            try:
                ec = client(**params)
                ec.__enter__()
                extra_clients.append(ec)
            except Exception:
                pass

        ## ServerQuirkChecker applies its own search-cache delay internally.
        ## setup_method may have already wrapped Calendar.search; temporarily
        ## expose the original so the checker doesn't double-delay each call.
        saved_calendar_search = Calendar.search
        had_underscore_search = hasattr(Calendar, "_search")
        saved_calendar_underscore_search = getattr(Calendar, "_search", None)
        if had_underscore_search:
            Calendar.search = saved_calendar_underscore_search

        try:
            checker = ServerQuirkChecker(
                self.caldav, debug_mode=debug_mode, extra_clients=extra_clients
            )
            checker.check_all()
            checker.cleanup(force=False)
        finally:
            for ec in extra_clients:
                try:
                    ec.__exit__(None, None, None)
                except Exception:
                    pass
            ## Restore the state setup_method left so teardown_method works normally
            Calendar.search = saved_calendar_search
            if had_underscore_search:
                Calendar._search = saved_calendar_underscore_search
            elif hasattr(Calendar, "_search"):
                delattr(Calendar, "_search")

        ## features observed and features expected
        fo = checker.features_checked
        fe = self.caldav.features

        mismatches = fe.compare(fo)
        assert not mismatches, "compatibility mismatches:\n" + "\n".join(
            f"  {m['feature']}: declared {m['expected']!r}, observed {m['observed']!r}"
            for m in mismatches
        )

    def testSupport(self):
        """
        Test the check_*_support methods
        """
        self.skip_on_compatibility_flag("dav_not_supported")
        assert self.caldav.check_dav_support()
        assert self.caldav.check_cdav_support()
        if self.is_supported("scheduling", str) != "unknown":
            assert self.caldav.check_scheduling_support() == self.is_supported("scheduling")

    def testSchedulingInfo(self):
        self.skip_unless_support("scheduling.calendar-user-address-set")
        calendar_user_address_set = self.principal.calendar_user_address_set()
        assert calendar_user_address_set is not None
        me_a_participant = self.principal.get_vcal_address()
        assert me_a_participant is not None

    def testAddOrganizer(self):
        """add_organizer() sets ORGANIZER from the current principal (issue #524).

        Tests three paths:
        - no-arg: principal is looked up from the client (requires
          scheduling.calendar-user-address-set).
        - explicit email string: pure in-memory, no server interaction.
        - explicit vCalAddress: pure in-memory, no server interaction.
        """
        from icalendar import vCalAddress

        cal = self._fixCalendar()
        event = Event(
            client=self.caldav,
            data=ev1,
            parent=cal,
        )

        ## ---- explicit string arg (pure in-memory, always runs) ----
        event.add_organizer("organizer@example.com")
        org = event.icalendar_component.get("organizer")
        assert org is not None, "ORGANIZER should be set after add_organizer(string)"
        assert "organizer@example.com" in str(org)

        ## ---- explicit vCalAddress arg ----
        addr = vCalAddress("mailto:addr@example.com")
        event.add_organizer(addr)
        org = event.icalendar_component.get("organizer")
        assert str(org) == "mailto:addr@example.com"

        ## ---- no-arg: uses current principal ----
        self.skip_unless_support("scheduling.calendar-user-address-set")
        event.add_organizer()
        org = event.icalendar_component.get("organizer")
        assert org is not None, "ORGANIZER should be set when add_organizer() uses principal"
        principal_addresses = self.principal.calendar_user_address_set()
        assert any(addr in str(org) for addr in principal_addresses), (
            f"ORGANIZER {org!r} should contain one of the principal's addresses {principal_addresses!r}"
        )

    def testIssue399ChangeAttendeeStatusUsernameEmailFallback(self):
        """change_attendee_status() works when the attendee is identified
        by the client username rather than calendar_user_address_set() (issue #399).

        On servers that expose calendar-user-address-set the normal path runs;
        on servers that do not, the username-email fallback introduced by the
        fix kicks in.  Either way the PARTSTAT update must succeed.
        Only skipped when the login username is not an email address.
        """
        self.skip_unless_support("scheduling")
        username = getattr(self.caldav, "username", None)
        if not username or "@" not in str(username):
            pytest.skip(
                "Client username %r is not an email address; "
                "cannot build a matching ATTENDEE line" % username
            )
        my_email = "mailto:" + username

        invite_data = """\
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//Test//EN
METHOD:REQUEST
BEGIN:VEVENT
UID:test-issue-399-%s@test.example
DTSTAMP:%s
DTSTART:%s
DTEND:%s
SUMMARY:Test invite for issue 399
ORGANIZER:mailto:organizer@test.example
ATTENDEE;PARTSTAT=NEEDS-ACTION:%s
END:VEVENT
END:VCALENDAR
""" % (
            uuid.uuid4(),
            datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
            (datetime.now(timezone.utc) + timedelta(days=10)).strftime("%Y%m%dT%H%M%SZ"),
            (datetime.now(timezone.utc) + timedelta(days=10, hours=1)).strftime("%Y%m%dT%H%M%SZ"),
            my_email,
        )

        ev = Event(client=self.caldav, data=invite_data)
        ev.change_attendee_status(partstat="ACCEPTED")

        attendee = ev.icalendar_component["attendee"]
        assert attendee.params.get("PARTSTAT") == "ACCEPTED"

    def testSchedulingMailboxes(self):
        self.skip_unless_support("scheduling.mailbox")
        inbox = self.principal.schedule_inbox()
        assert inbox is not None
        outbox = self.principal.schedule_outbox()
        assert outbox is not None

    def testFindCalendarOwner(self):
        cal = self._fixCalendar()
        owner = cal.get_property(dav.Owner())
        ## Not all servers expose the DAV:owner property; None is acceptable.
        if owner is None:
            return

        ## The owner URL should point to a principal resource.
        ## Constructing a Principal from it and fetching the vcal address
        ## demonstrates the full workflow from issue #544.
        if self.is_supported("scheduling.calendar-user-address-set"):
            owner_principal = Principal(client=self.caldav, url=owner)
            address = owner_principal.get_vcal_address()
            assert address is not None

    def testIssue397(self):
        self.skip_unless_support("save-load.event.recurrences.exception")
        cal = self._fixCalendar()
        cal.add_event(
            """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//PeterB//caldav//en_DK
BEGIN:VEVENT
SUMMARY:recurrence with attendee one single item
DTSTART;TZID=Europe/Zurich:20240101T090000
DTEND;TZID=Europe/Zurich:20240101T180000
UID:test1
DESCRIPTION:this is the recurrent series
TRANSP:OPAQUE
RRULE:FREQ=WEEKLY;BYDAY=TU,WE,TH
END:VEVENT
BEGIN:VEVENT
SUMMARY:single item
DTSTART;TZID=Europe/Zurich:20240605T090000
DTEND;TZID=Europe/Zurich:20240605T170000
UID:test1
DESCRIPTION:this is the single item assigning a attendee to just one event
ATTENDEE:foo.bar@corge.baz
RECURRENCE-ID:20240605T070000Z
END:VEVENT
END:VCALENDAR
"""
        )

        object_by_id = cal.get_object_by_uid("test1", comp_class=Event)
        instance = object_by_id.icalendar_instance
        events = [event for event in instance.subcomponents if isinstance(event, icalendar.Event)]
        assert len(events) == 2
        object_by_id = cal.get_object_by_uid("test1", comp_class=None)
        instance = object_by_id.icalendar_instance
        events = [event for event in instance.subcomponents if isinstance(event, icalendar.Event)]
        assert len(events) == 2

    def testAddOrphanedRecurrence(self):
        """
        add_event() with an ICS fragment containing only a RECURRENCE-ID override
        (no master RRULE object in the calendar) must not raise NotFoundError.

        Regression test for commit 7269f179 (graceful adding of orphaned recurrences):
        the library was raising NotFoundError before even attempting the PUT.
        Now it falls through to a plain PUT when the master cannot be found.
        """
        self.skip_unless_support("save-load.event")
        cal = self._fixCalendar()
        orphaned_recurrence = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example//CalDAV test//EN
BEGIN:VEVENT
UID:orphaned-recurrence-test-uid@example.com
DTSTAMP:20200101T000000Z
DTSTART:20200115T100000Z
DTEND:20200115T110000Z
RECURRENCE-ID:20200115T100000Z
SUMMARY:Orphaned recurrence with no master
END:VEVENT
END:VCALENDAR"""
        try:
            cal.add_event(orphaned_recurrence)
        except error.NotFoundError:
            pytest.fail(
                "add_event() raised NotFoundError for an orphaned recurrence; "
                "see commit 7269f179 (graceful adding of orphaned recurrences)"
            )
        except Exception:
            ## Some servers may reject an orphaned recurrence with a 4xx error;
            ## that is acceptable server behaviour.  The key guarantee is that
            ## the library does not raise NotFoundError before even attempting the PUT.
            pass

    def testPropfind(self):
        """
        Test of the propfind methods. (This is sort of redundant, since
        this is implicitly run by the setup)
        """
        # ResourceType MUST be defined, and SHOULD be returned on a propfind
        # for "allprop" if I have the permission to see it (RFC4918 section 9.1).
        # A few servers (bedework, CCS) omit it.
        self.skip_unless_support("propfind.allprop.resourcetype")

        # first a raw xml propfind to the root URL
        foo = self.caldav.propfind(
            self.principal.url,
            props='<?xml version="1.0" encoding="UTF-8"?>'
            '<D:propfind xmlns:D="DAV:">'
            "  <D:allprop/>"
            "</D:propfind>",
        )
        assert "resourcetype" in to_local(foo.raw)

        # next, the internal _query_properties, returning an xml tree ...
        # (DAV:status is a response-only element, not a queryable property -
        # asking for it makes some servers, e.g. CCS, answer 400 - so we query a
        # real live property instead and assert on this response, not the first.)
        foo2 = self.principal._query_properties(
            [
                dav.ResourceType(),
            ]
        )
        assert "resourcetype" in to_local(foo2.raw)
        # TODO: more advanced asserts

    def testGetCalendarHomeSet(self):
        chs = self.principal.get_properties([cdav.CalendarHomeSet()])
        assert "{urn:ietf:params:xml:ns:caldav}calendar-home-set" in chs

    def testGetDefaultCalendar(self):
        self.skip_unless_support("get-current-user-principal.has-calendar")
        assert len(self.principal.get_calendars()) != 0

    def testSearchShouldYieldData(self):
        """
        ref https://github.com/python-caldav/caldav/issues/201
        """
        ## Test breaks for OX (because it does not support old events in any meaningful way).
        self.skip_unless_support("search.unlimited-time-range")

        c = self._fixCalendar()

        if self.is_supported("save-load.event"):
            ## populate the calendar with an event or two or three
            c.add_event(ev1)
            c.add_event(ev2)
            c.add_event(ev3)
        objects = c.search(event=True)
        ## This will break if served a read-only calendar without any events
        assert objects
        ## This was observed to be broken for @dreimer1986
        assert objects[0].data

    def testGetCalendar(self):
        # Create calendar
        c = self._fixCalendar()
        assert c.url is not None
        assert len(self.principal.get_calendars()) != 0

        str_ = str(c)
        repr_ = repr(c)
        assert str_ and repr_

        ## Not sure if those asserts make much sense, the main point here is to exercise
        ## the __str__ and __repr__ methods on the Calendar object.
        if self.is_supported("create-calendar.set-displayname"):
            name = c.get_property(dav.DisplayName(), use_cached=True)
            if not name:
                name = c.url
            assert str(name) == str_
        assert "Calendar" in repr(c)
        assert str(c.url) in repr(c)

    def _notFound(self, collection=False):
        """The exception class a lookup of something non-existing may raise.

        ``collection=True`` for a lookup of a missing *calendar*, which some
        servers answer differently from a missing calendar *object*: Robur
        answers 403 for both, but ``load()`` retries a missing object as a
        multiget against the existing parent calendar and gets a 404 out of it,
        so only the collection lookup surfaces the AuthorizationError.  The two
        are siblings under ``non-existing-raises-not-found`` for that reason -
        neither answer can be derived from the other.
        """
        feature = "non-existing-raises-not-found." + ("collection" if collection else "object")
        if self.is_supported(feature):
            return error.NotFoundError
        else:
            ## Some servers answer 403 instead of 404 (e.g. Robur); accept any
            ## DAVError in that case.
            return error.DAVError

    def testPrincipal(self):
        collections = self.principal.get_calendars()
        if "principal_url" in self.server_params:
            assert self.principal.url == self.server_params["principal_url"]
        for c in collections:
            assert c.__class__.__name__ == "Calendar"

    def testPrincipals(self):
        self.skip_unless_support("principal-search")
        if self.is_supported("principal-search.by-name.self"):
            my_name = self.principal.get_display_name()
            my_principals = self.caldav.principals(name=my_name)
            assert isinstance(my_principals, list)
            assert len(my_principals) == 1
            assert my_principals[0].url == self.principal.url

        self.skip_unless_support("principal-search.list-all")
        all_principals = self.caldav.principals()
        assert isinstance(all_principals, list)
        if all_principals:
            assert all(isinstance(x, Principal) for x in all_principals)

    def testCreateDeleteCalendar(self):
        self.skip_unless_support("create-calendar")
        self.skip_unless_support("delete-calendar")
        # Always try to delete the calendar first in case a previous test run
        # was interrupted and left the calendar behind
        self._teardownCalendar(cal_id=self.testcal_id)
        c = self.principal.make_calendar(name="Yep", cal_id=self.testcal_id)

        assert c.url is not None
        events = c.get_events()
        assert len(events) == 0
        events = self.principal.calendar(name="Yep", cal_id=self.testcal_id).get_events()
        assert len(events) == 0
        c.delete()

        if not self.is_supported("create-calendar.auto"):
            # Two separate pytest.raises blocks: with both probes in a single
            # block, the first one to raise would short-circuit the second,
            # leaving it untested (and on auto-create servers get_events()
            # doesn't raise at all, so the block passed only because
            # get_display_name() happened to 404).
            with pytest.raises(self._notFound(collection=True)):
                self.principal.calendar(cal_id="shouldnotexist").get_events()
            with pytest.raises(self._notFound(collection=True)):
                self.principal.calendar(cal_id="shouldnotexist").get_display_name()

    def testChangeAttendeeStatusWithEmailGiven(self):
        self.skip_unless_support("save-load.event")
        ## Some servers (e.g. OX) forbid changing an attendee's PARTSTAT via a
        ## direct PUT (403 Forbidden) and require iTIP scheduling instead.
        self.skip_unless_support("save-load.mutable.attendee-partstat")
        c = self._fixCalendar()

        event = c.add_event(
            uid="test1",
            dtstart=datetime(2015, 10, 10, 8, 7, 6),
            dtend=datetime(2015, 10, 10, 9, 7, 6),
            ical_fragment="ATTENDEE;ROLE=OPT-PARTICIPANT;PARTSTAT=TENTATIVE:MAILTO:testuser@example.com",
        )
        event.change_attendee_status(attendee="testuser@example.com", PARTSTAT="ACCEPTED")
        event.save()
        event = c.get_event_by_uid("test1")
        ## TODO: work in progress ... see https://github.com/python-caldav/caldav/issues/399

    def testMultiGet(self):
        self.skip_unless_support("save-load.event")
        c = self._fixCalendar()

        event1 = c.add_event(
            uid="test1",
            dtstart=datetime(2015, 10, 10, 8, 7, 6),
            dtend=datetime(2015, 10, 10, 9, 7, 6),
            summary="test1",
        )

        event2 = c.add_event(
            uid="test2",
            dtstart=datetime(2015, 10, 10, 8, 7, 6),
            dtend=datetime(2015, 10, 10, 9, 7, 6),
            summary="test2",
        )

        results = c.calendar_multiget([event1.url, event2.url])
        assert len(results) == 2
        assert set([x.icalendar_component["uid"] for x in results]) == {
            "test1",
            "test2",
        }
        event1.load_by_multiget()

    def testCreateEvent(self):
        self.skip_unless_support("save-load.event")
        c = self._fixCalendar()

        existing_events = c.get_events()
        existing_urls = {x.url for x in existing_events}

        def cleanse(events):
            return [x for x in events if x.url not in existing_urls]

        if self.is_supported("create-calendar"):
            ## we're supposed to be working towards a brand new calendar
            assert len(existing_events) == 0

        # add event (near-now date so it stays visible to REPORT-based lookups
        # on sliding-window servers; see near_now_ics)
        c.add_event(near_now_ics(broken_ev1))

        # c.get_events() should give a full list of events
        events = cleanse(c.get_events())
        assert len(events) == 1

        # We should be able to access the calender through the URL
        c2 = self.caldav.calendar(url=c.url)
        events2 = cleanse(c2.get_events())
        assert len(events2) == 1
        assert events2[0].url == events[0].url

        if (
            self.is_supported("create-calendar")
            and self.is_supported("create-calendar.set-displayname")
            ## _fixCalendar only gives the calendar a display name ("Yep") when
            ## the server also keeps the URL stable; on servers that assign a
            ## different canonical URL when a name is set (Zimbra, OX) the fixture
            ## is created nameless.
            and self.is_supported("create-calendar.stable-url")
        ):
            ## We should be able to access the calender through the name
            c2 = self.principal.calendar(name="Yep")
            ## (but may break if we have multiple calendars with the same name)
            if (
                self.is_supported("delete-calendar")
                or self.is_supported("delete-calendar", str) == "fragile"
            ):
                ## A name lookup may return a different (canonical) calendar URL
                ## than the one we created it at on servers that don't preserve
                ## the URL (e.g. OX exposes the calendar under an internal
                ## cal://0/NNN id); see save-load.stable-url.
                if self.is_supported("save-load.stable-url"):
                    assert c2.url == c.url
                events2 = cleanse(c2.get_events())
                assert len(events2) == 1
                assert events2[0].url == events[0].url

        # add another event, it should be doable without having premade ICS
        _dt = datetime.now() + timedelta(days=31)
        ev2 = c.add_event(
            dtstart=_dt,
            summary="This is a test event",
            dtend=_dt + timedelta(hours=1),
            uid="ctuid1",
        )
        events = c.get_events()
        assert len(events) == len(existing_events) + 2
        ev2.delete()

    def testNamedCalendarUrlIsUsable(self):
        """A calendar created WITH a display name must be fully usable by URL.

        Exercises create-calendar.stable-url: on servers that assign a different
        canonical URL when a name is set (unsupported - Zimbra relocates the
        collection to a display-name-derived path, OX uses an opaque cal://0/NNN),
        Calendar._create() must discover and adopt the canonical URL so that
        object operations addressed via the returned calendar's .url resolve.
        Regression guard for the Zimbra "event 404s on the cal_id URL even though
        the collection is reachable there" quirk.  On stable servers the calendar
        simply stays at the requested cal_id and the test still passes.
        """
        self.skip_unless_support("create-calendar")
        self.skip_unless_support("create-calendar.set-displayname")
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("delete-calendar")

        cal_id = self.testcal_id + "-named-url"
        name = "csc-repoint-" + str(uuid.uuid4())
        self._teardownCalendar(cal_id=cal_id)
        cal = self.principal.make_calendar(cal_id=cal_id, name=name)
        try:
            ## the display name stuck (set-displayname is supported)
            assert cal.get_display_name() == name

            ## store an event and look it up BY URL through the returned calendar;
            ## cal.url must point at the address that actually resolves.
            uid = "csc-repoint-" + str(uuid.uuid4())
            _dt = datetime.now() + timedelta(days=20)
            stored = cal.add_event(
                dtstart=_dt,
                dtend=_dt + timedelta(hours=1),
                summary="re-point url test",
                uid=uid,
            )

            ## REPORT-based lookup may lag on indexing servers (e.g. OX); retry.
            fetched = None
            for _ in range(10):
                try:
                    fetched = cal.event_by_url(stored.url)
                    break
                except error.NotFoundError:
                    time.sleep(1)
            assert fetched is not None, "event not retrievable by URL on the created calendar"
            assert fetched.url == stored.url
            assert fetched.icalendar_component["uid"] == uid
        finally:
            try:
                cal.delete()
            except Exception:
                logging.warning(f"unable to delete calendar {cal.url} with name {name}")
            self._teardownCalendar(cal_id=cal_id)

    @pytest.mark.parametrize("klass", ["Calendar", "Event"])
    def testCreateEventFromiCal(self, klass):
        c = self._fixCalendar()
        try:  ## TODO: remove this try-except
            icalcal = icalendar.Calendar.new()
        except:
            ## Calendar.new() is supported from icalendar 7, which is yet to be released as of 2025-09
            pytest.skip("Newer icalendar version required")

        ## Use a near-future date so servers with a "sliding window" (e.g. OX) can find the event
        start = datetime.now() + timedelta(days=30)
        end = start + timedelta(hours=1)
        icalevent = icalendar.Event.new(
            uid="ctuid1",
            start=start,
            end=end,
            summary="This is a test event",
        )
        icalcal.add_component(icalevent)

        ## Parametrized test - we should test both with the Calendar object and the Event object
        obj = {"Calendar": icalcal, "Event": icalevent}[klass]
        event = c.add_event(obj)
        assert event is not None
        events = c.get_events()
        assert len([x for x in events if x.icalendar_component["uid"] == "ctuid1"]) == 1

    def testAlarm(self):
        ## Ref https://github.com/python-caldav/caldav/issues/132
        c = self._fixCalendar()
        ev = c.add_event(
            dtstart=datetime(2015, 10, 10, 8, 0, 0),
            summary="This is a test event",
            uid="test1",
            dtend=datetime(2016, 10, 10, 9, 0, 0),
            alarm_trigger=timedelta(minutes=-15),
            alarm_action="AUDIO",
        )
        assert ev is not None

        self.skip_unless_support("search.time-range.alarm")

        ## So we have an alarm that goes off 07:45 for an event starting 08:00

        ## Search for alarms after 8 should find nothing
        ## (search for an alarm 07:55 - 08:05 should most likely find nothing).
        assert (
            len(
                c.search(
                    event=True,
                    alarm_start=datetime(2015, 10, 10, 8, 1),
                    alarm_end=datetime(2015, 10, 10, 8, 7),
                )
            )
            == 0
        )

        ## Search for alarms from 07:40 to 07:55 should definitively find the alarm.
        assert (
            len(
                c.search(
                    event=True,
                    alarm_start=datetime(2015, 10, 10, 7, 40),
                    alarm_end=datetime(2015, 10, 10, 7, 55),
                )
            )
            == 1
        )

    def testCalendarByFullURL(self):
        """
        ref private email, passing a full URL as cal_id works in 0.5.0 but
        is broken in 0.8.0
        """
        mycal = self._fixCalendar()

        samecal = self.caldav.principal().calendar(cal_id=str(mycal.url))
        assert mycal.url.canonical() == samecal.url.canonical()
        ## passing cal_id as a URL object should also work.
        samecal = self.caldav.principal().calendar(cal_id=mycal.url)
        assert mycal.url.canonical() == samecal.url.canonical()

    def testObjectByUID(self):
        """
        It should be possible to save a task and retrieve it by uid
        """
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])
        c.add_todo(summary="Some test task with a well-known uid", uid="well_known_1")
        foo = c.get_object_by_uid("well_known_1")
        assert foo.component["summary"] == "Some test task with a well-known uid"
        with pytest.raises(error.NotFoundError):
            foo = c.get_object_by_uid("well_known")
        with pytest.raises(error.NotFoundError):
            foo = c.get_object_by_uid("well_known_10")

    def testObjectBySyncToken(self):
        """
        Support for sync-collection reports, ref https://github.com/python-caldav/caldav/issues/87.
        This test is using explicit calls to objects_by_sync_token
        """
        self.skip_unless_support("save-load.event")

        ## Boiler plate ... make a calendar and add some content
        c = self._fixCalendar()
        objcnt = 0
        ## in case we need to reuse an existing calendar ...
        if self.is_supported("save-load.todo.mixed-calendar"):
            objcnt += len(c.get_todos())
        objcnt += len(c.get_events())
        obj = c.add_event(near_now_ics(ev1))
        objcnt += 1
        if self.is_supported("save-load.event.recurrences"):
            c.add_event(evr)
            objcnt += 1
        if self.is_supported("save-load.todo.mixed-calendar"):
            c.add_todo(todo)
            c.add_todo(todo2)
            c.add_todo(todo3)
            objcnt += 3

        ## Check if sync tokens are time-based (need sleep(1) between operations)
        sync_info = self.is_supported("sync-token", return_type=dict)
        is_time_based = sync_info.get("behaviour") == "time-based"
        ## Consider the client-side fake sync-tokens and etag stuff to be fragile
        is_fragile = sync_info.get("support") in (
            "fragile",
            "broken",
            "unsupported",
            "ungraceful",
        )

        if is_time_based:
            time.sleep(1)

        ## objects should return all objcnt object.
        my_objects = c.objects()
        assert my_objects.sync_token != ""
        assert len(list(my_objects)) == objcnt

        ## They should not be loaded (unless using fallback fake tokens).
        ## Fake tokens are used when the server doesn't support sync-collection,
        ## and in that case objects will have data because search() loads them.
        is_using_fallback = my_objects.sync_token.startswith("fake-")
        if not is_using_fallback:
            for some_obj in my_objects:
                assert some_obj.data is None

        if is_time_based:
            time.sleep(1)

        ## running sync_token again with the new token should return 0 hits
        my_changed_objects = c.get_objects_by_sync_token(sync_token=my_objects.sync_token)
        if not is_fragile:
            assert len(list(my_changed_objects)) == 0

        ## I was unable to run the rest of the tests towards Google using their legacy caldav API
        self.skip_unless_support("save-load.mutable")

        ## MODIFYING an object
        if is_time_based:
            time.sleep(1)
        obj.icalendar_instance.subcomponents[0]["SUMMARY"] = "foobar"
        obj.save()

        if is_time_based:
            time.sleep(1)

        ## The modified object should be returned by the server
        my_changed_objects = c.get_objects_by_sync_token(
            sync_token=my_changed_objects.sync_token, load_objects=True
        )
        if is_fragile:
            assert len(list(my_changed_objects)) >= 1
        else:
            assert len(list(my_changed_objects)) == 1

        ## this time it should be loaded
        assert list(my_changed_objects)[0].data is not None

        if is_time_based:
            time.sleep(1)

        ## Re-running objects_by_sync_token, and no objects should be returned
        my_changed_objects = c.get_objects_by_sync_token(sync_token=my_changed_objects.sync_token)

        if not is_fragile:
            assert len(list(my_changed_objects)) == 0

        ## ADDING yet another object ... and it should also be reported
        if is_time_based:
            time.sleep(1)
        c.add_event(near_now_ics(ev3))
        if is_time_based:
            time.sleep(1)
        my_changed_objects = c.get_objects_by_sync_token(sync_token=my_changed_objects.sync_token)
        if not is_fragile:
            assert len(list(my_changed_objects)) == 1

        if is_time_based:
            time.sleep(1)

        ## Re-running objects_by_sync_token, and no objects should be returned
        my_changed_objects = c.get_objects_by_sync_token(sync_token=my_changed_objects.sync_token)
        if not is_fragile:
            assert len(list(my_changed_objects)) == 0

        if is_time_based:
            time.sleep(1)

        ## DELETING the object ... and it should be reported
        obj.delete()
        self.skip_unless_support("sync-token.delete")
        if is_time_based:
            time.sleep(1)
        my_changed_objects = c.get_objects_by_sync_token(
            sync_token=my_changed_objects.sync_token, load_objects=True
        )
        if not is_fragile:
            assert len(list(my_changed_objects)) == 1
        if is_time_based:
            time.sleep(1)
        ## even if we have asked for the object to be loaded, data should be None as it's a deleted object
        assert list(my_changed_objects)[0].data is None

        ## Re-running objects_by_sync_token, and no objects should be returned
        my_changed_objects = c.get_objects_by_sync_token(sync_token=my_changed_objects.sync_token)
        if not is_fragile:
            assert len(list(my_changed_objects)) == 0

    def testSync(self):
        """
        Support for sync-collection reports, ref https://github.com/python-caldav/caldav/issues/87.
        Same test pattern as testObjectBySyncToken, but exercises the .sync() method
        """
        self.skip_unless_support("save-load.event")

        ## Check if sync tokens are time-based (need sleep(1) between operations)
        sync_info = self.is_supported("sync-token", return_type=dict)
        is_time_based = sync_info.get("behaviour") == "time-based"
        ## Consider the client-side fake sync-tokens and etag stuff to be fragile
        is_fragile = sync_info.get("support") in (
            "fragile",
            "broken",
            "unsupported",
            "ungraceful",
        )

        ## Boiler plate ... make a calendar and add some content
        c = self._fixCalendar()

        objcnt = 0
        ## in case we need to reuse an existing calendar ...
        if self.is_supported("save-load.todo.mixed-calendar"):
            objcnt += len(c.get_todos())
        objcnt += len(c.get_events())
        obj = c.add_event(near_now_ics(ev1))
        objcnt += 1
        if self.is_supported("save-load.event.recurrences"):
            c.add_event(evr)
            objcnt += 1
        if self.is_supported("save-load.todo.mixed-calendar"):
            c.add_todo(todo)
            c.add_todo(todo2)
            c.add_todo(todo3)
            objcnt += 3

        if is_time_based:
            time.sleep(1)

        ## objects should return all objcnt object.
        my_objects = c.objects(load_objects=True)
        assert my_objects.sync_token != ""
        assert len(list(my_objects)) == objcnt

        stable_url = self.is_supported("save-load.stable-url")

        def synced_match(o):
            """Return the synced object corresponding to o, or None.

            objects_by_url() is keyed by the server-reported URL, which on
            servers that don't preserve the PUT URL (e.g. OX; see
            save-load.stable-url) differs from o.url - so fall back to matching
            by UID there.
            """
            synced = my_objects.objects_by_url()
            if stable_url:
                return synced.get(o.url)
            uid = o.icalendar_component["uid"]
            return next(
                (cand for cand in synced.values() if cand.icalendar_component["uid"] == uid),
                None,
            )

        if is_time_based:
            time.sleep(1)

        ## sync() should do nothing
        updated, deleted = my_objects.sync()
        if not is_fragile:
            assert len(list(updated)) == 0
            assert len(list(deleted)) == 0

        if is_time_based:
            time.sleep(1)

        ## I was unable to run the rest of the tests towards Google using their legacy caldav API
        self.skip_unless_support("save-load.mutable")

        ## MODIFYING an object
        obj.icalendar_instance.subcomponents[0]["SUMMARY"] = "foobar"
        obj.save()

        if is_time_based:
            time.sleep(1)

        updated, deleted = my_objects.sync()
        if not is_fragile:
            assert len(list(updated)) == 1
            assert len(list(deleted)) == 0
        assert "foobar" in synced_match(obj).data

        if is_time_based:
            time.sleep(1)

        ## ADDING yet another object ... and it should also be reported
        obj3 = c.add_event(near_now_ics(ev3))

        if is_time_based:
            time.sleep(1)

        updated, deleted = my_objects.sync()
        if not is_fragile:
            assert len(list(updated)) == 1
            assert len(list(deleted)) == 0
        assert synced_match(obj3) is not None

        self.skip_unless_support("sync-token.delete")

        if is_time_based:
            time.sleep(1)

        ## DELETING the object ... and it should be reported
        obj.delete()
        if is_time_based:
            time.sleep(1)
        updated, deleted = my_objects.sync()
        if not is_fragile:
            assert len(list(updated)) == 0
            assert len(list(deleted)) == 1
        assert synced_match(obj) is None

        if is_time_based:
            time.sleep(1)

        ## sync() should do nothing
        updated, deleted = my_objects.sync()
        if not is_fragile:
            assert len(list(updated)) == 0
            assert len(list(deleted)) == 0

    def testLoadEvent(self):
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("create-calendar")
        if self.cleanup_regime in ("light", "pre"):
            self._teardownCalendar(cal_id=self.testcal_id)
            self._teardownCalendar(cal_id=self.testcal_id2)
        c1 = self._fixCalendar(name="Yep", cal_id=self.testcal_id)
        c2 = self._fixCalendar(name="Yapp", cal_id=self.testcal_id2)
        assert c2 is not None

        e1_ = c1.add_event(near_now_ics(ev1))
        if not self.check_compatibility_flag("event_by_url_is_broken"):
            e1_.load()
        e1 = c1.get_events()[0]
        if not self.check_compatibility_flag("event_by_url_is_broken"):
            ## e1 came from a search and may carry a different (canonical) URL
            ## than the PUT URL on servers that don't preserve it (e.g. OX); see
            ## save-load.stable-url.
            if self.is_supported("save-load.stable-url"):
                assert e1.url == e1_.url
            e1.load()
        if self.cleanup_regime == "post":
            self._teardownCalendar(cal_id=self.testcal_id)
            self._teardownCalendar(cal_id=self.testcal_id2)

    def testCopyEvent(self):
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("create-calendar")
        if self.cleanup_regime in ("light", "pre"):
            self._teardownCalendar(cal_id=self.testcal_id)
            self._teardownCalendar(cal_id=self.testcal_id2)

        ## Let's create two calendars, and populate one event on the first calendar
        c1 = self._fixCalendar(name="Yep", cal_id=self.testcal_id)
        c2 = self._fixCalendar(name="Yapp", cal_id=self.testcal_id2)

        assert not len(c1.get_events())
        assert not len(c2.get_events())
        e1_ = c1.add_event(near_now_ics(ev1))
        assert e1_ is not None
        e1 = c1.get_events()[0]

        if self.is_supported("save.duplicate-event"):
            ## Duplicate the event in the same calendar, with new uid
            e1_dup = e1.copy()
            e1_dup.save()
            assert len(c1.get_events()) == 2

        if self.is_supported("save.duplicate-uid.cross-calendar"):
            e1_in_c2 = e1.copy(new_parent=c2, keep_uid=True)
            e1_in_c2.save()
            assert len(c2.get_events()) == 1

            ## what will happen with the event in c1 if we modify the event in c2,
            ## which shares the id with the event in c1?
            e1_in_c2.vobject_instance.vevent.summary.value = "asdf"
            e1_in_c2.save()
            if not self.check_compatibility_flag("event_by_url_is_broken"):
                e1.load()
                ## should e1.summary be 'asdf' or 'Bastille Day Party'?  I do
                ## not know, but all implementations I've tested will treat
                ## the copy in the other calendar as a distinct entity, even
                ## if the uid is the same.
                assert e1.vobject_instance.vevent.summary.value == "Bastille Day Party"
            assert c2.get_events()[0].vobject_instance.vevent.uid == e1.vobject_instance.vevent.uid

        ## Duplicate the event in the same calendar, with same uid -
        ## this makes no sense, there won't be any duplication
        e1_dup2 = e1.copy(keep_uid=True)
        e1_dup2.save()
        if self.is_supported("save.duplicate-event"):
            assert len(c1.get_events()) == 2
        else:
            assert len(c1.get_events()) == 1

        if self.cleanup_regime == "post":
            self._teardownCalendar(cal_id=self.testcal_id)
            self._teardownCalendar(cal_id=self.testcal_id2)

    def testCreateCalendarAndEventFromVobject(self):
        self.skip_unless_support("save-load.event")
        c = self._fixCalendar()

        ## in case the calendar is reused
        cnt = len(c.get_events())

        # add event from vobject data (near-now date so it stays visible to
        # REPORT-based lookups on sliding-window servers; see near_now_ics)
        ve1 = vobject.readOne(near_now_ics(ev1))
        c.add_event(ve1)
        cnt += 1

        # c.get_events() should give a full list of events
        events = c.get_events()
        assert len(events) == cnt

        # This makes no sense, it's a noop.  Perhaps an error
        # should be raised, but as for now, this is simply ignored.
        c.add_event(None)
        assert len(c.get_events()) == cnt

    def testGetSupportedComponents(self):
        c = self._fixCalendar()

        components = c.get_supported_components()
        assert components
        assert "VEVENT" in components

    def testSearchEvent(self):
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("search")
        self.skip_unless_support("search.time-range.event.old-dates")
        c = self._fixCalendar()

        c.add_event(ev1)
        c.add_event(ev3)
        c.add_event(evr)

        ## Search without any parameters should yield everything on calendar
        all_events = c.search()
        assert len(all_events) <= 3

        ## Search with comp_class set to Event should yield all events on calendar
        all_events = c.search(comp_class=Event)
        assert len(all_events) == 3

        ## Search with todo flag set should yield no events
        try:
            no_events = c.search(todo=True)
        except:
            no_events = []
        assert len(no_events) == 0

        ## Date search should be possible
        some_events = c.search(
            comp_class=Event,
            expand=False,
            start=datetime(2006, 7, 13, 13, 0),
            end=datetime(2006, 7, 15, 13, 0),
        )
        if not self.check_compatibility_flag("fastmail_buggy_noexpand_date_search"):
            assert len(some_events) == 1

        ## Search for misc text fields
        ## UID is a special case, supported by almost all servers
        some_events = c.search(comp_class=Event, uid="19970901T130000Z-123403@example.com")
        assert len(some_events) == 1

        ## class
        some_events = c.search(comp_class=Event, class_="CONFIDENTIAL")
        assert len(some_events) == 1

        ## not defined
        some_events = c.search(comp_class=Event, no_class=True)
        ## ev1, ev3 should be returned
        ## or perhaps not,
        ## ref https://gitlab.com/davical-project/davical/-/issues/281#note_1265743591
        ## PUBLIC is default, so maybe no events should be returned?
        assert (
            len(some_events) == 2
            or len([x for x in all_events if x.icalendar_component["class"] == "PUBLIC"]) == 2
        )

        some_events = c.search(comp_class=Event, no_category=True)
        ## ev1, ev3 should be returned
        assert len(some_events) == 2

        some_events = c.search(comp_class=Event, no_dtend=True)
        ## evr should be returned
        assert len(some_events) == 1

        ## category
        some_events = c.search(comp_class=Event, category="PERSONAL")
        assert len(some_events) == 1
        some_events = c.search(comp_class=Event, category="personal")
        assert len(some_events) == 0
        searcher = CalDAVSearcher(comp_class=Event)
        searcher.add_property_filter("category", "personal", case_sensitive=False)
        some_events = searcher.search(c)
        assert len(some_events) == 1

        ## It will not match if categories field is set to "PERSONAL,ANNIVERSARY,SPECIAL OCCASION"
        ## It may not match since the above is to be considered equivalent to the raw data entered.
        some_events = c.search(comp_class=Event, category="ANNIVERSARY,PERSONAL,SPECIAL OCCASION")
        assert len(some_events) in (0, 1)
        some_events = c.search(comp_class=Event, category="PERSON")
        assert len(some_events) == 1

        ## explicit substring search will force through a substring
        ## search even if the server does not support it
        searcher = CalDAVSearcher(comp_class=Event)
        searcher.add_property_filter("category", "PERSON", operator="contains")
        assert len(searcher.search(c)) == 1

        ## I expect "logical and" when combining category with a date range
        no_events = c.search(
            comp_class=Event,
            category="PERSONAL",
            start=datetime(2006, 7, 13, 13, 0),
            end=datetime(2006, 7, 15, 13, 0),
        )
        assert len(no_events) == 0
        some_events = c.search(
            comp_class=Event,
            category="PERSONAL",
            start=datetime(1997, 11, 1, 13, 0),
            end=datetime(1997, 11, 3, 13, 0),
        )
        assert len(some_events) == 1

        some_events = c.search(comp_class=Event, summary="Bastille Day Party")
        assert len(some_events) == 1

        some_events = c.search(comp_class=Event, summary="Bastille Day")
        ## fragile substring searches => anything could happen
        if self.is_supported("search.text.substring", str) == "fragile":
            assert len(some_events) in (0, 2)
        ## substring search not offered => implicit substring search is ignored.
        ## EXCEPT if text search is not offered - then the filtering logic will be done client-side
        if not self.is_supported("search.text.substring") and self.is_supported("search.text"):
            assert len(some_events) == 0
        else:
            assert len(some_events) == 2

        ## Explicit substring filter should always work
        searcher = CalDAVSearcher(event=True)
        searcher.add_property_filter("summary", "Bastille Day", "contains")
        some_events = searcher.search(c)
        assert len(some_events) == 2

        ## An explicit substring search should always do a substring search
        searcher = CalDAVSearcher(event=True)
        searcher.add_property_filter("summary", "Bastille Day", "contains")
        assert len(searcher.search(c)) == 2

        ## Even sorting should work out
        all_events = c.search(sort_keys=("summary", "dtstamp"))
        assert len(all_events) == 3
        assert all_events[0].vobject_instance.vevent.summary.value == "Bastille Day Jitsi Party"

        ## Sorting by upper case should also wor
        all_events = c.search(sort_keys=("SUMMARY", "DTSTAMP"))
        assert len(all_events) == 3
        assert all_events[0].vobject_instance.vevent.summary.value == "Bastille Day Jitsi Party"

        ## Sorting in reverse order should work also
        all_events = c.search(sort_keys=("SUMMARY", "DTSTAMP"), sort_reverse=True)
        assert len(all_events) == 3
        assert all_events[0].vobject_instance.vevent.summary.value == "Our Blissful Anniversary"

        ## A more robust check for the sort key
        all_events = c.search(sort_keys=("DTSTART",))
        assert len(all_events) == 3
        assert str(all_events[0].icalendar_component["DTSTART"].dt) < str(
            all_events[1].icalendar_component["DTSTART"].dt
        )
        assert str(all_events[1].icalendar_component["DTSTART"].dt) < str(
            all_events[2].icalendar_component["DTSTART"].dt
        )
        all_events = c.search(sort_keys=("DTSTART",), sort_reverse=True)
        assert str(all_events[0].icalendar_component["DTSTART"].dt) > str(
            all_events[1].icalendar_component["DTSTART"].dt
        )
        assert str(all_events[1].icalendar_component["DTSTART"].dt) > str(
            all_events[2].icalendar_component["DTSTART"].dt
        )

        ## Ref https://github.com/python-caldav/caldav/issues/448
        all_events = c.search(sort_keys=("DTSTART"))
        assert len(all_events) == 3
        assert str(all_events[0].icalendar_component["DTSTART"].dt) < str(
            all_events[1].icalendar_component["DTSTART"].dt
        )
        assert str(all_events[1].icalendar_component["DTSTART"].dt) < str(
            all_events[2].icalendar_component["DTSTART"].dt
        )
        all_events = c.search(sort_keys=("DTSTART"), sort_reverse=True)
        assert str(all_events[0].icalendar_component["DTSTART"].dt) > str(
            all_events[1].icalendar_component["DTSTART"].dt
        )
        assert str(all_events[1].icalendar_component["DTSTART"].dt) > str(
            all_events[2].icalendar_component["DTSTART"].dt
        )

    def testSearchSortTodo(self):
        self.skip_unless_support("save-load.todo")
        self.skip_unless_support("search")
        ## Test breaks for OX (because it does not support old events in any meaningful way).
        self.skip_unless_support("search.unlimited-time-range")
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])
        pre_todos = c.get_todos()
        pre_todo_uid_map = {x.icalendar_component["uid"] for x in pre_todos}

        def cleanse(tasks):
            return [x for x in tasks if x.icalendar_component["uid"] not in pre_todo_uid_map]

        t1 = c.add_todo(
            summary="1 task overdue",
            due=date(2022, 12, 12),
            dtstart=date(2022, 10, 11),
            uid="test1",
        )
        assert t1.is_pending()
        t2 = c.add_todo(
            summary="2 task future",
            due=datetime.now() + timedelta(hours=15),
            dtstart=datetime.now() + timedelta(minutes=15),
            uid="test2",
        )
        assert t2 is not None
        t3 = c.add_todo(
            summary="3 task future due",
            due=datetime.now() + timedelta(hours=15),
            dtstart=datetime(2022, 12, 11, 10, 9, 8),
            uid="test3",
        )
        assert t3 is not None
        t4 = c.add_todo(
            summary="4 task priority is set to nine which is the lowest",
            priority=9,
            uid="test4",
        )
        assert t4 is not None
        t5 = c.add_todo(
            summary="5 task status is set to COMPLETED and this will disappear from the ordinary todo search",
            status="COMPLETED",
            uid="test5",
        )
        assert not t5.is_pending()
        t6 = c.add_todo(
            summary="6 task has categories",
            categories="home,garden,sunshine",
            uid="test6",
        )
        assert t6 is not None

        def check_order(tasks, order):
            assert [str(x.icalendar_component["uid"]) for x in tasks] == [
                "test" + str(x) for x in order
            ]

        all_tasks = cleanse(c.search(todo=True, sort_keys=("uid",)))
        check_order(all_tasks, (1, 2, 3, 4, 6))

        all_tasks = cleanse(c.search(sort_keys=("summary",)))
        check_order(all_tasks, (1, 2, 3, 4, 5, 6))

        all_tasks = cleanse(
            c.search(
                sort_keys=(
                    "isnt_overdue",
                    "categories",
                    "dtstart",
                    "priority",
                    "status",
                )
            )
        )
        ## This is difficult ...
        ## * 1 is the only one that is overdue, and False sorts before True, so 1 comes first
        ## * categories, empty string sorts before a non-empty string, so 6 is at the end of the list
        ## So we have 2-5 still to worry about ...
        ## * dtstart - default is "long ago", so 4,5 or 5,4 should be first, followed by 3,2
        ## * priority - default is 0, so 5 comes before 4
        check_order(all_tasks, (1, 5, 4, 3, 2, 6))

    def testSearchTodos(self):
        self.skip_unless_support("save-load.todo")
        self.skip_unless_support("search")
        ## Test breaks for OX (because it does not support old events in any meaningful way).
        self.skip_unless_support("search.unlimited-time-range")
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])

        pre_cnt = len(c.get_todos())

        t1 = c.add_todo(todo)
        assert t1 is not None
        t2 = c.add_todo(todo2)
        assert t2 is not None
        t3 = c.add_todo(todo3)
        t4 = c.add_todo(todo4)
        assert t4 is not None
        t5 = c.add_todo(todo5)
        t6 = c.add_todo(todo6)

        ## Search without any parameters should yield everything on calendar
        all_todos = c.search()
        if not self.is_supported("search.comp-type.optional"):
            assert len(all_todos) <= 6 + pre_cnt
        else:
            assert len(all_todos) == 6 + pre_cnt

        ## Search with comp_class set to Event should yield all events on calendar
        all_todos = c.search(comp_class=Event)
        assert len(all_todos) == 0 + pre_cnt

        ## Search with todo flag set should yield all 6 tasks
        ## (Except, if the calendar server does not support is-not-defined very
        ## well, perhaps only 3 will be returned - see
        ## https://gitlab.com/davical-project/davical/-/issues/281 )
        all_todos = c.search(todo=True)
        if not self.is_supported("search.is-not-defined"):
            assert len(all_todos) - pre_cnt in (3, 6)
        else:
            assert len(all_todos) == 6 + pre_cnt

        ## Search for misc text fields
        ## UID is a special case, supported by almost all servers
        some_todos = c.search(comp_class=Todo, uid="19970901T130000Z-123404@host.com")
        if self.is_supported("search.text"):
            assert len(some_todos) == 1 + pre_cnt

        ## class ... hm, all 6 example todos are 'CONFIDENTIAL' ...
        some_todos = c.search(comp_class=Todo, class_="CONFIDENTIAL")
        if self.is_supported("search.text"):
            assert len(some_todos) == 6 + pre_cnt

        ## category
        ## Too much copying of the examples ...
        some_todos = c.search(comp_class=Todo, category="FINANCE")
        assert len(some_todos) == 6 + pre_cnt
        some_todos = c.search(comp_class=Todo, category="finance")
        assert len(some_todos) == 0 + pre_cnt
        searcher = CalDAVSearcher(comp_class=Todo)
        searcher.add_property_filter("category", "finance", case_sensitive=False)
        some_todos = searcher.search(c)
        assert len(some_todos) == 6 + pre_cnt
        some_todos = c.search(comp_class=Todo, categories="FAMILY,FINANCE")
        assert len(some_todos) - pre_cnt == 6
        ## TODO: We should consider to do client side filtering to ensure exact
        ## match only on components having MIL as a category (and not FAMILY)
        some_todos = c.search(comp_class=Todo, categories="MIL")
        assert len(some_todos) == 0
        some_todos = c.search(comp_class=Todo, category="MIL")
        if self.is_supported("search.text.substring") and self.is_supported(
            "search.text.category.substring"
        ):
            assert len(some_todos) == 6
        else:
            assert len(some_todos) in (0, 6)

        ## If the server is known to not support substring searches, the client should work around this
        searcher = CalDAVSearcher(comp_class=Todo)
        searcher.add_property_filter("category", "MIL", operator="contains")
        assert len(searcher.search(c)) == 6

        ## completing events, and it should not show up anymore
        assert t3.is_pending()
        t3.complete()
        t5.complete()
        t6.complete()
        assert not t3.is_pending()

        some_todos = c.search(todo=True)
        assert len(some_todos) == 3 + pre_cnt

        ## unless we specifically ask for completed tasks
        all_todos = c.search(todo=True, include_completed=True)
        assert len(all_todos) == 6 + pre_cnt

        ## Just for increasing code coverage
        t3.component.pop("COMPLETED")
        assert not t3.is_pending()

        ## Test that uncomplete works
        ## (except for GMX ... their server is weird)
        self.skip_on_compatibility_flag("vtodo-cannot-be-uncompleted")
        t5.uncomplete()
        some_todos = c.search(todo=True)
        assert len(some_todos) == 4 + pre_cnt

    def testWrongAuthType(self):
        if (
            "password" not in self.server_params
            or not self.server_params["password"]
            or self.server_params["password"] == "any-password-seems-to-work"
        ):
            pytest.skip(
                "Testing with wrong password skipped as calendar server does not require a password"
            )

        connect_params1 = self.server_params.copy()
        for delme in ("setup", "teardown", "name"):
            if delme in connect_params1:
                connect_params1.pop(delme)

        connect_params2 = connect_params1.copy()

        ## At least one of those two ought to fail
        ## as they are (or should be) incompatible
        connect_params1["auth_type"] = "digest"
        connect_params2["auth_type"] = "bearer"

        with pytest.raises(error.AuthorizationError):
            client(**connect_params1).principal()
            client(**connect_params2).principal()

    def testWrongPassword(self):
        self.skip_unless_support("wrong-password-check")
        if (
            "password" not in self.server_params
            or not self.server_params["password"]
            or self.server_params["password"] == "any-password-seems-to-work"
        ):
            pytest.skip(
                "Testing with wrong password skipped as calendar server does not require a password"
            )
        connect_params = self.server_params.copy()
        for delme in ("setup", "teardown", "name"):
            if delme in connect_params:
                connect_params.pop(delme)
        connect_params["password"] = codecs.encode(connect_params["password"], "rot13") + "!"
        with pytest.raises(error.AuthorizationError):
            client(**connect_params).principal()

    def testCreateChildParent(self):
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("save-load.icalendar.related-to")
        c = self._fixCalendar(supported_calendar_component_set=["VEVENT"])
        parent = c.add_event(
            dtstart=datetime(2022, 12, 26, 19, 15),
            dtend=datetime(2022, 12, 26, 20, 00),
            summary="this is a parent event test",
            uid="ctuid1",
        )
        child = c.add_event(
            dtstart=datetime(2022, 12, 26, 19, 17),
            dtend=datetime(2022, 12, 26, 20, 00),
            summary="this is a child event test",
            parent=[parent.id],
            uid="ctuid2",
        )
        grandparent = c.add_event(
            dtstart=datetime(2022, 12, 26, 19, 00),
            dtend=datetime(2022, 12, 26, 20, 00),
            summary="this is a grandparent event test",
            child=[parent.id],
            uid="ctuid3",
        )
        another_child = c.add_event(
            dtstart=datetime(2022, 12, 27, 19, 00),
            dtend=datetime(2022, 12, 27, 20, 00),
            summary="this is yet another child test event",
            uid="ctuid4",
        )
        another_parent = c.add_event(
            dtstart=datetime(2022, 12, 27, 19, 00),
            dtend=datetime(2022, 12, 27, 20, 00),
            summary="this is yet another parent test event",
            uid="ctuid5",
        )

        parent_ = c.get_event_by_uid(parent.id)
        child_ = c.get_event_by_uid(child.id)
        grandparent_ = c.get_event_by_uid(grandparent.id)

        rt = grandparent_.icalendar_component["RELATED-TO"]
        if isinstance(rt, list):
            assert len(rt) == 1
            rt = rt[0]
        assert rt == parent.id
        assert rt.params["RELTYPE"] == "CHILD"
        rt = parent_.icalendar_component["RELATED-TO"]
        assert len(rt) == 2
        assert set([str(rt[0]), str(rt[1])]) == set([grandparent.id, child.id])
        assert set([rt[0].params["RELTYPE"], rt[1].params["RELTYPE"]]) == set(["CHILD", "PARENT"])
        rt = child_.icalendar_component["RELATED-TO"]
        if isinstance(rt, list):
            assert len(rt) == 1
            rt = rt[0]
        assert rt == parent.id
        assert rt.params["RELTYPE"] == "PARENT"

        foo = parent_.get_relatives(reltypes={"PARENT"})
        assert len(foo) == 1
        assert len(foo["PARENT"]) == 1
        assert [list(foo["PARENT"])[0].icalendar_component["UID"] == grandparent.id]
        foo = parent_.get_relatives(reltypes={"CHILD"})
        assert len(foo) == 1
        assert len(foo["CHILD"]) == 1
        assert [list(foo["CHILD"])[0].icalendar_component["UID"] == child.id]
        foo = parent_.get_relatives(reltypes={"CHILD", "PARENT"})
        assert len(foo) == 2
        assert len(foo["CHILD"]) == 1
        assert len(foo["PARENT"]) == 1
        foo = parent_.get_relatives(relfilter=lambda x: x.params.get("GAP"))

        ## verify the check_reverse_relations method (TODO: move to a separate test)
        assert parent_.check_reverse_relations() == []
        assert child_.check_reverse_relations() == []
        assert grandparent_.check_reverse_relations() == []

        ## My grandchild is also my child ... that sounds fishy
        grandparent_.set_relation(child, reltype="CHILD", set_reverse=False)

        ## The check_reverse should tell that something is amiss
        missing_parent = grandparent_.check_reverse_relations()
        assert len(missing_parent) == 1
        assert missing_parent[0][0].icalendar_component["uid"] == "ctuid2"
        assert missing_parent[0][1] == "PARENT"
        ## But only when run on the grandparent.  The child is blissfully
        ## unaware who the second parent is (even if reloading it).
        child_.load()
        assert child_.check_reverse_relations() == []

        ## We should be able to fix the missing parent
        grandparent_.fix_reverse_relations()
        assert not grandparent_.check_reverse_relations()

        ## TODO:
        ## This does not work out.  A relation to some object that is not on
        ## the calendar is not flagged - but perhaps it shouldn't be flagged?
        # child.delete()
        # assert parent_.check_reverse_relations()

        ## Verify the `set_relation` with default `set_reverse=True`
        foo = another_parent.get_relatives(reltypes={"CHILD", "PARENT"})
        bar = another_child.get_relatives(reltypes={"CHILD", "PARENT"})
        assert len(foo) == 0
        assert len(bar) == 0

        another_parent.set_relation("ctuid4", reltype="CHILD")
        another_parent.load()
        another_child.load()
        assert another_child.check_reverse_relations() == []
        assert another_parent.check_reverse_relations() == []
        foo = another_parent.get_relatives(reltypes={"CHILD", "PARENT"})
        bar = another_child.get_relatives(reltypes={"CHILD", "PARENT"})
        assert (
            sum([len(x.get("CHILD", set())) + len(x.get("PARENT", set())) for x in [foo, bar]]) == 2
        )
        assert [str(obj.component["UID"]) for obj in foo["CHILD"]] == ["ctuid4"]
        assert [str(obj.component["UID"]) for obj in bar["PARENT"]] == ["ctuid5"]

    def testSetDue(self):
        self.skip_unless_support("save-load.todo")

        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])

        utc = timezone.utc

        some_todo = c.add_todo(
            dtstart=datetime(2022, 12, 26, 19, 15, tzinfo=utc),
            due=datetime(2022, 12, 26, 20, 00, tzinfo=utc),
            summary="Some task",
            uid="ctuid5",
        )

        ## setting the due should ... set the due (surprise, surprise)
        some_todo.set_due(datetime(2022, 12, 26, 20, 10, tzinfo=utc))
        assert some_todo.icalendar_component["DUE"].dt == datetime(2022, 12, 26, 20, 10, tzinfo=utc)
        assert some_todo.icalendar_component["DTSTART"].dt == datetime(
            2022, 12, 26, 19, 15, tzinfo=utc
        )

        ## move_dtstart causes the duration to be unchanged
        some_todo.set_due(datetime(2022, 12, 26, 20, 20, tzinfo=utc), move_dtstart=True)
        assert some_todo.icalendar_component["DUE"].dt == datetime(2022, 12, 26, 20, 20, tzinfo=utc)
        assert some_todo.icalendar_component["DTSTART"].dt == datetime(
            2022, 12, 26, 19, 25, tzinfo=utc
        )

        ## This task has duration set rather than due.  Due should be implied to be 19:30.
        some_other_todo = c.add_todo(
            dtstart=datetime(2022, 12, 26, 19, 15, tzinfo=utc),
            duration=timedelta(minutes=15),
            summary="Some other task",
            uid="ctuid6",
        )
        some_other_todo.set_due(datetime(2022, 12, 26, 19, 45, tzinfo=utc), move_dtstart=True)
        assert some_other_todo.icalendar_component["DUE"].dt == datetime(
            2022, 12, 26, 19, 45, tzinfo=utc
        )
        assert some_other_todo.icalendar_component["DTSTART"].dt == datetime(
            2022, 12, 26, 19, 30, tzinfo=utc
        )

        some_todo.save()

        self.skip_unless_support("save-load.icalendar.related-to")

        parent = c.add_todo(
            dtstart=datetime(2022, 12, 26, 19, 00, tzinfo=utc),
            due=datetime(2022, 12, 26, 21, 00, tzinfo=utc),
            summary="this is a parent test task",
            uid="ctuid7",
            child=[some_todo.id],
        )

        ## The check_reverse_relations method is cheeky,
        ## returning a list of non-behaving relations
        ## (so it SHOULD return an empty list)
        assert not parent.check_reverse_relations()

        ## The above updates the some_todo object on the server side,
        ## but the local object is not updated ... until we reload it
        some_todo.load()

        ## This should work out (set the children due to some time before the parents due)
        some_todo.set_due(
            datetime(2022, 12, 26, 20, 30, tzinfo=utc),
            move_dtstart=True,
            check_dependent=True,
        )
        assert some_todo.icalendar_component["DUE"].dt == datetime(2022, 12, 26, 20, 30, tzinfo=utc)
        assert some_todo.icalendar_component["DTSTART"].dt == datetime(
            2022, 12, 26, 19, 35, tzinfo=utc
        )

        ## This should not work out (set the children due to some time before the parents due)
        with pytest.raises(error.ConsistencyError):
            some_todo.set_due(
                datetime(2022, 12, 26, 21, 30, tzinfo=utc),
                move_dtstart=True,
                check_dependent=True,
            )

        ## `todo.set_due` with `check_dependent='return'`
        ## should return the parent
        assert (
            parent.component["uid"]
            == some_todo.set_due(
                datetime(2022, 12, 26, 21, 30, tzinfo=utc),
                move_dtstart=True,
                check_dependent="return",
            ).component["uid"]
        )

        child = c.add_todo(
            dtstart=datetime(2022, 12, 26, 19, 45),
            due=datetime(2022, 12, 26, 19, 55),
            summary="this is a test child task",
            uid="ctuid4",
            parent=[some_todo.id],
        )
        assert child is not None

        ## This should still work out (set the children due to some time before the parents due)
        ## (The fact that we now have a child does not affect it anyhow)
        some_todo.set_due(
            datetime(2022, 12, 26, 20, 31, tzinfo=utc),
            move_dtstart=True,
            check_dependent=True,
        )
        assert some_todo.icalendar_component["DUE"].dt == datetime(2022, 12, 26, 20, 31, tzinfo=utc)
        assert some_todo.icalendar_component["DTSTART"].dt == datetime(
            2022, 12, 26, 19, 36, tzinfo=utc
        )

    def testCreateJournalListAndJournalEntry(self):
        """
        This test demonstrates the support for journals.
        * It will create a journal list
        * It will add some journal entries to it
        * It will list out all journal entries
        """
        self.skip_unless_support("save-load.journal")
        c = self._fixCalendar(supported_calendar_component_set=["VJOURNAL"])
        j1 = c.add_journal(journal)
        journals = c.get_journals()
        assert len(journals) == 1
        j1_ = c.get_journal_by_uid(j1.id)
        ## Direct comparison handles different line folding from different fetch methods
        assert j1_.get_icalendar_instance() == journals[0].get_icalendar_instance()
        j2 = c.add_journal(
            dtstart=date(2011, 11, 11),
            summary="A childbirth in a hospital in Kupchino",
            description="A quick birth, in the middle of the night",
            uid="ctuid1",
        )
        assert j2 is not None
        assert len(c.get_journals()) == 2
        assert len(c.search(journal=True)) == 2
        todos = c.get_todos()
        events = c.get_events()
        assert todos + events == []

    def testCreateTaskListAndTodo(self):
        """
        This test demonstrates the support for task lists.
        * It will create a "task list"
        * It will add a task to it
        * Verify the cal.get_todos() method
        * Verify that cal.get_events() method returns nothing
        """
        self.skip_unless_support("save-load.todo")
        ## Test breaks for OX (because it does not support old events in any meaningful way).
        self.skip_unless_support("search.unlimited-time-range")

        # For most servers (notable exception Zimbra), it's
        # possible to create a calendar and add todo-items to it.
        # Zimbra has separate calendars and task lists, and it's not
        # allowed to put TODO-tasks into the calendar.  We need to
        # tell Zimbra that the new "calendar" is a task list.  This
        # is done though the supported_calendar_component_set
        # property - hence the extra parameter here:
        logging.info("Creating calendar Yep for tasks")
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])

        # add todo-item
        logging.info("Adding todo item to calendar Yep")
        t1 = c.add_todo(todo)
        assert t1.id == "20070313T123432Z-456553@example.com"

        # c.get_todos() should give a full list of todo items
        logging.info("Fetching the full list of todo items (should be one)")
        todos = c.get_todos()
        todos2 = c.get_todos(include_completed=True)
        assert len(todos) == 1
        assert len(todos2) == 1

        t3 = c.add_todo(summary="mop the floor", categories=["housework"], priority=4, uid="ctuid1")
        assert t3 is not None
        assert len(c.get_todos()) == 2

        # adding a todo without a UID, it should also work (library will add the missing UID)
        t7 = c.add_todo(todo7)
        logging.info("Fetching the todos (should be three)")
        todos = c.get_todos()

        logging.info("Fetching the events (should be none)")
        # c.get_events() should NOT return todo-items
        events = c.get_events()

        t7.delete()

        ## Delayed asserts ... this test is fragile, since todo7 is without
        ## an uid it may not be covered by the automatic cleanup procedures
        ## in the test framework.
        assert len(todos) == 3
        assert len(events) == 0
        assert len(c.get_todos()) == 2

    def testTodos(self):
        """
        This test will exercise the cal.get_todos() method,
        and in particular the sort_keys attribute.
        * It will list out all pending tasks, sorted by due date
        * It will list out all pending tasks, sorted by priority
        """
        self.skip_unless_support("save-load.todo")
        ## Test breaks for OX (because it does not support old events in any meaningful way).
        self.skip_unless_support("search.unlimited-time-range")
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])

        # add todo-item
        t1 = c.add_todo(todo)
        t2 = c.add_todo(todo2)
        t4 = c.add_todo(todo4)

        todos = c.get_todos()
        assert len(todos) == 3

        def uids(lst):
            return [x.vobject_instance.vtodo.uid for x in lst]

        ## Default sort order is (due, priority).
        assert uids(todos) == uids([t2, t1, t4])

        todos = c.get_todos(sort_keys=("priority",))
        ## sort_key is considered to be a legacy parameter,
        ## but should work at least until 1.0
        todos2 = c.get_todos(sort_key="priority")

        def pri(lst):
            return [
                x.vobject_instance.vtodo.priority.value
                for x in lst
                if hasattr(x.vobject_instance.vtodo, "priority")
            ]

        assert pri(todos) == pri([t4, t2])
        assert pri(todos2) == pri([t4, t2])

        todos = c.get_todos(
            sort_keys=(
                "summary",
                "priority",
            )
        )
        assert uids(todos) == uids([t4, t2, t1])

        ## str of CalendarObjectResource is slightly inconsistent compared to
        ## the str of Calendar objects, as the class name is included.  Perhaps
        ## it should be removed, hence no assertions on that.
        ## (the statements below is mostly to exercise the __str__ and __repr__)
        assert str(todos[0].url) in str(todos[0])
        assert str(todos[0].url) in repr(todos[0])
        assert "Todo" in repr(todos[0])

    def testSearchCompType(self) -> None:
        """
        Test that component-type filtering works correctly, even on servers
        with broken comp-type support (like Bedework which misclassifies TODOs as events).

        This test verifies that when calendar.get_events() is called, only events are returned,
        and when calendar.get_todos() is called, only todos are returned, regardless of
        server bugs.
        """
        self.skip_unless_support("save-load.todo")
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("save-load.todo.mixed-calendar")

        ## Use a mixed calendar that supports both events and todos
        c = self._fixCalendar()

        ## Add an event
        event = c.add_event(
            summary="Test Event for Component-Type Filtering",
            dtstart=datetime(2025, 1, 1, 12, 0, 0),
            dtend=datetime(2025, 1, 1, 13, 0, 0),
        )

        ## Add a todo
        todo_obj = c.add_todo(
            summary="Test TODO for Component-Type Filtering",
            dtstart=date(2025, 1, 2),
        )

        ## Get events - should only return the event, not the todo
        events = c.get_events()
        event_summaries = [e.component["summary"] for e in events]

        ## Get todos - should only return the todo, not the event
        todos = c.get_todos(include_completed=True)
        todo_summaries = [t.component["summary"] for t in todos]

        ## Verify correct filtering
        assert "Test Event for Component-Type Filtering" in event_summaries
        assert "Test TODO for Component-Type Filtering" not in event_summaries

        assert "Test TODO for Component-Type Filtering" in todo_summaries
        assert "Test Event for Component-Type Filtering" not in todo_summaries

        ## Clean up
        event.delete()
        todo_obj.delete()

    @pytest.mark.filterwarnings("ignore:use `calendar.search:DeprecationWarning")
    def testTodoDatesearch(self):
        """
        Let's see how the date search method works for todo events.

        Note: This test intentionally uses the deprecated date_search method
        to ensure backward compatibility.
        """
        self.skip_unless_support("save-load.todo")
        self.skip_unless_support("search.time-range.todo")
        self.skip_unless_support("search.time-range.todo.old-dates")
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])

        # add todo-item
        t1 = c.add_todo(todo)
        t2 = c.add_todo(todo2)
        assert t2 is not None
        t3 = c.add_todo(todo3)
        assert t3 is not None
        t4 = c.add_todo(todo4)
        t5 = c.add_todo(todo5)
        assert t5 is not None
        t6 = c.add_todo(todo6)
        todos = c.get_todos()
        assert len(todos) == 6

        with pytest.deprecated_call():
            notodos = c.date_search(  # default compfilter is events
                start=datetime(1997, 4, 14), end=datetime(2015, 5, 14), expand=False
            )
            assert not notodos

        # Now, this is interesting.
        # t1 has due set but not dtstart set
        # t2 and t3 has dtstart and due set
        # t4 has neither dtstart nor due set.
        # t5 has dtstart and due set prior to the search window
        # t6 has dtstart and due set prior to the search window, but is yearly recurring.
        # What will a date search yield?
        with pytest.deprecated_call():
            todos1 = c.date_search(
                start=datetime(1997, 4, 14),
                end=datetime(2015, 5, 14),
                compfilter="VTODO",
                expand=True,
            )
        todos2 = c.search(
            start=datetime(1997, 4, 14),
            end=datetime(2015, 5, 14),
            todo=True,
            expand=True,
            split_expanded=False,
            include_completed=True,
        )
        todos3 = c.search(
            start=datetime(1997, 4, 14),
            end=datetime(2015, 5, 14),
            todo=True,
            expand=True,
            split_expanded=False,
            include_completed=True,
        )
        todos4 = c.search(
            start=datetime(1997, 4, 14),
            end=datetime(2015, 5, 14),
            todo=True,
            expand=True,
            split_expanded=False,
            include_completed=True,
        )
        # The RFCs are pretty clear on this.  rfc5545 states:

        # A "VTODO" calendar component without the "DTSTART" and "DUE" (or
        # "DURATION") properties specifies a to-do that will be associated
        # with each successive calendar date, until it is completed.

        # and RFC4791, section 9.9 also says that events without
        # dtstart or due should be counted.  The expanded yearly event
        # should be returned as one object with multiple BEGIN:VEVENT
        # and DTSTART lines.

        # Hence a compliant server should chuck out all the todos except t5.
        # Not all servers perform according to (my interpretation of) the RFC.
        foo = 5
        implicit_todo_fragile = (
            self.is_supported("search.recurrences.includes-implicit.todo", str) == "fragile"
        )
        if not self.is_supported("search.recurrences.includes-implicit.todo"):
            foo -= 1  ## t6 will not be returned
        if not self.is_supported(
            "search.time-range.todo.no-dtstart"
        ) or self.check_compatibility_flag(
            "vtodo_datesearch_nodtstart_task_is_skipped_in_closed_date_range"
        ):
            foo -= 2  ## t1 and t4 not returned
        elif self.check_compatibility_flag("vtodo_datesearch_notime_task_is_skipped"):
            foo -= 1  ## t4 not returned
        if implicit_todo_fragile:
            assert len(todos1) in (foo, foo + 1)
            assert len(todos2) in (foo, foo + 1)
        else:
            assert len(todos1) == foo
            assert len(todos2) == foo

        ## verify that "expand" works
        if self.is_supported("search.recurrences.includes-implicit.todo"):
            ## todo1 and todo2 should be the same (todo1 using legacy method)
            ## todo1 and todo2 tries doing server side expand, with fallback
            ## to client side expand
            assert len([x for x in todos1 if "DTSTART:20020415T1330" in x.data]) == 1
            assert len([x for x in todos2 if "DTSTART:20020415T1330" in x.data]) == 1
            if self.is_supported("search.recurrences.expanded.todo"):
                assert len([x for x in todos4 if "DTSTART:20020415T1330" in x.data]) == 1
            ## todo3 is client side expand, should always work
            assert len([x for x in todos3 if "DTSTART:20020415T1330" in x.data]) == 1
            ## todo4 is server side expand, may work dependent on server

        ## exercise the default for expand (maybe -> False for open-ended search)
        with pytest.deprecated_call():
            todos1 = c.date_search(start=datetime(2025, 4, 14), compfilter="VTODO")
        todos2 = c.search(start=datetime(2025, 4, 14), todo=True, include_completed=True)
        todos3 = c.search(start=datetime(2025, 4, 14), todo=True)

        ## On a compliant server t1/t4/t6 are returned by an open-ended future
        ## search, so we get Todo objects back.  Some servers legitimately return
        ## nothing here: they skip no-dtstart todos (t1/t4) and don't carry the
        ## recurring todo (t6) into the future - e.g. Stalwart, which skips
        ## no-dtstart todos and only marks implicit-recurrence todos "fragile".
        ## The presence/absence of each todo is verified by the urls_found logic
        ## below; here we type-check whatever did come back -- every object,
        ## not just the first, and unconditionally: guarding on non-emptiness
        ## would make the check disappear silently on exactly the servers
        ## where it is most likely to catch something.
        if self.is_supported("search.time-range.open.end"):
            for todos in (todos1, todos2, todos3):
                assert all(isinstance(x, Todo) for x in todos), (
                    f"search returned non-Todo objects: "
                    f"{[type(x).__name__ for x in todos if not isinstance(x, Todo)]}"
                )

        ## * t6 should be returned, as it's a yearly task spanning over 2025
        ## * t1 should probably be returned, as it has no due date set and hence
        ## has an infinite duration.
        ## * t4 should probably be returned, as it has no dtstart nor due and
        ##  hence is also considered to span over infinite time
        urls_found = [x.url for x in todos1]
        urls_found2 = [x.url for x in todos2]
        assert set(urls_found) == set(urls_found2)
        urls_found = set(urls_found)
        if self.is_supported("search.recurrences.includes-implicit.todo", accept_fragile=True):
            urls_found.discard(t6.url)
        if self.is_supported(
            "search.time-range.todo.no-dtstart"
        ) and not self.check_compatibility_flag("vtodo_datesearch_notime_task_is_skipped"):
            urls_found.discard(t4.url)
        if self.check_compatibility_flag("vtodo_no_due_infinite_duration"):
            urls_found.discard(t1.url)
        ## everything should be popped from urls_found by now
        assert len(urls_found) == 0

        assert len([x for x in todos1 if "DTSTART:20270415T1330" in x.data]) == 0
        assert len([x for x in todos2 if "DTSTART:20270415T1330" in x.data]) == 0

        # TODO: prod the caldav server implementers about the RFC
        # breakages.

    def testSearchWithoutCompType(self):
        """
        Test for https://github.com/python-caldav/caldav/issues/539
        """
        self.skip_unless_support("save-load.todo.mixed-calendar")
        cal = self._fixCalendar()
        cal.add_todo(todo)
        cal.add_event(ev1)
        objects = cal.search()
        assert len(objects) == 2
        assert set([type(x).__name__ for x in objects]) == {"Todo", "Event"}

    def testSearchWithoutCompTypeWithDateRange(self):
        """Test for https://github.com/python-caldav/caldav/issues/681

        A time-range search that does NOT specify a component type must work
        even on SabreDAV-based servers (Baikal, Nextcloud, ...) which - correctly
        per RFC4791 section 9.7 - reject a CALDAV:time-range placed directly under
        the VCALENDAR comp-filter with HTTP 400.  The library works around this by
        splitting the search into one query per component type
        (search.time-range.comp-type-optional being unsupported).

        The search is run twice: once with the server's real feature
        configuration, and once with search.time-range.comp-type-optional forced
        to "supported".  The forced run makes the library optimistically send the
        comp-type-less time-range query that SabreDAV rejects, exercising the
        reactive 400-fallback.  Without that fallback the forced run fails on
        Baikal.
        """
        self.skip_unless_support("search.time-range.event")
        cal = self._fixCalendar()

        ## Near-future dates, to steer clear of servers that restrict old-date
        ## time-range searches.
        now = datetime.now(timezone.utc)
        dtstart = now + timedelta(days=1)
        dtend = dtstart + timedelta(hours=1)
        uid = "issue681-" + uuid.uuid4().hex
        ical = (
            "BEGIN:VCALENDAR\r\n"
            "VERSION:2.0\r\n"
            "PRODID:-//python-caldav//issue681 test//EN\r\n"
            "BEGIN:VEVENT\r\n"
            f"UID:{uid}\r\n"
            f"DTSTAMP:{now.strftime('%Y%m%dT%H%M%SZ')}\r\n"
            f"DTSTART:{dtstart.strftime('%Y%m%dT%H%M%SZ')}\r\n"
            f"DTEND:{dtend.strftime('%Y%m%dT%H%M%SZ')}\r\n"
            "SUMMARY:issue 681 comp-type-less time-range search\r\n"
            "END:VEVENT\r\n"
            "END:VCALENDAR\r\n"
        )
        cal.save_event(ical)

        start = now
        end = now + timedelta(days=2)

        def _assert_event_found():
            ## must not raise (this is the crux of issue #681) and must find the event
            objects = cal.search(start=start, end=end)
            assert [o for o in objects if uid in o.data], (
                "comp-type-less time-range search did not return the event"
            )

        ## Run 1: the server's real feature configuration (proactive comp-type split)
        _assert_event_found()

        ## Determine how this server reacts to the raw comp-type-less time-range
        ## query.  Only SabreDAV-style servers (Baikal, Nextcloud) reject it with a
        ## ReportError (HTTP 400) - that is the case the reactive fallback (issue
        ## #681 item 4) is designed to recover from.  Others return nothing, or a
        ## different error (e.g. Cyrus may answer 403), where forcing the feature on
        ## is an unrecoverable misconfiguration not worth asserting on.
        try:
            cal.search(start=start, end=end, compatibility_workarounds=False)
            raw_report_error = False
        except error.ReportError:
            raw_report_error = True
        except error.DAVError:
            raw_report_error = False

        ## Run 2 (only meaningful where the raw query raises a ReportError): force
        ## search.time-range.comp-type-optional ON and verify the reactive fallback
        ## recovers and still finds the event.
        if raw_report_error:
            features = self.caldav.features
            key = "search.time-range.comp-type-optional"
            had_key = key in features._server_features
            saved = features._server_features.get(key)
            features.set_feature(key, {"support": "full"})
            try:
                objects = cal.search(start=start, end=end)
                assert [o for o in objects if uid in o.data], (
                    "reactive fallback did not recover the comp-type-less time-range search"
                )
            finally:
                if had_key:
                    features._server_features[key] = saved
                else:
                    features._server_features.pop(key, None)

    def testSearchWithoutCompTypeWithCategory(self):
        """Test for https://github.com/python-caldav/caldav/issues/681

        A property filter (here CATEGORIES) without a component type must work.
        Placed directly under the VCALENDAR comp-filter the prop-filter targets
        VCALENDAR's own properties, which lack component properties like
        CATEGORIES, so servers (Xandikos, SabreDAV, ...) match nothing.  The
        library works around this by splitting the search into one query per
        component type (search.text.comp-type-optional being unsupported).
        """
        self.skip_unless_support("search.text.category")
        cal = self._fixCalendar()

        category = "issue681cat" + uuid.uuid4().hex[:8]
        uid = "issue681cat-" + uuid.uuid4().hex
        ical = (
            "BEGIN:VCALENDAR\r\n"
            "VERSION:2.0\r\n"
            "PRODID:-//python-caldav//issue681 test//EN\r\n"
            "BEGIN:VEVENT\r\n"
            f"UID:{uid}\r\n"
            f"DTSTAMP:{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}\r\n"
            f"DTSTART:{(datetime.now(timezone.utc) + timedelta(days=1)).strftime('%Y%m%dT%H%M%SZ')}\r\n"
            f"DTEND:{(datetime.now(timezone.utc) + timedelta(days=1, hours=1)).strftime('%Y%m%dT%H%M%SZ')}\r\n"
            "SUMMARY:issue 681 comp-type-less category search\r\n"
            f"CATEGORIES:{category}\r\n"
            "END:VEVENT\r\n"
            "END:VCALENDAR\r\n"
        )
        cal.save_event(ical)

        ## The proactive per-component-type split is the only safe fix here: unlike
        ## the time-range case (where SabreDAV returns HTTP 400, which the reactive
        ## fallback can catch), servers silently return nothing for a prop-filter
        ## under VCALENDAR, so there is no error to recover from.  Hence we only
        ## verify the default (proactive) behaviour.
        objects = cal.search(category=category)
        assert [o for o in objects if uid in o.data], (
            "comp-type-less category search did not return the event"
        )

    def testTodoCompletion(self):
        """
        Will check that todo-items can be completed and deleted
        """
        self.skip_unless_support("save-load.todo")
        ## Test breaks for OX, because it doesn't support old tasks.
        self.skip_unless_support("search.unlimited-time-range")
        # not all caldav servers support VTODO
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])

        # add todo-items
        t1 = c.add_todo(todo)
        assert t1 is not None
        t2 = c.add_todo(todo2)
        t3 = c.add_todo(todo3, status="NEEDS-ACTION")

        # There are now three todo-items at the calendar
        todos = c.get_todos()
        assert len(todos) == 3

        # Complete one of them
        t3.complete()

        # There are now two todo-items at the calendar
        todos = c.get_todos()
        assert len(todos) == 2

        # The historic todo-item can still be accessed
        todos = c.get_todos(include_completed=True)
        assert len(todos) == 3
        t3_ = c.get_todo_by_uid(t3.id)
        assert t3_.vobject_instance.vtodo.summary == t3.vobject_instance.vtodo.summary
        assert t3_.vobject_instance.vtodo.uid == t3.vobject_instance.vtodo.uid
        assert t3_.vobject_instance.vtodo.dtstart == t3.vobject_instance.vtodo.dtstart

        t2.delete()

        # ... the deleted one is gone ...
        if not self.check_compatibility_flag("event_by_url_is_broken"):
            todos = c.get_todos(include_completed=True)
            assert len(todos) == 2

        # date search should not include completed events ... hum.
        # TODO, fixme.
        # todos = c.date_search(
        #     start=datetime(1990, 4, 14), end=datetime(2015,5,14),
        #     compfilter='VTODO', hide_completed_todos=True)
        # assert len(todos) == 1

    ## TODO: use parameterized test, this is duplicated in testTodoRecurringCompleteThisandfuture
    def testTodoRecurringCompleteSafe(self):
        self.skip_unless_support("save-load.todo")
        ## Test breaks for OX, because it doesn't support old tasks.
        self.skip_unless_support("search.unlimited-time-range")
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])
        assert len(c.get_todos()) == 0
        t6 = c.add_todo(todo6, status="NEEDS-ACTION")
        assert len(c.get_todos()) == 1
        if self.is_supported("save-load.todo.recurrences.count"):
            assert len(c.get_todos()) == 1
            t8 = c.add_todo(todo8)
            assert len(c.get_todos()) == 2
        else:
            assert len(c.get_todos()) == 1
        t6.complete(handle_rrule=True, rrule_mode="safe")
        if not self.is_supported("save-load.todo.recurrences.count"):
            assert len(c.get_todos()) == 1
            assert len(c.get_todos(include_completed=True)) == 2
            c.get_todos()[0].delete()
        self.skip_unless_support("save-load.todo.recurrences.count")
        assert len(c.get_todos()) == 2
        assert len(c.get_todos(include_completed=True)) == 3
        t8.complete(handle_rrule=True, rrule_mode="safe")
        todos = c.get_todos()
        assert len(todos) == 2
        t8.complete(handle_rrule=True, rrule_mode="safe")
        t8.complete(handle_rrule=True, rrule_mode="safe")
        assert len(c.get_todos()) == 1
        assert len(c.get_todos(include_completed=True)) == 5
        [x.delete() for x in c.get_todos(include_completed=True)]

    def testTodoRecurringCompleteThisandfuture(self):
        self.skip_unless_support("save-load.todo")
        self.skip_unless_support("save-load.todo.recurrences.thisandfuture")
        c = self._fixCalendar(supported_calendar_component_set=["VTODO"])
        assert len(c.get_todos()) == 0
        t6 = c.add_todo(todo6, status="NEEDS-ACTION")
        if self.is_supported("save-load.todo.recurrences.count"):
            t8 = c.add_todo(todo8)
            assert len(c.get_todos()) == 2
        else:
            assert len(c.get_todos()) == 1
        t6.complete(handle_rrule=True, rrule_mode="thisandfuture")
        all_todos = c.get_todos(include_completed=True)
        if not self.is_supported("save-load.todo.recurrences.count"):
            assert len(c.get_todos()) == 1
            assert len(all_todos) == 1
        self.skip_unless_support("save-load.todo.recurrences.count")
        assert len(c.get_todos()) == 2
        assert len(all_todos) == 2
        # assert sum([len(x.icalendar_instance.subcomponents) for x in all_todos]) == 5
        t8.complete(handle_rrule=True, rrule_mode="thisandfuture")
        assert len(c.get_todos()) == 2
        t8.complete(handle_rrule=True, rrule_mode="thisandfuture")
        t8.complete(handle_rrule=True, rrule_mode="thisandfuture")
        assert len(c.get_todos()) == 1

    def testUtf8Event(self):
        self.skip_unless_support("save-load.event")
        # TODO: what's the difference between this and testUnicodeEvent?
        # TODO: split up in creating a calendar with non-ascii name
        # and an event with non-ascii description
        self.skip_unless_support("create-calendar")
        if self.cleanup_regime in ("light", "pre"):
            self._teardownCalendar(cal_id=self.testcal_id)

        c = self._fixCalendar(name="Yølp", cal_id=self.testcal_id)

        # add event
        e1 = c.add_event(
            near_now_ics(ev1).replace("Bastille Day Party", "Bringebærsyltetøyfestival")
        )
        assert e1 is not None

        # fetch it back
        events = c.get_events()

        # no todos should be added
        if self.is_supported("save-load.todo"):
            todos = c.get_todos()
            assert len(todos) == 0

        # COMPATIBILITY PROBLEM - todo, look more into it
        if "zimbra" not in str(c.url):
            assert len(events) == 1

        if self.cleanup_regime == "post":
            self._teardownCalendar(cal_id=self.testcal_id)

    def testUnicodeEvent(self):
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("create-calendar")
        if self.cleanup_regime in ("light", "pre"):
            self._teardownCalendar(cal_id=self.testcal_id)
        c = self._fixCalendar(name="Yølp", cal_id=self.testcal_id)

        # add event
        e1 = c.add_event(
            to_str(near_now_ics(ev1).replace("Bastille Day Party", "Bringebærsyltetøyfestival"))
        )
        assert e1 is not None

        # c.get_events() should give a full list of events
        events = c.get_events()

        # COMPATIBILITY PROBLEM - todo, look more into it
        if "zimbra" not in str(c.url):
            assert len(events) == 1

    def testSetCalendarProperties(self):
        self.skip_unless_support("create-calendar.set-displayname")
        ## This test expects the fixture's display name ("Yep") and renames the
        ## calendar in place; both require the URL to stay put when a name is set.
        self.skip_unless_support("create-calendar.stable-url")
        self.skip_unless_support("delete-calendar")

        c = self._fixCalendar()
        assert c.url is not None

        ## TODO: there are more things in this test that
        ## should be run even if mkcalendar is not available.
        self.skip_unless_support("create-calendar")

        props = c.get_properties(
            [
                dav.DisplayName(),
            ]
        )
        assert "Yep" == props[dav.DisplayName.tag]

        # Creating a new calendar with different ID but with existing name
        # TODO: why do we do this?
        # TODO: we're doing this all over the placee, it should be consolidated
        # TODO: it should be in the test setup/teardown
        if self.cleanup_regime in ("light", "pre"):
            self._teardownCalendar(cal_id=self.testcal_id2)
        cc = self._fixCalendar(name="Yep", cal_id=self.testcal_id2)
        try:
            cc.delete()
        except error.DeleteError:
            if not self.is_supported("delete-calendar"):
                raise

        try:
            c.set_properties(
                [
                    dav.DisplayName("hooray"),
                ]
            )
            props = c.get_properties(
                [
                    dav.DisplayName(),
                ]
            )
            assert props[dav.DisplayName.tag] == "hooray"
        finally:
            ## Restore the fixture's canonical display name.  Under the
            ## wipe-calendar cleanup regime the calendar is reused (never
            ## deleted) between tests, so a lingering "hooray" would make this
            ## test non-idempotent (the next run reads "hooray", not "Yep") and,
            ## on servers enforcing per-principal unique calendar names (SOGo),
            ## block other calendars from taking the "hooray" name.
            try:
                c.set_properties([dav.DisplayName("Yep")])
            except error.PropsetError:
                ## Best-effort cleanup only: the assertion of interest has
                ## already run above.  Some servers reject setting the display
                ## name (PropsetError); if so there's nothing to restore and
                ## nothing actionable to do here, so swallow it silently.
                pass

        ## calendar color and calendar order are extra properties not
        ## described by RFC5545, but anyway supported by quite some server
        ## implementations.  How they behave is probed in detail by the
        ## server-tester (calendar-color / calendar-color.hex /
        ## calendar-order); here we mirror the core of what it asserts.
        ##
        ## The colour cannot be compared against the value that was set: a
        ## server marked `full` is allowed to normalise a colour name to its
        ## hex form.  But asserting only that *something* came back would
        ## pass even if set_properties() were a complete no-op, so instead we
        ## set two different values and require two different values back.
        if self.is_supported("calendar-color"):
            self._assert_property_tracks_input(c, ical.CalendarColor, "blue", "green")
        if self.is_supported("calendar-color.hex"):
            self._assert_property_tracks_input(c, ical.CalendarColor, "#FF0000FF", "#00FF00FF")
        if self.is_supported("calendar-order"):
            c.set_properties([ical.CalendarOrder("12")])
            props = c.get_properties([ical.CalendarOrder()])
            assert props[ical.CalendarOrder.tag] == "12"

    def _assert_property_tracks_input(self, cal, element, value1, value2):
        """Assert that a collection property actually stores what it is given.

        Set two different values in turn and require two different values
        back.  This distinguishes a property that works (even one the server
        normalises) from one that is read-only or silently dropped, without
        assuming the stored form equals the form that was set.
        """
        cal.set_properties([element(value1)])
        got1 = cal.get_properties([element()])[element.tag]
        cal.set_properties([element(value2)])
        got2 = cal.get_properties([element()])[element.tag]
        assert got1, f"{element.tag}: nothing was stored for {value1!r}"
        assert got1 != got2, (
            f"{element.tag}: {got1!r} comes back for both {value1!r} and {value2!r} - "
            f"the property is read-only, or set_properties() did nothing"
        )

    def testLookupEvent(self):
        """
        Makes sure we can add events and look them up by URL and ID
        """
        self.skip_unless_support("save-load.event")
        # Create calendar
        c = self._fixCalendar()
        assert c.url is not None

        # add event, with a near-now date so it stays visible to REPORT-based
        # lookups on sliding-window servers (see near_now_ics()).
        e1 = c.add_event(near_now_ics(ev1))
        assert e1.url is not None

        # Verify that we can look it up, both by URL and by ID
        e2 = c.event_by_url(e1.url)
        assert e2.vobject_instance.vevent.uid == e1.vobject_instance.vevent.uid
        assert e2.url == e1.url

        # look up by UID
        e3 = c.get_event_by_uid("20010712T182145Z-123401@example.com")
        assert e3.vobject_instance.vevent.uid == e1.vobject_instance.vevent.uid
        if self.is_supported("save-load.stable-url"):
            assert e3.url == e1.url
        else:
            ## The server reports the object under a different (canonical) URL
            ## than the one we stored it at (e.g. OX App Suite).  We can't compare
            ## URLs, but we can confirm the looked-up URL is a real, fetchable
            ## resource holding the same event.
            e3.load()
            assert e3.icalendar_component["uid"] == e1.icalendar_component["uid"]

        e4 = Event(client=self.caldav, url=e1.url)
        e4.load()
        assert e4.id == e1.id

        with pytest.raises(error.NotFoundError):
            c.get_event_by_uid("nonexistent-uid-0")

    def testCreateOverwriteDeleteEvent(self):
        """
        Makes sure we can add events and delete them
        """
        self.skip_unless_support("save-load.event")
        # Create calendar
        c = self._fixCalendar()
        assert c.url is not None

        ## near-now date so the event stays visible to REPORT-based lookups on
        ## sliding-window servers (e.g. OX); see near_now_ics
        ev1_now = near_now_ics(ev1)

        # attempts on updating/overwriting a non-existing event should fail:
        with pytest.raises(error.ConsistencyError):
            c.add_event(ev1_now, no_create=True)

        # no_create and no_overwrite is mutually exclusive, this will always
        # raise an error (unless the ical given is blank)
        with pytest.raises(error.ConsistencyError):
            c.add_event(ev1_now, no_create=True, no_overwrite=True)

        # add event
        e1 = c.add_event(ev1_now)

        todo_ok = self.is_supported("save-load.todo.mixed-calendar")
        if todo_ok:
            t1 = c.add_todo(todo)
        assert e1.url is not None
        if todo_ok:
            assert t1.url is not None
        if not self.check_compatibility_flag("event_by_url_is_broken"):
            assert c.event_by_url(e1.url).url == e1.url
        ## get_event_by_uid may return a different (canonical) URL than the PUT
        ## URL on servers that don't preserve it (e.g. OX); see save-load.stable-url
        e_by_uid = c.get_event_by_uid(e1.id)
        if self.is_supported("save-load.stable-url"):
            assert e_by_uid.url == e1.url
        else:
            assert e_by_uid.icalendar_component["uid"] == e1.icalendar_component["uid"]

        no_create = True

        ## add same event again.  As it has same uid, it should be overwritten
        ## (but some calendars may throw a "409 Conflict").  Overwriting via a
        ## fresh PUT without an If-Match etag is gated on save-load.mutable.if-match-optional:
        ## OX enforces optimistic concurrency and rejects such a PUT with 409
        ## (etag-conditional save() still works, so save-load.mutable stays full).
        if self.is_supported("save-load.mutable") and self.is_supported(
            "save-load.mutable.if-match-optional"
        ):
            e2 = c.add_event(ev1_now)
            if todo_ok:
                t2 = c.add_todo(todo)

            ## add same event with "no_create".  Should work like a charm.
            e2 = c.add_event(ev1_now, no_create=no_create)
            if todo_ok:
                t2 = c.add_todo(todo, no_create=no_create)

            ## this should also work.
            e2.vobject_instance.vevent.summary.value = (
                e2.vobject_instance.vevent.summary.value + "!"
            )
            e2.save(no_create=no_create)

            if todo_ok:
                t2.vobject_instance.vtodo.summary.value = (
                    t2.vobject_instance.vtodo.summary.value + "!"
                )
                t2.save(no_create=no_create)

            if not self.check_compatibility_flag("event_by_url_is_broken"):
                e3 = c.event_by_url(e1.url)
                assert e3.vobject_instance.vevent.summary.value == "Bastille Day Party!"

        ## "no_overwrite" should throw a ConsistencyError.
        with pytest.raises(error.ConsistencyError):
            c.add_event(ev1_now, no_overwrite=True)
        if todo_ok:
            with pytest.raises(error.ConsistencyError):
                c.add_todo(todo, no_overwrite=True)

        # delete event
        e1.delete()
        if todo_ok:
            t1.delete()

        # Verify that we can't look it up, both by URL and by ID
        with pytest.raises(self._notFound()):
            c.event_by_url(e1.url)
        ## e2 only exists if the put-overwrite block above ran
        if self.is_supported("save-load.mutable") and self.is_supported(
            "save-load.mutable.if-match-optional"
        ):
            with pytest.raises(self._notFound()):
                c.event_by_url(e2.url)
        if not self.check_compatibility_flag("event_by_url_is_broken"):
            with pytest.raises(error.NotFoundError):
                c.get_event_by_uid("20010712T182145Z-123401@example.com")

    @pytest.mark.filterwarnings("ignore:use `calendar.search:DeprecationWarning")
    def testDateSearchAndFreeBusy(self):
        """
        Verifies that date search works with a non-recurring event
        Also verifies that it's possible to change a date of a
        non-recurring event.

        Note: This test intentionally uses the deprecated date_search method
        to ensure backward compatibility.
        """
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("search")
        self.skip_unless_support("search.time-range.event.old-dates")
        # Create calendar, add event ...
        c = self._fixCalendar()
        assert c.url is not None
        e = c.add_event(ev1)

        ## just a sanity check to increase coverage (ref
        ## https://github.com/python-caldav/caldav/issues/93) -
        ## expand=False and no end date given is no-no
        with pytest.deprecated_call():
            with pytest.raises(error.DAVError):
                c.date_search(datetime(2006, 7, 13, 17, 00, 00), expand=True)

        # .. and search for it.
        with pytest.deprecated_call():
            r1 = c.date_search(
                datetime(2006, 7, 13, 17, 00, 00),
                datetime(2006, 7, 15, 17, 00, 00),
                expand=False,
            )
        r2 = c.search(
            event=True,
            start=datetime(2006, 7, 13, 17, 00, 00),
            end=datetime(2006, 7, 15, 17, 00, 00),
            expand=False,
        )

        assert e.vobject_instance.vevent.uid == r1[0].vobject_instance.vevent.uid
        assert e.vobject_instance.vevent.uid == r2[0].vobject_instance.vevent.uid
        assert len(r1) == 1
        assert len(r2) == 1

        ## The rest of the test code here depends on us changing an event.
        ## Apparently, in google calendar, events are immutable.
        ## TODO: delete the old event and insert a new one rather than skipping.
        ## (But events should not be immutable!  One should be able to change an event, push the changes
        ## out to all participants and all copies of the calendar, and let everyone know that it's a
        ## changed event and not a cancellation and a new event).
        self.skip_unless_support("save-load.mutable")

        # ev2 is same UID, but one year ahead.
        # The timestamp should change.
        e.data = ev2
        e.save()
        with pytest.deprecated_call():
            r1 = c.date_search(
                datetime(2006, 7, 13, 17, 00, 00),
                datetime(2006, 7, 15, 17, 00, 00),
                expand=False,
            )
        r2 = c.search(
            event=True,
            start=datetime(2006, 7, 13, 17, 00, 00),
            end=datetime(2006, 7, 15, 17, 00, 00),
            expand=False,
        )
        assert len(r1) == 0
        assert len(r2) == 0
        with pytest.deprecated_call():
            r1 = c.date_search(
                datetime(2007, 7, 13, 17, 00, 00),
                datetime(2007, 7, 15, 17, 00, 00),
                expand=False,
            )
            assert len(r1) == 1

        # date search without closing date should also find it
        with pytest.deprecated_call():
            r = c.date_search(datetime(2007, 7, 13, 17, 00, 00), expand=False)
            assert len(r) == 1

        # Lets try a freebusy request as well
        self.skip_unless_support("freebusy-query")

        freebusy = c.freebusy_request(
            datetime(2007, 7, 13, 17, 00, 00), datetime(2007, 7, 15, 17, 00, 00)
        )
        # TODO: assert something more complex on the return object
        assert isinstance(freebusy, FreeBusy)
        assert freebusy.vobject_instance.vfreebusy

        ## Just to improve the code coverage.  This shouldn't raise any errors.
        ## (TODO: move it to some other test)
        e.data = icalendar.Calendar.from_ical(ev2)

    @pytest.mark.filterwarnings("ignore:use `calendar.search:DeprecationWarning")
    def testRecurringDateSearch(self):
        """
        This is more sanity testing of the server side than testing of the
        library per se.  How will it behave if we serve it a recurring
        event?

        Note: This test intentionally uses the deprecated date_search method
        to ensure backward compatibility.
        """
        self.skip_unless_support("save-load.event")
        self.skip_unless_support("search.recurrences.includes-implicit.event")
        c = self._fixCalendar()

        # evr is a yearly event starting at 1997-11-02.  We search the next
        # future Nov-2 anniversary rather than a fixed historic year, so that
        # sliding-window servers (e.g. OX) can serve the time range.
        year, narrow_start, narrow_end, wide_end = next_anniversary_windows()
        e = c.add_event(evr)
        assert e is not None

        ## Without "expand", we should still find it when searching the anniversary
        with pytest.deprecated_call():
            r = c.date_search(
                narrow_start,
                narrow_end,
                expand=False,
            )
        r2 = c.search(
            event=True,
            start=narrow_start,
            end=narrow_end,
            expand=False,
        )
        assert len(r) == 1
        assert len(r2) == 1

        ## With expand=True, we should find one occurrence
        ## legacy method name
        with pytest.deprecated_call():
            r1 = c.date_search(
                narrow_start,
                narrow_end,
                expand=True,
            )
        ## server expansion, with client side fallback
        r2 = c.search(
            event=True,
            start=narrow_start,
            end=narrow_end,
            expand=True,
        )
        ## r3 was client-side expansion, but this is the default now
        ## server side expansion
        r4 = c.search(
            event=True,
            start=narrow_start,
            end=narrow_end,
            server_expand=True,
        )
        assert len(r1) == 1
        assert len(r2) == 1
        assert r1[0].data.count("END:VEVENT") == 1
        assert r2[0].data.count("END:VEVENT") == 1
        ## due to expandation, the DTSTART should be in the anniversary year
        assert r1[0].data.count(f"DTSTART;VALUE=DATE:{year}") == 1
        assert r2[0].data.count(f"DTSTART;VALUE=DATE:{year}") == 1
        if self.is_supported("search.recurrences.expanded.event"):
            assert r4[0].data.count(f"DTSTART;VALUE=DATE:{year}") == 1

        ## With expand=True and searching over two recurrences ...
        with pytest.deprecated_call():
            r1 = c.date_search(
                narrow_start,
                wide_end,
                expand=True,
            )
        r2 = c.search(
            event=True,
            start=narrow_start,
            end=wide_end,
            expand=True,
        )

        ## According to https://datatracker.ietf.org/doc/html/rfc4791#section-7.8.3, the
        ## resultset should be one vcalendar with two events.
        assert len(r1) == 1
        assert "RRULE" not in r1[0].data
        if self.check_compatibility_flag("robur_rrule_freq_yearly_expands_monthly"):
            assert r1[0].data.count("END:VEVENT") == 13
        else:
            assert r1[0].data.count("END:VEVENT") == 2
        ## However, the new search method will by default split it into
        ## two events.  Or 13, in the case of robur
        if self.check_compatibility_flag("robur_rrule_freq_yearly_expands_monthly"):
            assert len(r2) == 13
        else:
            assert len(r2) == 2
        assert "RRULE" not in r2[0].data
        assert "RRULE" not in r2[1].data
        assert r2[0].data.count("END:VEVENT") == 1
        assert r2[1].data.count("END:VEVENT") == 1

        # The recurring events should not be expanded when using the
        # events() method
        r = c.get_events()
        if not not self.is_supported("create-calendar"):
            assert len(r) == 1
        assert r[0].data.count("END:VEVENT") == 1

    def testRecurringDateWithExceptionSearch(self):
        self.skip_unless_support("search")
        self.skip_unless_support("search.time-range.event.old-dates")
        c = self._fixCalendar()

        # evr2 is a bi-weekly event starting 2024-04-11
        ## It has an exception, edited summary for recurrence id 20240425T123000Z
        e = c.add_event(evr2)
        assert e is not None

        rc = c.search(
            start=datetime(2024, 3, 31, 0, 0),
            end=datetime(2024, 5, 4, 0, 0, 0),
            event=True,
            expand=True,
        )
        ## client expand removed, since that's default from 2.0
        rs = c.search(
            start=datetime(2024, 3, 31, 0, 0),
            end=datetime(2024, 5, 4, 0, 0, 0),
            event=True,
            server_expand=True,
        )

        ## Only assert exact count and RRULE-free output when exception handling
        ## is reliable (either client-side or server-side expansion works correctly).
        if self.is_supported("save-load.event.recurrences.exception") or self.is_supported(
            "search.recurrences.expanded.exception"
        ):
            assert len(rc) == 2
            assert "RRULE" not in rc[0].data
            assert "RRULE" not in rc[1].data

        if self.is_supported("search.recurrences.expanded.event") and self.is_supported(
            "search.recurrences.expanded.exception"
        ):
            assert len(rs) == 2

        asserts_on_results = []
        # Client-side expansion only produces correct RECURRENCE-IDs when the
        # server keeps master VEVENT + exception VEVENT in the same calendar
        # object resource.  If the server splits them, skip this assertion.
        if self.is_supported("save-load.event.recurrences.exception"):
            asserts_on_results.append(rc)
        if self.is_supported("search.recurrences.expanded.exception"):
            asserts_on_results.append(rs)

        for r in asserts_on_results:
            # Check that we have two recurrence instances with correct dates
            # Order is not guaranteed by the spec, so collect the dates and verify both are present
            recurrence_ids = []
            for event in r:
                ## Some servers (e.g. Cyrus) omit RECURRENCE-ID on the first expanded occurrence
                ## TODO: xandikos returns a datetime without a tzinfo, radicale returns a datetime with tzinfo=UTC, but perhaps other calendar servers returns the timestamp converted to localtime?
                recurrence_id = event.icalendar_component.get(
                    "RECURRENCE-ID"
                ) or event.icalendar_component.get("DTSTART")
                assert recurrence_id is not None
                assert isinstance(recurrence_id, icalendar.vDDDTypes)
                recurrence_ids.append(recurrence_id.dt.replace(tzinfo=None))

            # Verify we have both expected recurrence instances (order-independent)
            assert set(recurrence_ids) == {
                datetime(2024, 4, 11, 12, 30, 0),
                datetime(2024, 4, 25, 12, 30, 0),
            }

    def testEditSingleRecurrence(self):
        """
        It should be possible to fetch a single recurrence from
        the calendar using search and expand, edit it and save it.
        Only the recurrence should be edited, not the rest of the
        event.
        """
        self.skip_unless_support("search.recurrences.includes-implicit.event")

        ## TODO TODO TODO ... gross hack just to skip this test on bedework.
        ## The test fails on bedework, the edit does not go through
        ## I don't want to spend time on research into bedework or more special
        ## checks on bedework compatibility, at the other hand this thing
        ## may (unlikely) mask problems with other servers
        self.skip_unless_support("search.text")

        cal = self._fixCalendar()

        ## Anchor the daily recurring event a few days in the future so servers
        ## with a sliding REPORT window / no old-date support (e.g. CCS, ref
        ## search.time-range.event.old-dates) can still serve the time ranges.
        ## The integer passed to search()/summary_on() is a day offset from this
        ## anchor day; the values just need to be distinct future days.
        base = (datetime.now() + timedelta(days=2)).replace(
            hour=8, minute=7, second=6, microsecond=0
        )

        ## Create a daily recurring event
        cal.add_event(
            uid="test1",
            summary="daily test",
            dtstart=base,
            dtend=base + timedelta(hours=1),
            rrule={"FREQ": "DAILY"},
        )

        def day_start(offset):
            return (base + timedelta(days=offset)).replace(
                hour=0, minute=0, second=0, microsecond=0
            )

        def search(offset):
            """
            Internal function to find one recurrence object - the occurrence on
            the day `offset` days after the event's anchor day.
            """
            recurrence = cal.search(
                event=True,
                start=day_start(offset),
                end=day_start(offset) + timedelta(days=1),
                expand=True,
            )
            assert len(recurrence) == 1
            return recurrence[0]

        def summary_on(offset):
            return search(offset).icalendar_component["summary"]

        ## Search for a recurrence
        recurrence = search(7)

        ## Modify it and save it
        recurrence.icalendar_component["summary"] = "half a year of daily testing"
        recurrence.save()

        ## Only one day should be affected
        assert summary_on(6) == "daily test"
        assert summary_on(7) == "half a year of daily testing"
        assert summary_on(8) == "daily test"

        ## let's try to set several recurrence exceptions
        recurrence = search(2)
        recurrence.icalendar_component["summary"] = "one month of daily testing"
        recurrence.save()

        assert summary_on(1) == "daily test"
        assert summary_on(2) == "one month of daily testing"
        assert summary_on(7) == "half a year of daily testing"

        ## Changing any of the exceptions should also work
        recurrence = search(7)
        recurrence.icalendar_component["summary"] = "six months of daily testing"
        recurrence.save()
        assert summary_on(7) == "six months of daily testing"

        ## parameter all_recurrences should change all recurrences -
        ## except the two edited exceptions (offsets 2 and 7)
        recurrence = search(9)
        recurrence.icalendar_component["summary"] = "daily testing"
        recurrence.save(all_recurrences=True)
        assert summary_on(1) == "daily testing"
        assert summary_on(2) == "one month of daily testing"
        assert summary_on(3) == "daily testing"
        assert summary_on(7) == "six months of daily testing"

        ## Last ... let's change the dtend and dtstart of the recurrence.
        ## This reschedules the whole series (moves the master DTSTART) while the
        ## two exceptions above are still attached - some servers (e.g. OX) reject
        ## that re-anchoring with a 409 Conflict, so it is gated on its own flag.
        if self.is_supported("save-load.event.recurrences.exception.reschedule"):
            recurrence = search(9)
            recurrence.icalendar_component.pop("dtstart")
            recurrence.icalendar_component.add("dtstart", day_start(9).replace(hour=8))
            recurrence.icalendar_component.pop("dtend")
            recurrence.icalendar_component.add("dtend", day_start(9).replace(hour=10))
            recurrence.save(all_recurrences=True)

            recurrence = search(8)
            assert (
                recurrence.icalendar_component.start.astimezone()
                == day_start(8).replace(hour=8).astimezone()
            )
            assert (
                recurrence.icalendar_component.end.astimezone()
                == day_start(8).replace(hour=10).astimezone()
            )

    def testOffsetURL(self):
        """
        pass a URL pointing to a calendar or a user to the DAVClient class,
        and things should still work
        """
        urls = [self.principal.url, self._fixCalendar().url]
        connect_params = self.server_params.copy()
        for delme in ("url", "setup", "teardown", "name"):
            if delme in connect_params:
                connect_params.pop(delme)
        for url in urls:
            conn = client(**connect_params, url=url)
            principal = conn.principal()
            calendars = principal.get_calendars()
            assert calendars is not None
            assert calendars is not None

    def testObjects(self):
        # TODO: description ... what are we trying to test for here?
        o = DAVObject(self.caldav)
        with pytest.raises(Exception):
            o.save()


class MyProxyPlugin(HttpProxyBasePlugin):
    """
    1) injects an extra header into the response from the server, so we can verify the data came trough the browser.
    2) keeps a count of all requests
    """

    proxy_access_logs = []

    def handle_upstream_chunk(self, chunk):
        """
        Injects a new header line (this may break if the content itself contains the trigger string)
        """
        return chunk.__class__(
            chunk.tobytes().replace(
                b"\r\nContent-Type: ",
                b"\r\nX-Data-Came-Through-Proxy: True\r\nContent-Type: ",
            )
        )

    def on_access_log(self, context):
        """
        Keep a count of requests done through the proxy
        """
        ## TODO ... howto?  This may run in a separate process even ... only way is to write things to  a file?
        return context


class AssertProxyDAVResponse(DAVResponse):
    def __init__(self, response, davclient=None):
        assert response.headers.get("X-Data-Came-Through-Proxy") == "True"
        return DAVResponse.__init__(self, response, davclient)


@mock.patch("caldav.davclient.DAVResponse", new=AssertProxyDAVResponse)
class TestProxy(proxy.TestCase):
    PROXY_PY_STARTUP_FLAGS = ["--plugins", "tests.test_caldav.MyProxyPlugin"]

    def setup_method(self, *largs, **kwargs):
        self.proxy = f"http://localhost:{self.PROXY.flags.port}"
        # Need an HTTP server (not HTTPS) because the proxy injects headers
        # into the response, which only works for unencrypted traffic
        http_servers = [s for s in caldav_servers if s.get("url", "").startswith("http://")]
        if not http_servers:
            pytest.skip("No HTTP server available for proxy testing")
        self.server_params = http_servers[0]

    def testNoProxyRaisesError(self):
        with client(**self.server_params) as conn:
            with pytest.raises(AssertionError):
                conn.principal()

    def testWithProxyParams(self):
        with client(proxy=self.proxy, **self.server_params) as conn:
            assert conn.principal() is not None

    def testWithProxyParamsWithoutScheme(self):
        with client(proxy=f"localhost:{self.PROXY.flags.port}", **self.server_params) as conn:
            assert conn.principal() is not None

    ## TODO: figure out how to test this properly.
    @pytest.mark.skipif(True, reason="work in progress ... this doesn't seem to work")
    def testWithEnvironment(self):
        os.environ["HTTP_PROXY"] = self.proxy
        os.environ["HTTPS_PROXY"] = self.proxy
        with client(**self.server_params) as conn:
            assert conn.principal() is not None

    ## TODO: test socks proxy as well.
    ## TODO: test https proxying as well
    ## TODO: test username/password in the proxy URL


# We want to run all tests in the above class through all caldav_servers;
# and I don't really want to create a custom nose test loader.  The
# solution here seems to be to generate one child class for each
# caldav_url, and inject it into the module namespace. TODO: This is
# very hacky.  If there are better ways to do it, please let me know.
# (maybe a custom nose test loader really would be the better option?)
# -- Tobias Brox <t-caldav@tobixen.no>, 2013-10-10

## TODO: The better way is probably to use @pytest.mark.parametrize
## -- Tobias Brox <t-caldav@tobixen.no>, 2024-11-15

## if doing something like
## `pytestmark = pytest.mark.parametrize("conn", [client[**x] for x in caldav_servers])`
## then all tests would get a conn parameter.  The functional tests that should not be
## run on all servers needs to be split into a separate file.  Things like `pytest -k GMX`
## will stop working.  Hm.
## -- Tobias Brox <t-caldav@tobixen.no>, 2025-06-17

_servernames = set()
for _caldav_server in caldav_servers:
    if "name" in _caldav_server:
        _servername = _caldav_server["name"]
    else:
        # create a unique identifier out of the server domain name
        _parsed_url = urlparse(_caldav_server["url"])
        _servername = _parsed_url.hostname.replace(".", "_").replace("-", "_") + str(
            _parsed_url.port or ""
        )
        while _servername in _servernames:
            _servername = _servername + "_"
        _servername = _servername.capitalize()
        _servernames.add(_servername)

    # create a classname and a class
    _classname = "TestForServer" + _servername

    # inject the new class into this namespace
    vars()[_classname] = type(
        _classname,
        (RepeatedFunctionalTestsBaseClass,),
        {"server_params": _caldav_server},
    )

    # If the server has scheduling_users configured, also generate a
    # TestSchedulingForServer* class so scheduling tests run per-server.
    if "scheduling_users" in _caldav_server:
        _sched_classname = "TestSchedulingForServer" + _servername
        vars()[_sched_classname] = type(
            _sched_classname,
            (_TestSchedulingBase,),
            {
                "_users": _caldav_server["scheduling_users"],
                "_server_features": _caldav_server.get("features"),
            },
        )
