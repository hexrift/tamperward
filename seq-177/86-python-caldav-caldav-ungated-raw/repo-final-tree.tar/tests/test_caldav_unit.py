#!/usr/bin/env python
"""
Rule: None of the tests in this file should initiate any internet
communication, and there should be no dependencies on a working caldav
server for the tests in this file.  We use the Mock class when needed
to emulate server communication.
"""

import pickle
from datetime import date, datetime, timedelta, timezone
from typing import Any
from unittest import mock
from urllib.parse import urlparse

import icalendar
import lxml.etree
import pytest

from caldav import (
    Calendar,
    CalendarObjectResource,
    CalendarSet,
    Event,
    Journal,
    Principal,
    Todo,
)
from caldav.davclient import DAVClient, DAVResponse
from caldav.elements import cdav, dav
from caldav.lib import error
from caldav.lib.python_utilities import to_normal_str, to_wire
from caldav.lib.url import URL

## Note on the imports - those two lines are equivalent:
# from caldav.objects import foo
# from caldav import foo
## This is due to a line like this in __init__.py:
# from .objects import *
## Said line should be deprecated at some point

## Some example icalendar data partly copied from test_caldav.py
ev1 = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:20010712T182145Z-123401@example.com
DTSTAMP:20060712T182145Z
DTSTART:20060714T170000Z
DTEND:20060715T040000Z
SUMMARY:Bastille Day Party
END:VEVENT
END:VCALENDAR
"""

todo = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:20070313T123432Z-456553@example.com
DTSTAMP:20070313T123432Z
DUE;VALUE=DATE:20070501
SUMMARY:Submit Quebec Income Tax Return for 2006
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
STATUS:NEEDS-ACTION
END:VTODO
END:VCALENDAR"""

todo_implicit_duration = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:20070313T123432Z-456553@example.com
DTSTAMP:20070313T123432Z
DTSTART;VALUE=DATE:20070425
DUE;VALUE=DATE:20070501
SUMMARY:Submit Quebec Income Tax Return for 2006
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
STATUS:NEEDS-ACTION
END:VTODO
END:VCALENDAR"""

todo_explicit_duration = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:20070313T123432Z-456553@example.com
DTSTAMP:20070313T123432Z
DTSTART:20070425T160000Z
DURATION:P5D
SUMMARY:Submit Quebec Income Tax Return for 2006
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
STATUS:NEEDS-ACTION
END:VTODO
END:VCALENDAR"""

todo_only_duration = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:20070313T123432Z-456553@example.com
DTSTAMP:20070313T123432Z
DURATION:P5D
SUMMARY:Submit Quebec Income Tax Return for 2006
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
STATUS:NEEDS-ACTION
END:VTODO
END:VCALENDAR"""

journal = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VJOURNAL
UID:19970901T130000Z-123405@example.com
DTSTAMP:19970901T130000Z
DTSTART;VALUE=DATE:19970317
SUMMARY:Staff meeting minutes
DESCRIPTION:1. Staff meeting: Participants include Joe\\, Lisa
  and Bob. Aurora project plans were reviewed. There is currently
  no budget reserves for this project. Lisa will escalate to
  management. Next meeting on Tuesday.\n
END:VJOURNAL
END:VCALENDAR
"""

# example from https://datatracker.ietf.org/doc/html/rfc5545
evr = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:19970901T130000Z-123403@example.com
DTSTAMP:19970901T130000Z
DTSTART;VALUE=DATE:19971102
SUMMARY:Our Blissful Anniversary
TRANSP:TRANSPARENT
CLASS:CONFIDENTIAL
CATEGORIES:ANNIVERSARY,PERSONAL,SPECIAL OCCASION
RRULE:FREQ=YEARLY
END:VEVENT
END:VCALENDAR"""

todo6 = """
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:19920901T130000Z-123408@host.com
DTSTAMP:19920901T130000Z
DTSTART:19920415T133000Z
DUE:19920516T045959Z
SUMMARY:Yearly Income Tax Preparation
RRULE:FREQ=YEARLY
CLASS:CONFIDENTIAL
CATEGORIES:FAMILY,FINANCE
PRIORITY:1
END:VTODO
END:VCALENDAR"""

## Mock response with 2 pending and 2 completed todos, for testing include_completed behavior
## https://github.com/python-caldav/caldav/issues/650
mixed_todos_response = """<d:multistatus xmlns:d="DAV:" xmlns:cal="urn:ietf:params:xml:ns:caldav">
  <d:response>
    <d:href>/calendar/pending1.ics</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VTODO\r\nUID:pending1\r\nSUMMARY:Pending 1\r\nSTATUS:NEEDS-ACTION\r\nDTSTAMP:20250101T000000Z\r\nEND:VTODO\r\nEND:VCALENDAR\r\n</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
  <d:response>
    <d:href>/calendar/pending2.ics</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VTODO\r\nUID:pending2\r\nSUMMARY:Pending 2\r\nDTSTAMP:20250101T000000Z\r\nEND:VTODO\r\nEND:VCALENDAR\r\n</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
  <d:response>
    <d:href>/calendar/completed1.ics</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VTODO\r\nUID:completed1\r\nSUMMARY:Completed 1\r\nSTATUS:COMPLETED\r\nDTSTAMP:20250101T000000Z\r\nCOMPLETED:20250101T120000Z\r\nEND:VTODO\r\nEND:VCALENDAR\r\n</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
  <d:response>
    <d:href>/calendar/completed2.ics</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>BEGIN:VCALENDAR\r\nVERSION:2.0\r\nBEGIN:VTODO\r\nUID:completed2\r\nSUMMARY:Completed 2\r\nSTATUS:COMPLETED\r\nDTSTAMP:20250101T000000Z\r\nCOMPLETED:20250101T120000Z\r\nEND:VTODO\r\nEND:VCALENDAR\r\n</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>"""

## from https://github.com/python-caldav/caldav/issues/495
recurring_task_response = """<d:multistatus xmlns:d="DAV:" xmlns:s="http://sabredav.org/ns" xmlns:cal="urn:ietf:params:xml:ns:caldav" xmlns:cs="http://calendarserver.org/ns/" xmlns:oc="http://owncloud.org/ns" xmlns:nc="http://nextcloud.org/ns">
  <d:response>
    <d:href>/remote.php/dav/calendars/oxi/personal/A9FFE819-5DDB-4947-A09C-308EEE5DA1F9.ics</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>BEGIN:VCALENDAR
VERSION:2.0
PRODID:+//IDN bitfire.at//ical4android (at.techbee.jtx)
BEGIN:VTODO
DTSTAMP:20250522T075151Z
UID:8a8736b4-bc35-4085-a98b-89c2f52a5c51
SEQUENCE:23
CREATED:20250411T233004Z
LAST-MODIFIED:20250522T075137Z
SUMMARY:Clean Rosie filter
DTSTART;VALUE=DATE:20250415
RRULE:FREQ=WEEKLY;BYDAY=TU,FR
PRIORITY:0
END:VTODO
BEGIN:VTODO
DTSTAMP:20250522T075151Z
UID:8a8736b4-bc35-4085-a98b-89c2f52a5c51
SEQUENCE:1
CREATED:20250411T234336Z
LAST-MODIFIED:20250414T082134Z
SUMMARY:Clean Rosie filter
STATUS:COMPLETED
DTSTART;VALUE=DATE:20250415
RECURRENCE-ID;VALUE=DATE:20250415
COMPLETED:20250414T082134Z
PERCENT-COMPLETE:100
PRIORITY:0
END:VTODO
BEGIN:VTODO
DTSTAMP:20250522T075151Z
UID:8a8736b4-bc35-4085-a98b-89c2f52a5c51
SEQUENCE:1
CREATED:20250411T234336Z
LAST-MODIFIED:20250414T082134Z
SUMMARY:Clean Rosie filter
STATUS:CANCELLED
DTSTART;VALUE=DATE:20250418
RECURRENCE-ID;VALUE=DATE:20250418
PRIORITY:0
END:VTODO
BEGIN:VTODO
DTSTAMP:20250522T075151Z
UID:8a8736b4-bc35-4085-a98b-89c2f52a5c51
SEQUENCE:1
CREATED:20250411T234336Z
LAST-MODIFIED:20250414T082134Z
SUMMARY:Clean Rosie filter
STATUS:CANCELLED
DTSTART;VALUE=DATE:20250422
RECURRENCE-ID;VALUE=DATE:20250422
PRIORITY:0
END:VTODO
BEGIN:VTODO
DTSTAMP:20250522T075151Z
UID:8a8736b4-bc35-4085-a98b-89c2f52a5c51
SEQUENCE:1
CREATED:20250411T234336Z
LAST-MODIFIED:20250425T124511Z
SUMMARY:Clean Rosie filter
STATUS:COMPLETED
DTSTART;VALUE=DATE:20250425
RECURRENCE-ID;VALUE=DATE:20250425
COMPLETED:20250425T124511Z
PERCENT-COMPLETE:100
PRIORITY:0
END:VTODO
BEGIN:VTODO
DTSTAMP:20250522T075151Z
UID:8a8736b4-bc35-4085-a98b-89c2f52a5c51
SEQUENCE:1
CREATED:20250411T234336Z
LAST-MODIFIED:20250425T124511Z
SUMMARY:Clean Rosie filter
STATUS:CANCELLED
DTSTART;VALUE=DATE:20250429
RECURRENCE-ID;VALUE=DATE:20250429
COMPLETED:20250425T124511Z
PERCENT-COMPLETE:100
PRIORITY:0
END:VTODO
BEGIN:VTODO
DTSTAMP:20250522T075151Z
UID:8a8736b4-bc35-4085-a98b-89c2f52a5c51
SEQUENCE:1
CREATED:20250411T234336Z
LAST-MODIFIED:20250502T113705Z
SUMMARY:Clean Rosie filter
STATUS:COMPLETED
DTSTART;VALUE=DATE:20250502
RECURRENCE-ID;VALUE=DATE:20250502
COMPLETED:20250502T113705Z
PERCENT-COMPLETE:100
PRIORITY:0
END:VTODO
END:VCALENDAR
</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>
"""


def MockedDAVResponse(text, davclient=None):
    """
    For unit testing - a mocked DAVResponse with some specific content
    """
    resp = mock.MagicMock()
    resp.status_code = 207
    resp.reason = "multistatus"
    resp.headers = {}
    resp.content = text
    return DAVResponse(resp, davclient)


class MockedDAVClient(DAVClient):
    """
    For unit testing - a mocked DAVClient returning some specific content every time
    a request is performed
    """

    def __init__(self, xml_returned):
        self.xml_returned = xml_returned
        DAVClient.__init__(self, url="https://somwhere.in.the.universe.example/some/caldav/root")

    def request(self, *largs, **kwargs):
        return MockedDAVResponse(self.xml_returned)


class GetRefusedDAVClient(DAVClient):
    """
    For unit testing - a mocked DAVClient that refuses a plain GET with 403
    and answers a REPORT with some specific content.  This is the Robur
    shape: the server answers 403 rather than 404 for anything that does
    not exist, but a calendar-multiget REPORT against the existing parent
    collection still reports the missing href.
    """

    def __init__(self, report_xml):
        self.report_xml = report_xml
        DAVClient.__init__(self, url="https://somwhere.in.the.universe.example/some/caldav/root")

    def request(self, *largs, **kwargs):
        raise error.AuthorizationError(url=largs[0] if largs else None, reason="Forbidden")

    def report(self, *largs, **kwargs):
        return MockedDAVResponse(self.report_xml)


class TestCalDAV:
    """
    Test class for "pure" unit tests (small internal tests, testing that
    a small unit of code works as expected, without any third party
    dependencies, without accessing any caldav server)
    """

    @mock.patch("caldav.davclient.requests.Session.request")
    def testRequestNonAscii(self, mocked):
        """
        ref https://github.com/python-caldav/caldav/issues/83
        """
        mocked().status_code = 200
        mocked().headers = {}
        cal_url = "http://me:hunter2@calendar.møøh.example:80/"
        client = DAVClient(url=cal_url)
        response = client.put("/foo/møøh/bar", "bringebærsyltetøy 北京 пиво", {})
        assert response.status == 200
        assert response.tree is None

        response = client.put(
            "/foo/møøh/bar".encode(),
            "bringebærsyltetøy 北京 пиво".encode(),
            {},
        )
        assert response.status == 200
        assert response.tree is None

    def testSearchForRecurringTask(self):
        client = MockedDAVClient(recurring_task_response)
        calendar = Calendar(client, url="/calendar/issue491/")
        mytasks = calendar.search(todo=True, expand=False, post_filter=True)
        assert len(mytasks) == 1
        mytasks = calendar.search(
            todo=True,
            expand=True,
            start=datetime(2025, 5, 5),
            end=datetime(2025, 6, 5),
        )
        assert len(mytasks) == 9

        ## It should not include the COMPLETED recurrences
        mytasks = calendar.search(
            todo=True,
            expand=True,
            start=datetime(2025, 1, 1),
            end=datetime(2025, 6, 5),
        )
        assert len(mytasks) == 9

    def testSearcherReuseConsistency_Issue650(self):
        """
        Regression test for https://github.com/python-caldav/caldav/issues/650

        A CalDAVSearcher with todo=True and default include_completed (None) should
        return consistent results across multiple search() calls.  Previously, the
        icalendar_searcher library would mutate include_completed from None to False
        during the first search(), changing which code path subsequent calls took.
        """
        client = MockedDAVClient(mixed_todos_response)
        calendar = Calendar(client, url="/calendar/issue650/")

        ## Test 1: searcher with include_completed=None (default) should give consistent results
        searcher = calendar.searcher(todo=True)
        assert searcher.include_completed is None, "include_completed should start as None"

        first_result = searcher.search()
        assert len(first_result) == 2, f"Expected 2 pending todos, got {len(first_result)}"

        ## After calling search(), include_completed must not have been mutated
        assert searcher.include_completed is None, (
            "include_completed was mutated from None during search() - "
            "this breaks reuse of the searcher object (issue #650)"
        )

        second_result = searcher.search()
        assert len(second_result) == 2, (
            f"Second search() call returned {len(second_result)} results, "
            f"expected 2 - inconsistent behavior after searcher reuse (issue #650)"
        )

        ## Test 2: explicit include_completed=False should also give correct results
        searcher_false = calendar.searcher(todo=True, include_completed=False)
        result_false = searcher_false.search()
        assert len(result_false) == 2, (
            f"include_completed=False returned {len(result_false)} results, expected 2"
        )

        ## Test 3: include_completed=True should return all todos
        searcher_true = calendar.searcher(todo=True, include_completed=True)
        result_true = searcher_true.search()
        assert len(result_true) == 4, (
            f"include_completed=True returned {len(result_true)} results, expected 4"
        )

    def testLoadByMultiGet404(self):
        xml = """
<D:multistatus xmlns:D="DAV:">
  <D:response>
    <D:href>/calendars/pythoncaldav-test/20010712T182145Z-123401%40example.com.ics</D:href>
    <D:status>HTTP/1.1 404 Not Found</D:status>
  </D:response>
</D:multistatus>"""
        client = MockedDAVClient(xml)
        calendar = Calendar(client, url="/calendar/issue491/")
        object = Event(url="/calendar/issue491/notfound.ics", parent=calendar)
        with pytest.raises(error.NotFoundError):
            object.load_by_multiget()

    MULTIGET_FOUND = """
<D:multistatus xmlns:D="DAV:" xmlns:C="urn:ietf:params:xml:ns:caldav">
  <D:response>
    <D:href>/calendar/robur/found.ics</D:href>
    <D:propstat>
      <D:prop>
        <C:calendar-data>BEGIN:VCALENDAR
VERSION:2.0
BEGIN:VEVENT
UID:found@example.com
DTSTAMP:20260826T120000Z
DTSTART:20260827T120000Z
SUMMARY:found through multiget
END:VEVENT
END:VCALENDAR
</C:calendar-data>
      </D:prop>
      <D:status>HTTP/1.1 200 OK</D:status>
    </D:propstat>
  </D:response>
</D:multistatus>"""

    MULTIGET_NOT_FOUND = """
<D:multistatus xmlns:D="DAV:">
  <D:response>
    <D:href>/calendar/robur/gone.ics</D:href>
    <D:status>HTTP/1.1 404 Not Found</D:status>
  </D:response>
</D:multistatus>"""

    MULTIGET_FORBIDDEN = """
<D:multistatus xmlns:D="DAV:">
  <D:response>
    <D:href>/calendar/robur/secret.ics</D:href>
    <D:status>HTTP/1.1 403 Forbidden</D:status>
  </D:response>
</D:multistatus>"""

    def _robur_object(self, report_xml, path):
        client = GetRefusedDAVClient(report_xml)
        calendar = Calendar(client, url="/calendar/robur/")
        return Event(url=path, parent=calendar)

    def testLoadFallsBackToMultigetByDefault(self):
        """A GET refused with 403 is retried as a calendar-multiget REPORT.

        This is what makes Robur look like a well-behaved server from the
        outside: the object is loaded even though the GET was refused.
        """
        object = self._robur_object(self.MULTIGET_FOUND, "/calendar/robur/found.ics")
        object.load()
        assert "found through multiget" in object.data

    def testLoadWithoutMultigetFallbackRaisesTheServersOwnError(self):
        """load(multiget_fallback=False) surfaces what the server actually said.

        Without this, no caller can tell a server that answers 404 from one
        that answers 403 and is rescued by the REPORT - which is precisely
        what "non-existing-raises-not-found" is supposed to describe.
        """
        object = self._robur_object(self.MULTIGET_FOUND, "/calendar/robur/found.ics")
        with pytest.raises(error.AuthorizationError):
            object.load(multiget_fallback=False)

    def testTheMultigetFallbackDoesNotLaunderARealForbidden(self):
        """A genuine 403 does not come out of the multiget fallback as a 404.

        The fallback only turns a refused GET into NotFoundError when the
        REPORT itself reports the href as missing: _extract_multiget_results
        raises NotFoundError on an inner 404, and _post_load_by_multiget
        raises it on an empty result set.  An inner 403 hits neither -
        validate_status rejects it, and the caller gets a ResponseError.  So
        "it is forbidden" and "it is not there" stay distinguishable, which
        is why non-existing-raises-not-found can be observed at all.
        """
        object = self._robur_object(self.MULTIGET_FORBIDDEN, "/calendar/robur/secret.ics")
        with pytest.raises(error.ResponseError):
            object.load()

    def testLoadFallsBackToNotFoundWhenTheReportSaysSo(self):
        """A refused GET plus a REPORT reporting an inner 404 gives NotFoundError."""
        object = self._robur_object(self.MULTIGET_NOT_FOUND, "/calendar/robur/gone.ics")
        with pytest.raises(error.NotFoundError):
            object.load()

    def testPropfindResponseLevelNotFound(self):
        """A PROPFIND answered with a response-level 404 must raise NotFoundError.

        RFC 4918 section 14.24 lets a <response> carry either propstat
        elements or a bare <status>, so a server may report "this resource
        does not exist" inside a 207 Multi-Status rather than as a transport
        level 404.  Xandikos does exactly that for PROPFIND on a missing
        collection (while answering REPORT on the very same URL with a plain
        404).  We used to look only at the propstats, find none, and hand the
        caller a None value for every requested property.
        """
        xml = """
<D:multistatus xmlns:D="DAV:">
  <D:response>
    <D:href>/calendars/shouldnotexist/</D:href>
    <D:status>HTTP/1.1 404 Not Found</D:status>
  </D:response>
</D:multistatus>"""
        client = MockedDAVClient(xml)
        calendar = Calendar(client, url="/calendars/shouldnotexist/")
        with pytest.raises(error.NotFoundError):
            calendar.get_display_name()
        with pytest.raises(error.NotFoundError):
            calendar.get_properties([dav.DisplayName()])

    def testPropfindResponseLevelNotFoundOnlyWhenAllAreMissing(self):
        """A 404 for one href among several must NOT raise.

        On a Depth: 1 PROPFIND a single missing child is a normal, expected
        part of the reply - only a reply where nothing at all was found means
        the requested resource is gone.
        """
        xml = """
<D:multistatus xmlns:D="DAV:">
  <D:response>
    <D:href>/calendars/</D:href>
    <D:propstat>
      <D:prop><D:displayname>calendars</D:displayname></D:prop>
      <D:status>HTTP/1.1 200 OK</D:status>
    </D:propstat>
  </D:response>
  <D:response>
    <D:href>/calendars/vanished/</D:href>
    <D:status>HTTP/1.1 404 Not Found</D:status>
  </D:response>
</D:multistatus>"""
        client = MockedDAVClient(xml)
        calendar = Calendar(client, url="/calendars/")
        props = calendar.get_properties([dav.DisplayName()], depth=1)
        assert props[dav.DisplayName.tag] == "calendars"

    @mock.patch("caldav.davclient.requests.Session.request")
    def testRequestCustomHeaders(self, mocked):
        """
        ref https://github.com/python-caldav/caldav/issues/285
        also ref https://github.com/python-caldav/caldav/issues/385
        """
        mocked().status_code = 200
        mocked().headers = {}
        cal_url = "http://me:hunter2@calendar.møøh.example:80/"
        client = DAVClient(
            url=cal_url,
            headers={"X-NC-CalDAV-Webcal-Caching": "On", "User-Agent": "MyCaldavApp"},
        )
        assert client.headers["Content-Type"] == "text/xml"
        assert client.headers["X-NC-CalDAV-Webcal-Caching"] == "On"
        ## User-Agent would be overwritten by some boring default in earlier versions
        assert client.headers["User-Agent"] == "MyCaldavApp"

    @mock.patch("caldav.davclient.requests.Session.request")
    def testRequestUserAgent(self, mocked):
        """
        ref https://github.com/python-caldav/caldav/issues/391
        """
        mocked().status_code = 200
        mocked().headers = {}
        cal_url = "http://me:hunter2@calendar.møøh.example:80/"
        client = DAVClient(
            url=cal_url,
        )
        assert client.headers["Content-Type"] == "text/xml"
        assert client.headers["User-Agent"].startswith("python-caldav/")

    @mock.patch("caldav.davclient.requests.Session.request")
    def testEmptyXMLNoContentLength(self, mocked):
        """
        ref https://github.com/python-caldav/caldav/issues/213
        """
        mocked().status_code = 200
        mocked().headers = {"Content-Type": "text/xml"}
        mocked().content = ""
        response = DAVClient(url="AsdfasDF").request("/")
        assert response.status == 200

    @mock.patch("caldav.davclient.requests.Session.request")
    def testNonValidXMLNoContentLength(self, mocked):
        """
        If XML is expected but nonvalid XML is given, an error should be raised
        """
        mocked().status_code = 200
        mocked().headers = {"Content-Type": "text/xml"}
        mocked().content = "this is not XML"
        client = DAVClient(url="AsdfasDF")
        with pytest.raises(lxml.etree.XMLSyntaxError):
            client.request("/")

    @mock.patch("caldav.davclient.requests.Session.request")
    def testCommunicationDump(self, mocked):
        """
        ref https://github.com/python-caldav/caldav/issues/638
        When PYTHON_CALDAV_COMMDUMP (or debug_dump_communication) is set,
        request/response data should be written to a temp file.
        """
        import glob
        import os
        import tempfile

        mocked().status_code = 200
        mocked().headers = {"Content-Type": "text/plain"}
        mocked().content = b""
        mocked().reason = "OK"
        mocked().reason_phrase = None

        from caldav.lib import error as caldav_error

        old_value = caldav_error.debug_dump_communication
        caldav_error.debug_dump_communication = True
        try:
            client = DAVClient(url="http://test.example.com/")
            before = set(glob.glob(os.path.join(tempfile.gettempdir(), "caldavcomm*")))
            client.request("/")
            after = set(glob.glob(os.path.join(tempfile.gettempdir(), "caldavcomm*")))
            new_files = after - before
            assert len(new_files) == 1
            content = open(list(new_files)[0], "rb").read()
            assert b"GET /" in content
            assert b"200 OK" in content
        finally:
            caldav_error.debug_dump_communication = old_value

    def testPathWithEscapedCharacters(self):
        xml = b"""<D:multistatus xmlns:D="DAV:" xmlns:caldav="urn:ietf:params:xml:ns:caldav" xmlns:cs="http://calendarserver.org/ns/" xmlns:ical="http://apple.com/ns/ical/">
  <D:response xmlns:carddav="urn:ietf:params:xml:ns:carddav" xmlns:cm="http://cal.me.com/_namespace/" xmlns:md="urn:mobileme:davservices">
    <D:href>/some/caldav/root/133bahgr6ohlo9ungq0it45vf8%40group.calendar.google.com/events/</D:href>
    <D:propstat>
      <D:status>HTTP/1.1 200 OK</D:status>
      <D:prop>
        <caldav:supported-calendar-component-set>
          <caldav:comp name="VEVENT"/>
        </caldav:supported-calendar-component-set>
      </D:prop>
    </D:propstat>
  </D:response>
</D:multistatus>"""
        client = MockedDAVClient(xml)
        assert client.calendar(
            url="https://somwhere.in.the.universe.example/some/caldav/root/133bahgr6ohlo9ungq0it45vf8%40group.calendar.google.com/events/"
        ).get_supported_components() == ["VEVENT"]

    def test_get_supported_components_present(self):
        """Test get_supported_components when the property is present in the server response."""
        xml = b"""<multistatus xmlns="DAV:">
  <response xmlns="DAV:">
    <href>/some/caldav/root/testcal/</href>
    <propstat>
      <prop>
        <supported-calendar-component-set xmlns="urn:ietf:params:xml:ns:caldav">
          <comp xmlns="urn:ietf:params:xml:ns:caldav" name="VEVENT"/>
        </supported-calendar-component-set>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>"""
        client = MockedDAVClient(xml)
        assert client.calendar(
            url="https://somwhere.in.the.universe.example/some/caldav/root/testcal/"
        ).get_supported_components() == ["VEVENT"]

    def test_get_supported_components_absent(self):
        """RFC 4791 says supported-calendar-component-set is optional.
        When absent, the server MUST accept all component types, and the
        client MUST assume that all component types are accepted.
        Regression for https://github.com/python-caldav/caldav/issues/653"""
        xml = b"""<D:multistatus xmlns:D="DAV:">
  <D:response>
    <D:href>/some/caldav/root/testcal/</D:href>
    <D:propstat>
      <D:status>HTTP/1.1 200 OK</D:status>
      <D:prop/>
    </D:propstat>
  </D:response>
</D:multistatus>"""
        client = MockedDAVClient(xml)
        components = client.calendar(
            url="https://somwhere.in.the.universe.example/some/caldav/root/testcal/"
        ).get_supported_components()
        assert "VEVENT" in components
        assert "VTODO" in components
        assert "VJOURNAL" in components

    def test_get_supported_components_absent_hints(self):
        """When supported-calendar-component-set is absent, the RFC default is filtered
        by compatibility hints: if the server is known not to support VTODO or VJOURNAL,
        those should be excluded from the returned list.
        See https://github.com/python-caldav/caldav/issues/653"""
        from caldav.compatibility_hints import FeatureSet

        xml = b"""<D:multistatus xmlns:D="DAV:">
  <D:response>
    <D:href>/some/caldav/root/testcal/</D:href>
    <D:propstat>
      <D:status>HTTP/1.1 200 OK</D:status>
      <D:prop/>
    </D:propstat>
  </D:response>
</D:multistatus>"""
        client = MockedDAVClient(xml)
        client.features = FeatureSet(
            {
                "save-load.todo": {"support": "unsupported"},
                "save-load.journal": {"support": "unsupported"},
            }
        )
        components = client.calendar(
            url="https://somwhere.in.the.universe.example/some/caldav/root/testcal/"
        ).get_supported_components()
        assert components == ["VEVENT"]

    def testAbsoluteURL(self):
        """Version 0.7.0 does not handle responses with absolute URLs very well, ref https://github.com/python-caldav/caldav/pull/103"""
        ## none of this should initiate any communication
        client = DAVClient(url="http://cal.example.com/")
        principal = Principal(client=client, url="http://cal.example.com/home/bernard/")
        ## now, ask for the calendar_home_set, but first we need to mock up client.propfind
        mocked_response = mock.MagicMock()
        mocked_response.status_code = 207
        mocked_response.reason = "multistatus"
        mocked_response.headers = {}
        mocked_response.content = """
<xml>
<d:multistatus xmlns:d="DAV:" xmlns:c="urn:ietf:params:xml:ns:caldav">
    <d:response>
        <d:href>http://cal.example.com/home/bernard/</d:href>
        <d:propstat>
            <d:prop>
                <c:calendar-home-set>
                    <d:href>http://cal.example.com/home/bernard/calendars/</d:href>
                </c:calendar-home-set>
            </d:prop>
            <d:status>HTTP/1.1 200 OK</d:status>
        </d:propstat>
    </d:response>
</d:multistatus>
</xml>"""
        mocked_davresponse = DAVResponse(mocked_response)
        client.propfind = mock.MagicMock(return_value=mocked_davresponse)
        bernards_calendars = principal.calendar_home_set
        assert bernards_calendars.url == URL("http://cal.example.com/home/bernard/calendars/")

    def _load(self, only_if_unloaded=True):
        self.data = todo6

    def _batch_load(self, objects):
        ## Search results are batch-loaded via a single calendar-multiget REPORT
        ## (Calendar._batch_load_objects); the mocked server returns no
        ## calendar-data, so inject todo6 here the same way _load does per object.
        for obj in objects:
            obj.data = todo6

    @mock.patch("caldav.collection.Calendar._batch_load_objects", new=_batch_load)
    @mock.patch("caldav.calendarobjectresource.CalendarObjectResource.load", new=_load)
    def testDateSearch(self):
        """
        ## ref https://github.com/python-caldav/caldav/issues/133
        """
        xml = """<xml><multistatus xmlns="DAV:">
<response>
    <href>/principals/calendar/home@petroski.example.com/963/43B060B3-A023-48ED-B9E7-6FFD38D5073E.ics</href>
    <propstat>
      <prop/>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
    <propstat>
      <prop>
        <calendar-data xmlns="urn:ietf:params:xml:ns:caldav"/>
        <expand xmlns="urn:ietf:params:xml:ns:caldav"/>
      </prop>
      <status>HTTP/1.1 404 Not Found</status>
    </propstat>
  </response>
  <response>
    <href>/principals/calendar/home@petroski.example.com/963/114A4E50-8835-42E1-8185-8A97567B5C1A.ics</href>
    <propstat>
      <prop/>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
    <propstat>
      <prop>
        <calendar-data xmlns="urn:ietf:params:xml:ns:caldav"/>
        <expand xmlns="urn:ietf:params:xml:ns:caldav"/>
      </prop>
      <status>HTTP/1.1 404 Not Found</status>
    </propstat>
  </response>
  <response>
    <href>/principals/calendar/home@petroski.example.com/963/C20A8820-7156-4DD2-AD1D-17105D923145.ics</href>
    <propstat>
      <prop/>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
    <propstat>
      <prop>
        <calendar-data xmlns="urn:ietf:params:xml:ns:caldav"/>
        <expand xmlns="urn:ietf:params:xml:ns:caldav"/>
      </prop>
      <status>HTTP/1.1 404 Not Found</status>
    </propstat>
  </response>
</multistatus></xml>
"""
        client = MockedDAVClient(xml)
        calendar = Calendar(client, url="/principals/calendar/home@petroski.example.com/963/")
        ## expand=False does no client-side time-range filtering, so all three
        ## server-returned hrefs are returned regardless of the search window.
        with pytest.deprecated_call():
            results = calendar.date_search(datetime(2021, 2, 1), datetime(2021, 2, 7), expand=False)
            assert len(results) == 3

    def testCalendar(self):
        """
        Principal.calendar() and CalendarSet.calendar() should create
        Calendar objects without initiating any communication with the
        server.  Calendar.event() should create Event object without
        initiating any communication with the server.
        DAVClient.__init__ also doesn't do any communication
        Principal.__init__ as well, if the principal_url is given
        Principal.calendar_home_set needs to be set or the server will be queried
        """
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)

        principal = Principal(client, cal_url + "me/")
        principal.calendar_home_set = cal_url + "me/calendars/"
        # calendar_home_set is actually a CalendarSet object
        assert isinstance(principal.calendar_home_set, CalendarSet)
        calendar1 = principal.calendar(name="foo", cal_id="bar")
        calendar2 = principal.calendar_home_set.calendar(name="foo", cal_id="bar")
        calendar3 = principal.calendar(cal_id="bar")
        assert calendar1.url == calendar2.url
        assert calendar1.url == calendar3.url
        assert calendar1.url == "http://calendar.example:80/me/calendars/bar/"

        # principal.calendar_home_set can also be set to an object
        # This should be noop
        principal.calendar_home_set = principal.calendar_home_set
        calendar1 = principal.calendar(name="foo", cal_id="bar")
        assert calendar1.url == calendar2.url

        # When building a calendar from a relative URL and a client,
        # the relative URL should be appended to the base URL in the client
        calendar1 = Calendar(client, "someoneelse/calendars/main_calendar")
        calendar2 = Calendar(
            client,
            "http://me:hunter2@calendar.example:80/someoneelse/calendars/main_calendar",
        )
        assert calendar1.url == calendar2.url

    def test_get_events_icloud(self):
        """
        tests that some XML observed from the icloud returns 0 events found.
        """
        xml = """
<multistatus xmlns="DAV:">
  <response>
    <href>/17149682/calendars/testcalendar-485d002e-31b9-4147-a334-1d71503a4e2c/</href>
    <propstat>
      <prop>    </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
    <propstat>
      <prop>
        <calendar-data xmlns="urn:ietf:params:xml:ns:caldav"/>
      </prop>
      <status>HTTP/1.1 404 Not Found</status>
    </propstat>
  </response>
</multistatus>
        """
        client = MockedDAVClient(xml)
        calendar = Calendar(
            client,
            url="/17149682/calendars/testcalendar-485d002e-31b9-4147-a334-1d71503a4e2c/",
        )
        assert len(calendar.get_events()) == 0

    def test_get_calendars(self):
        xml = """
<D:multistatus xmlns:D="DAV:">
  <D:response>
    <D:href>/dav/tobias%40redpill-linpro.com/</D:href>
    <D:propstat>
      <D:status>HTTP/1.1 200 OK</D:status>
      <D:prop>
        <D:resourcetype>
          <D:collection/>
        </D:resourcetype>
        <D:displayname>USER_ROOT</D:displayname>
      </D:prop>
    </D:propstat>
  </D:response>
  <D:response>
    <D:href>/dav/tobias%40redpill-linpro.com/Inbox/</D:href>
    <D:propstat>
      <D:status>HTTP/1.1 200 OK</D:status>
      <D:prop>
        <D:resourcetype>
          <D:collection/>
          <C:schedule-inbox xmlns:C="urn:ietf:params:xml:ns:caldav"/>
        </D:resourcetype>
        <D:displayname>Inbox</D:displayname>
      </D:prop>
    </D:propstat>
  </D:response>
  <D:response>
    <D:href>/dav/tobias%40redpill-linpro.com/Emailed%20Contacts/</D:href>
    <D:propstat>
      <D:status>HTTP/1.1 200 OK</D:status>
      <D:prop>
        <D:resourcetype>
          <D:collection/>
          <C:addressbook xmlns:C="urn:ietf:params:xml:ns:carddav"/>
        </D:resourcetype>
        <D:displayname>Emailed Contacts</D:displayname>
      </D:prop>
    </D:propstat>
  </D:response>
  <D:response>
    <D:href>/dav/tobias%40redpill-linpro.com/Calendarc5f1a47c-2d92-11e3-b654-0016eab36bf4.ics</D:href>
    <D:propstat>
      <D:status>HTTP/1.1 200 OK</D:status>
      <D:prop>
        <D:resourcetype/>
        <D:displayname>Calendarc5f1a47c-2d92-11e3-b654-0016eab36bf4.ics</D:displayname>
      </D:prop>
    </D:propstat>
  </D:response>
  <D:response>
    <D:href>/dav/tobias%40redpill-linpro.com/Yep/</D:href>
    <D:propstat>
      <D:status>HTTP/1.1 200 OK</D:status>
      <D:prop>
        <D:resourcetype>
          <D:collection/>
          <C:calendar xmlns:C="urn:ietf:params:xml:ns:caldav"/>
        </D:resourcetype>
        <D:displayname>Yep</D:displayname>
      </D:prop>
    </D:propstat>
  </D:response>
</D:multistatus>
"""
        client = MockedDAVClient(xml)
        calendar_home_set = CalendarSet(client, url="/dav/tobias%40redpill-linpro.com/")
        assert len(calendar_home_set.get_calendars()) == 1

    def test_xml_parsing(self):
        """
        DAVResponse has quite some code to parse the XML received from the
        server.  This test contains real XML received from various
        caldav servers, and the expected result from the parse
        methods.
        """
        xml = """
<multistatus xmlns="DAV:">
  <response xmlns="DAV:">
    <href>/</href>
    <propstat>
      <prop>
        <current-user-principal xmlns="DAV:">
          <href xmlns="DAV:">/17149682/principal/</href>
        </current-user-principal>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>
"""
        expected_result = {"/": {"{DAV:}current-user-principal": "/17149682/principal/"}}

        assert (
            MockedDAVResponse(xml).expand_simple_props(props=[dav.CurrentUserPrincipal()])
            == expected_result
        )

        ## This duplicated response is observed in the real world -
        ## see https://github.com/python-caldav/caldav/issues/136
        ## (though I suppose there was an email address instead of
        ## simply "frank", the XML I got was obfuscated)
        xml = """<multistatus xmlns="DAV:">
  <response>
    <href>/principals/users/frank/</href>
    <propstat>
      <prop>
        <current-user-principal>
          <href>/principals/users/frank/</href>
        </current-user-principal>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
  <response>
    <href>/principals/users/frank/</href>
    <propstat>
      <prop>
        <current-user-principal>
          <href>/principals/users/frank/</href>
        </current-user-principal>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>
"""
        expected_result = {
            "/principals/users/frank/": {"{DAV:}current-user-principal": "/principals/users/frank/"}
        }
        assert (
            MockedDAVResponse(xml).expand_simple_props(props=[dav.CurrentUserPrincipal()])
            == expected_result
        )

        xml = """
<multistatus xmlns="DAV:">
  <response xmlns="DAV:">
    <href>/17149682/principal/</href>
    <propstat>
      <prop>
        <calendar-home-set xmlns="urn:ietf:params:xml:ns:caldav">
          <href xmlns="DAV:">https://p62-caldav.icloud.com:443/17149682/calendars/</href>
        </calendar-home-set>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>"""
        expected_result = {
            "/17149682/principal/": {
                "{urn:ietf:params:xml:ns:caldav}calendar-home-set": "https://p62-caldav.icloud.com:443/17149682/calendars/"
            }
        }
        assert (
            MockedDAVResponse(xml).expand_simple_props(props=[cdav.CalendarHomeSet()])
            == expected_result
        )

        xml = """
<multistatus xmlns="DAV:">
  <response xmlns="DAV:">
    <href>/</href>
    <propstat>
      <prop>
        <current-user-principal xmlns="DAV:">
          <href xmlns="DAV:">/17149682/principal/</href>
        </current-user-principal>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>"""
        expected_result = {"/": {"{DAV:}current-user-principal": "/17149682/principal/"}}
        assert (
            MockedDAVResponse(xml).expand_simple_props(props=[dav.CurrentUserPrincipal()])
            == expected_result
        )

        xml = """
<multistatus xmlns="DAV:">
  <response>
    <href>/17149682/calendars/testcalendar-84439d0b-ce46-4416-b978-7b4009122c64/</href>
    <propstat>
      <prop>
                </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
    <propstat>
      <prop>
        <calendar-data xmlns="urn:ietf:params:xml:ns:caldav"/>
      </prop>
      <status>HTTP/1.1 404 Not Found</status>
    </propstat>
  </response>
  <response>
    <href>/17149682/calendars/testcalendar-84439d0b-ce46-4416-b978-7b4009122c64/20010712T182145Z-123401%40example.com.ics</href>
    <propstat>
      <prop>
        <calendar-data xmlns="urn:ietf:params:xml:ns:caldav">BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:20010712T182145Z-123401@example.com
DTSTAMP:20060712T182145Z
DTSTART:20060714T170000Z
DTEND:20060715T040000Z
SUMMARY:Bastille Day Party
END:VEVENT
END:VCALENDAR
</calendar-data>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>
"""
        expected_result = {
            "/17149682/calendars/testcalendar-84439d0b-ce46-4416-b978-7b4009122c64/": {
                "{urn:ietf:params:xml:ns:caldav}calendar-data": None
            },
            "/17149682/calendars/testcalendar-84439d0b-ce46-4416-b978-7b4009122c64/20010712T182145Z-123401@example.com.ics": {
                "{urn:ietf:params:xml:ns:caldav}calendar-data": "BEGIN:VCALENDAR\nVERSION:2.0\nPRODID:-//Example Corp.//CalDAV Client//EN\nBEGIN:VEVENT\nUID:20010712T182145Z-123401@example.com\nDTSTAMP:20060712T182145Z\nDTSTART:20060714T170000Z\nDTEND:20060715T040000Z\nSUMMARY:Bastille Day Party\nEND:VEVENT\nEND:VCALENDAR\n"
            },
        }
        assert (
            MockedDAVResponse(xml).expand_simple_props(props=[cdav.CalendarData()])
            == expected_result
        )

        xml = """
<multistatus xmlns="DAV:">
  <response xmlns="DAV:">
    <href>/17149682/calendars/</href>
    <propstat>
      <prop>
        <resourcetype xmlns="DAV:">
          <collection/>
        </resourcetype>
        <displayname xmlns="DAV:">Ny Test</displayname>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
  <response xmlns="DAV:">
    <href>/17149682/calendars/06888b87-397f-11eb-943b-3af9d3928d42/</href>
    <propstat>
      <prop>
        <resourcetype xmlns="DAV:">
          <collection/>
          <calendar xmlns="urn:ietf:params:xml:ns:caldav"/>
        </resourcetype>
        <displayname xmlns="DAV:">calfoo3</displayname>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
  <response xmlns="DAV:">
    <href>/17149682/calendars/inbox/</href>
    <propstat>
      <prop>
        <resourcetype xmlns="DAV:">
          <collection/>
          <schedule-inbox xmlns="urn:ietf:params:xml:ns:caldav"/>
        </resourcetype>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
    <propstat>
      <prop>
        <displayname xmlns="DAV:"/>
      </prop>
      <status>HTTP/1.1 404 Not Found</status>
    </propstat>
  </response>
  <response xmlns="DAV:">
    <href>/17149682/calendars/testcalendar-e2910e0a-feab-4b51-b3a8-55828acaa912/</href>
    <propstat>
      <prop>
        <resourcetype xmlns="DAV:">
          <collection/>
          <calendar xmlns="urn:ietf:params:xml:ns:caldav"/>
        </resourcetype>
        <displayname xmlns="DAV:">Yep</displayname>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>
"""
        expected_result = {
            "/17149682/calendars/": {
                "{DAV:}resourcetype": ["{DAV:}collection"],
                "{DAV:}displayname": "Ny Test",
            },
            "/17149682/calendars/06888b87-397f-11eb-943b-3af9d3928d42/": {
                "{DAV:}resourcetype": [
                    "{DAV:}collection",
                    "{urn:ietf:params:xml:ns:caldav}calendar",
                ],
                "{DAV:}displayname": "calfoo3",
            },
            "/17149682/calendars/inbox/": {
                "{DAV:}resourcetype": [
                    "{DAV:}collection",
                    "{urn:ietf:params:xml:ns:caldav}schedule-inbox",
                ],
                "{DAV:}displayname": None,
            },
            "/17149682/calendars/testcalendar-e2910e0a-feab-4b51-b3a8-55828acaa912/": {
                "{DAV:}resourcetype": [
                    "{DAV:}collection",
                    "{urn:ietf:params:xml:ns:caldav}calendar",
                ],
                "{DAV:}displayname": "Yep",
            },
        }
        assert (
            MockedDAVResponse(xml).expand_simple_props(
                props=[dav.DisplayName()], multi_value_props=[dav.ResourceType()]
            )
            == expected_result
        )

        xml = """
<multistatus xmlns="DAV:">
  <response xmlns="DAV:">
    <href>/17149682/calendars/testcalendar-f96b3bf0-09e1-4f3d-b891-3a25c99a2894/</href>
    <propstat>
      <prop>
        <getetag xmlns="DAV:">"kkkgopik"</getetag>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
  <response xmlns="DAV:">
    <href>/17149682/calendars/testcalendar-f96b3bf0-09e1-4f3d-b891-3a25c99a2894/1761bf8c-6363-11eb-8fe4-74e5f9bfd8c1.ics</href>
    <propstat>
      <prop>
        <getetag xmlns="DAV:">"kkkgorwx"</getetag>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
  <response xmlns="DAV:">
    <href>/17149682/calendars/testcalendar-f96b3bf0-09e1-4f3d-b891-3a25c99a2894/20010712T182145Z-123401%40example.com.ics</href>
    <propstat>
      <prop>
        <getetag xmlns="DAV:">"kkkgoqqu"</getetag>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
  <sync-token>HwoQEgwAAAh4yw8ntwAAAAAYAhgAIhUIopml463FieB4EKq9+NSn04DrkQEoAA==</sync-token>
</multistatus>
"""
        expected_results = {
            "/17149682/calendars/testcalendar-f96b3bf0-09e1-4f3d-b891-3a25c99a2894/": {
                "{DAV:}getetag": '"kkkgopik"',
                "{urn:ietf:params:xml:ns:caldav}calendar-data": None,
            },
            "/17149682/calendars/testcalendar-f96b3bf0-09e1-4f3d-b891-3a25c99a2894/1761bf8c-6363-11eb-8fe4-74e5f9bfd8c1.ics": {
                "{DAV:}getetag": '"kkkgorwx"',
                "{urn:ietf:params:xml:ns:caldav}calendar-data": None,
            },
            "/17149682/calendars/testcalendar-f96b3bf0-09e1-4f3d-b891-3a25c99a2894/20010712T182145Z-123401@example.com.ics": {
                "{DAV:}getetag": '"kkkgoqqu"',
                "{urn:ietf:params:xml:ns:caldav}calendar-data": None,
            },
        }
        ## This assert was missing: the XML and the expected dict above were
        ## built and then never compared.  Note the third href is
        ## percent-encoded in the XML and plain in the expected keys, so this
        ## also covers the unquoting.
        assert (
            MockedDAVResponse(xml).expand_simple_props(props=[dav.GetEtag(), cdav.CalendarData()])
            == expected_results
        )

    def testHugeTreeParam(self):
        """
        With dealing with a huge XML response, such as event containing attachments, XMLParser will throw an exception
        huge_tree parameters allows to handle this kind of events.
        """

        xml = """
<multistatus xmlns="DAV:">
  <response>
    <href>/17149682/calendars/testcalendar-84439d0b-ce46-4416-b978-7b4009122c64/</href>
    <propstat>
      <prop>
                </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
    <propstat>
      <prop>
        <calendar-data xmlns="urn:ietf:params:xml:ns:caldav"/>
      </prop>
      <status>HTTP/1.1 404 Not Found</status>
    </propstat>
  </response>
  <response>
    <href>/17149682/calendars/testcalendar-84439d0b-ce46-4416-b978-7b4009122c64/20010712T182145Z-123401%40example.com.ics</href>
    <propstat>
      <prop>
        <calendar-data xmlns="urn:ietf:params:xml:ns:caldav">

BEGIN:VCALENDAR
PRODID:-//MDaemon Technologies Ltd//MDaemon 21.5.2
VERSION:2.0
METHOD:PUBLISH
BEGIN:VEVENT
UID:
 040000008200E0007000B7101A82E0080000000050BF99B19D31
SEQUENCE:0
DTSTAMP:20230213T142930Z
SUMMARY:This a summary of a very bug event
DESCRIPTION:Description of this very big event
LOCATION:Somewhere
ORGANIZER:MAILTO:noreply@test.com
PRIORITY:5
ATTACH;VALUE=BINARY;ENCODING=BASE64;FMTTYPE=image/jpeg;
 X-FILENAME=image001.jpg;X-ORACLE-FILENAME=image001.jpg:
"""
        xml += (
            "gIyIoLTkwKCo2KyIjM4444449QEBAJjBGS0U+Sjk/QD3/2wBDAQsLCw8NDx0QEB09KSMpPT09\n" * 153490
        )
        xml += """
 /Z
DTSTART;TZID="Europe/Paris":20230310T140000
DTEND;TZID="Europe/Paris":20230310T150000
END:VEVENT
END:VCALENDAR
</calendar-data>
      </prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>
"""
        davclient = MockedDAVClient(xml)
        resp = mock.MagicMock()
        resp.headers = {"Content-Type": "text/xml"}
        resp.content = xml

        ## It seems like the huge_tree flag is not necessary in all
        ## environments as of 2023-07.  Perhaps versioning issues with
        ## the lxml library.
        # davclient.huge_tree = False
        # try:
        #    import pdb; pdb.set_trace()
        #    DAVResponse(resp, davclient=davclient)
        #    assert False
        # except Exception as e:
        #    assert type(e) == lxml.etree.XMLSyntaxError

        davclient.huge_tree = True
        try:
            DAVResponse(resp, davclient=davclient)
            assert True
        except:
            assert False

    def testFailedQuery(self):
        """
        ref https://github.com/python-caldav/caldav/issues/54
        """
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        calhome = CalendarSet(client, cal_url + "me/")

        ## syntesize a failed response
        class FailedResp:
            pass

        failedresp = FailedResp()
        failedresp.status = 400
        failedresp.reason = "you are wrong"
        failedresp.raw = "your request does not adhere to standards"

        ## synthesize a new http method
        calhome.client.unknown_method = lambda url, body, depth: failedresp

        ## call it.
        with pytest.raises(error.DAVError):
            calhome._query(query_method="unknown_method")

    def testDefaultClient(self):
        """When no client is given to a DAVObject, but the parent is given,
        parent.client will be used"""
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        calhome = CalendarSet(client, cal_url + "me/")
        calendar = Calendar(parent=calhome)
        assert calendar.client == calhome.client

    def testData(self):
        """
        Event.data should always return a unicode string, without \r
        Event.wire_data should always return a byte string, with \r\n
        """
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        my_event = Event(client, data=ev1)
        ## bytes on py3, normal string on py2 (but nobody uses python2, I hope?)
        bytestr = b"".__class__
        assert isinstance(my_event.data, str)
        assert isinstance(my_event.wire_data, bytestr)
        ## this may have side effects, as it converts the internal storage
        my_event.get_icalendar_instance()
        assert isinstance(my_event.data, str)
        assert isinstance(my_event.wire_data, bytestr)
        ## this may have side effects, as it converts the internal storage
        my_event.get_vobject_instance()
        assert isinstance(my_event.data, str)
        assert isinstance(my_event.wire_data, bytestr)
        my_event.wire_data = to_wire(ev1)
        assert isinstance(my_event.data, str)
        assert isinstance(my_event.wire_data, bytestr)
        my_event.data = to_normal_str(ev1)
        assert isinstance(my_event.data, str)
        assert isinstance(my_event.wire_data, bytestr)

    def testInstance(self):
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        my_event = Event(client, data=ev1)
        my_event.vobject_instance.vevent.summary.value = "new summary"
        assert "new summary" in my_event.data
        icalobj = my_event.icalendar_instance
        icalobj.subcomponents[0]["SUMMARY"] = "yet another summary"
        assert my_event.vobject_instance.vevent.summary.value == "yet another summary"
        ## Now the data has been converted from string to vobject to string to icalendar to string to vobject and ... will the string still match the original?
        lines_now = my_event.data.strip().split("\n")
        lines_orig = ev1.replace("Bastille Day Party", "yet another summary").strip().split("\n")
        lines_now.sort()
        lines_orig.sort()
        assert lines_now == lines_orig

    def testComponent(self):
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        my_event = Event(client, data=ev1)
        icalcomp = my_event.icalendar_component
        icalcomp["SUMMARY"] = "yet another summary"
        assert my_event.vobject_instance.vevent.summary.value == "yet another summary"
        ## will the string still match the original?
        lines_now = my_event.data.strip().split("\n")
        lines_orig = ev1.replace("Bastille Day Party", "yet another summary").strip().split("\n")
        lines_now.sort()
        lines_orig.sort()
        assert lines_now == lines_orig
        ## Can we replace the component?  (One shouldn't do things like this in normal circumstances though ... both because the uid changes and because the component type changes - we're putting a vtodo into an Event class ...)
        icalendar_component = icalendar.Todo.from_ical(todo).subcomponents[0]
        my_event.icalendar_component = icalendar_component
        assert (
            my_event.vobject_instance.vtodo.summary.value
            == "Submit Quebec Income Tax Return for 2006"
        )

    def testComponentSet(self):
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        target = Event(client, data=evr)

        ## Creating some dummy data such that the target has more than one subcomponent
        with pytest.deprecated_call():
            target.expand_rrule(start=datetime(1996, 10, 10), end=datetime(1999, 12, 12))
            assert len(target.icalendar_instance.subcomponents) == 3

        ## The following should not fail within _set_icalendar_component
        target.icalendar_component = icalendar.Todo.from_ical(todo).subcomponents[0]
        assert len(target.icalendar_instance.subcomponents) == 1

    def testNewDataAPI(self):
        """Test the new safe data access API (issue #613).

        The new API provides:
        - get_data() / get_icalendar_instance() / get_vobject_instance() for read-only access
        - edit_icalendar_instance() / edit_vobject_instance() context managers for editing
        """
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        event = Event(client, data=ev1)

        # Test get_data() returns string
        data = event.get_data()
        assert isinstance(data, str)
        assert "Bastille Day Party" in data

        # Test get_icalendar_instance() returns a COPY
        ical1 = event.get_icalendar_instance()
        ical2 = event.get_icalendar_instance()
        assert ical1 is not ical2  # Different objects (copies)

        # Modifying the copy should NOT affect the original
        for comp in ical1.subcomponents:
            if comp.name == "VEVENT":
                comp["SUMMARY"] = "Modified in copy"
        assert "Modified in copy" not in event.get_data()

        # Test get_vobject_instance() returns a COPY
        vobj1 = event.get_vobject_instance()
        vobj2 = event.get_vobject_instance()
        assert vobj1 is not vobj2  # Different objects (copies)

        # Test edit_icalendar_instance() context manager
        with event.edit_icalendar_instance() as cal:
            for comp in cal.subcomponents:
                if comp.name == "VEVENT":
                    comp["SUMMARY"] = "Edited Summary"

        # Changes should be reflected
        assert "Edited Summary" in event.get_data()

        # Test edit_vobject_instance() context manager
        with event.edit_vobject_instance() as vobj:
            vobj.vevent.summary.value = "Vobject Edit"

        assert "Vobject Edit" in event.get_data()

        # Test that nested borrowing of different types raises error
        with event.edit_icalendar_instance() as cal:
            with pytest.raises(RuntimeError):
                with event.edit_vobject_instance() as vobj:
                    pass

    def testDataAPICheapAccessors(self):
        """Test the cheap internal accessors for issue #613.

        These accessors avoid unnecessary format conversions when we just
        need to peek at basic properties like UID or component type.
        """
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)

        # Test with event
        event = Event(client, data=ev1)
        assert event._get_uid_cheap() == "20010712T182145Z-123401@example.com"
        assert event._get_component_type_cheap() == "VEVENT"
        assert event._has_data() is True

        # Test with todo
        my_todo = Todo(client, data=todo)
        assert my_todo._get_uid_cheap() == "20070313T123432Z-456553@example.com"
        assert my_todo._get_component_type_cheap() == "VTODO"
        assert my_todo._has_data() is True

        # Test with journal
        my_journal = CalendarObjectResource(client, data=journal)
        assert my_journal._get_uid_cheap() == "19970901T130000Z-123405@example.com"
        assert my_journal._get_component_type_cheap() == "VJOURNAL"
        assert my_journal._has_data() is True

        # Test with no data
        empty_event = Event(client)
        assert empty_event._get_uid_cheap() is None
        assert empty_event._get_component_type_cheap() is None
        assert empty_event._has_data() is False

    def testDataAPIStateTransitions(self):
        """Test state transitions in the data API (issue #613).

        Verify that the internal state correctly transitions between
        RawDataState, IcalendarState, and VobjectState.
        """
        from caldav.datastate import (
            IcalendarState,
            RawDataState,
            VobjectState,
        )

        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        event = Event(client, data=ev1)

        # Initial state should be RawDataState (or lazy init)
        event._ensure_state()
        assert isinstance(event._state, RawDataState)

        # get_data() should NOT change state
        _ = event.get_data()
        assert isinstance(event._state, RawDataState)

        # get_icalendar_instance() should NOT change state (returns copy)
        _ = event.get_icalendar_instance()
        assert isinstance(event._state, RawDataState)

        # edit_icalendar_instance() SHOULD change state to IcalendarState
        with event.edit_icalendar_instance():
            pass
        assert isinstance(event._state, IcalendarState)

        # edit_vobject_instance() SHOULD change state to VobjectState
        with event.edit_vobject_instance():
            pass
        assert isinstance(event._state, VobjectState)

        # get_data() should still work from VobjectState
        data = event.get_data()
        assert "Bastille Day Party" in data

    def testDataAPINoDataState(self):
        """Test NoDataState behavior (issue #613).

        When an object has no data, the NoDataState should provide
        sensible defaults without raising errors.
        """
        from caldav.datastate import NoDataState

        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        event = Event(client)  # No data

        # Ensure state is NoDataState
        event._ensure_state()
        assert isinstance(event._state, NoDataState)

        # get_data() should return empty string
        assert event.get_data() == ""

        # get_icalendar_instance() should return empty Calendar
        ical = event.get_icalendar_instance()
        assert ical is not None
        assert len(list(ical.subcomponents)) == 0

        # Cheap accessors should return None
        assert event._get_uid_cheap() is None
        assert event._get_component_type_cheap() is None
        assert event._has_data() is False

    def test_set_data_updates_state_cache(self) -> None:
        """§2.9: _set_data (raw string branch) must reset _state so that
        get_data()/get_icalendar_instance()/id return the new content.

        Bug: _set_data cleared _data/_vobject_instance/_icalendar_instance
        but never updated self._state.  Once _state was cached by an earlier
        call to _ensure_state() (e.g. via event.id or is_loaded()), all
        subsequent reads through the new API served stale content.
        """
        from caldav.datastate import RawDataState

        client = DAVClient(url="http://cal.example.com/")
        ev2 = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:updated-uid@example.com
DTSTAMP:20260101T000000Z
DTSTART:20260601T100000Z
DTEND:20260601T110000Z
SUMMARY:Updated Event
END:VEVENT
END:VCALENDAR
"""
        event = Event(client, data=ev1)

        # Prime the state cache — simulates the common scenario where the
        # object is accessed before a reload (e.g. event.id or is_loaded())
        assert event.id == "20010712T182145Z-123401@example.com"
        assert isinstance(event._state, RawDataState)

        # Simulate what load() does: assign new raw data
        event.data = ev2

        # _state must now reflect the new data
        assert isinstance(event._state, RawDataState)
        assert event.get_data() == ev2, "get_data() returned stale pre-reload content"
        assert event.id == "updated-uid@example.com", "id returned stale UID after reload"
        assert "Updated Event" in event.get_data()

    def test_vfreebusy_component_type_detection(self) -> None:
        """§2.10: RawDataState.get_component_type() tested for 'BEGIN:FREEBUSY'
        but real iCalendar data uses 'BEGIN:VFREEBUSY', so FreeBusy objects
        got component_type=None → is_loaded()/has_component() False → save()
        silent no-op and load(only_if_unloaded=True) spuriously reloads.
        Also fixes get_uid()/get_component_type() in DataState base class
        which listed 'FREEBUSY' instead of 'VFREEBUSY' as comp.name.
        """
        from caldav.datastate import RawDataState

        freebusy_data = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//Test//EN
BEGIN:VFREEBUSY
UID:freebusy@example.com
DTSTAMP:20240101T120000Z
DTSTART:20240601T090000Z
DTEND:20240601T110000Z
FREEBUSY:20240601T090000Z/20240601T100000Z
END:VFREEBUSY
END:VCALENDAR
"""
        state = RawDataState(freebusy_data)
        assert state.get_component_type() == "VFREEBUSY", (
            "RawDataState.get_component_type() returned None for VFREEBUSY data "
            "(was checking for 'BEGIN:FREEBUSY' instead of 'BEGIN:VFREEBUSY')"
        )
        assert state.get_uid() == "freebusy@example.com"

        # Also verify via the base class parsers (IcalendarState path)
        import icalendar

        from caldav.datastate import IcalendarState

        ical = icalendar.Calendar.from_ical(freebusy_data)
        istate = IcalendarState(ical)
        assert istate.get_component_type() == "VFREEBUSY"
        assert istate.get_uid() == "freebusy@example.com"

    def testDataAPIEdgeCases(self):
        """Test edge cases in the data API (issue #613)."""
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)

        # Test with folded UID line (UID split across lines)
        folded_uid_data = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//Test//EN
BEGIN:VEVENT
UID:this-is-a-very-long-uid-that-might-be-folded-across-multiple-lines-in-r
 eal-world-icalendar-files@example.com
DTSTAMP:20060712T182145Z
DTSTART:20060714T170000Z
SUMMARY:Folded UID Test
END:VEVENT
END:VCALENDAR
"""
        event = Event(client, data=folded_uid_data)
        # The cheap accessor uses regex which might not handle folded lines
        # So we test that it falls back to full parsing when needed
        uid = event._get_uid_cheap()
        # Either the regex works or it falls back - either way we should get a UID
        assert uid is not None
        assert "this-is-a-very-long-uid" in uid

        # Test that nested borrowing (even same type) raises error
        # This prevents confusing ownership semantics
        event2 = Event(client, data=ev1)
        with event2.edit_icalendar_instance():
            with pytest.raises(RuntimeError):
                with event2.edit_icalendar_instance():
                    pass

        # Test sequential edits work fine
        event3 = Event(client, data=ev1)
        with event3.edit_icalendar_instance() as cal:
            for comp in cal.subcomponents:
                if comp.name == "VEVENT":
                    comp["SUMMARY"] = "First Edit"
        assert "First Edit" in event3.get_data()

        # Second edit after first is complete
        with event3.edit_icalendar_instance() as cal:
            for comp in cal.subcomponents:
                if comp.name == "VEVENT":
                    comp["SUMMARY"] = "Second Edit"
        assert "Second Edit" in event3.get_data()

    def testTodoDuration(self):
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        my_todo1 = Todo(client, data=todo)
        my_todo2 = Todo(client, data=todo_implicit_duration)
        my_todo3 = Todo(client, data=todo_explicit_duration)
        my_todo4 = Todo(client, data=todo_only_duration)
        orig_start = date(2007, 5, 1)
        ## TODO: Check the RFC.  For events a whole-day event without duration/dtend defaults to lasting for one day.  Probably the same with tasks?
        assert my_todo1.get_duration() == timedelta(0)
        assert my_todo1.get_due() == orig_start
        assert my_todo2.get_duration() == timedelta(days=6)
        assert my_todo2.get_due() == orig_start
        assert my_todo3.get_duration() == timedelta(days=5)
        ## This used to read `foo6 = ...strftime("%s") == "1177945200"`: an
        ## assertion assigned to a variable and never checked.  It could not have
        ## been asserted as written either - "%s" is a glibc extension that
        ## ignores tzinfo, so the comparison only holds in the author's own
        ## timezone (1177945200 is 2007-04-30T16:00+02:00; in UTC the same
        ## datetime gives 1177948800).  Asserted on the value instead.
        assert my_todo3.get_due() == datetime(2007, 4, 30, 16, 0, tzinfo=timezone.utc)
        some_date = date(2011, 1, 1)

        my_todo1.set_due(some_date)
        assert my_todo1.get_due() == some_date

        ## set_due has "only" one if, so two code paths, one where dtstart is actually moved and one where it isn't
        my_todo2.set_due(some_date, move_dtstart=True)
        assert my_todo2.icalendar_instance.subcomponents[0]["DTSTART"].dt == some_date - timedelta(
            days=6
        )

        ## set_duration at the other hand has 5 code paths ...
        ## 1) DTSTART set, DTSTART as the movable component
        my_todo1.set_duration(timedelta(1))
        assert my_todo1.get_due() == some_date
        assert my_todo1.icalendar_instance.subcomponents[0]["DTSTART"].dt == some_date - timedelta(
            1
        )

        ## 2) DUE and DTSTART set, DUE as the movable component
        my_todo1.set_duration(timedelta(2), movable_attr="DUE")
        assert my_todo1.get_due() == some_date + timedelta(days=1)
        assert my_todo1.icalendar_instance.subcomponents[0]["DTSTART"].dt == some_date - timedelta(
            1
        )

        ## 3) DUE set, DTSTART not set
        dtstart = my_todo1.icalendar_instance.subcomponents[0].pop("DTSTART").dt
        my_todo1.set_duration(timedelta(2))
        assert my_todo1.icalendar_instance.subcomponents[0]["DTSTART"].dt == dtstart

        ## 4) DTSTART set, DUE not set
        my_todo1.icalendar_instance.subcomponents[0].pop("DUE")
        my_todo1.set_duration(timedelta(1))
        assert my_todo1.get_due() == some_date

        ## 5) Neither DUE nor DTSTART set
        my_todo1.icalendar_instance.subcomponents[0].pop("DUE")
        my_todo1.icalendar_instance.subcomponents[0].pop("DTSTART")
        my_todo1.set_duration(timedelta(days=3))
        assert my_todo1.get_duration() == timedelta(days=3)

        ## 6) DUE and DTSTART set, DTSTART as the movable component (default)
        my_todo2 = Todo(client, data=todo_implicit_duration)
        orig_end = my_todo2.component.end
        my_todo2.set_duration(timedelta(2))
        assert my_todo2.component.start == orig_start - timedelta(2)
        assert my_todo2.component.end == orig_end

        ## 7) DURATION set, but neither DTSTART nor DTEND
        assert "DTSTART" not in my_todo4.component
        assert "DUE" not in my_todo4.component
        assert my_todo4.component["duration"].dt == timedelta(5)
        my_todo4.set_duration(timedelta(2))
        assert "DTSTART" not in my_todo4.component
        assert "DUE" not in my_todo4.component
        assert my_todo4.component["duration"].dt == timedelta(2)

    def testTodoDurationTimedDtstart(self):
        """§2.11: _get_duration must return timedelta(0) for a VTODO with a timed DTSTART
        and no DUE/DURATION — not timedelta(days=1).

        isinstance(i["DTSTART"], datetime) tested the vDDDTypes wrapper (always False),
        so the date-vs-datetime branch always took the 'is a date' path, returning 1 day.
        Fix: test isinstance(i["DTSTART"].dt, datetime) instead.
        """
        cal_url = "http://me:hunter2@calendar.example:80/"
        client = DAVClient(url=cal_url)
        todo_timed_dtstart = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//EN
BEGIN:VTODO
UID:timed-dtstart@example.com
DTSTAMP:20240101T000000Z
DTSTART:20240601T100000Z
SUMMARY:Todo with timed DTSTART only
END:VTODO
END:VCALENDAR"""
        todo_item = Todo(client, data=todo_timed_dtstart)
        assert todo_item.get_duration() == timedelta(0), (
            f"Expected timedelta(0) for timed DTSTART with no DUE, got {todo_item.get_duration()}"
        )

    def testURL(self):
        """Exercising the URL class"""
        long_url = "http://foo:bar@www.example.com:8080/caldav.php/?foo=bar"

        # 1) URL.objectify should return a valid URL object almost no matter
        # what's thrown in
        url0 = URL.objectify(None)
        url0b = URL.objectify("")
        url1 = URL.objectify(long_url)
        url2 = URL.objectify(url1)
        url3 = URL.objectify("/bar")
        url4 = URL.objectify(urlparse(str(url1)))
        url5 = URL.objectify(urlparse("/bar"))

        # 2) __eq__ works well
        assert url1 == url2
        assert url1 == url4
        assert url3 == url5

        # 3) str will always return the URL
        assert str(url1) == long_url
        assert str(url3) == "/bar"
        assert str(url4) == long_url
        assert str(url5) == "/bar"

        ## 3b) repr should also be exercised.  Returns URL(/bar) now.
        assert "/bar" in repr(url5)
        assert "URL" in repr(url5)
        assert len(repr(url5)) < 12

        # 4) join method
        url6 = url1.join(url2)
        url7 = url1.join(url3)
        url8 = url1.join(url4)
        url9 = url1.join(url5)
        urlA = url1.join("someuser/calendar")
        urlB = url5.join(url1)
        assert url6 == url1
        assert url7 == "http://foo:bar@www.example.com:8080/bar"
        assert url8 == url1
        assert url9 == url7
        assert urlA == "http://foo:bar@www.example.com:8080/caldav.php/someuser/calendar"
        assert urlB == url1
        with pytest.raises(ValueError):
            url1.join("http://www.google.com")

        # 4b) join method, with URL as input parameter
        url6 = url1.join(URL.objectify(url2))
        url7 = url1.join(URL.objectify(url3))
        url8 = url1.join(URL.objectify(url4))
        url9 = url1.join(URL.objectify(url5))
        urlA = url1.join(URL.objectify("someuser/calendar"))
        urlB = url5.join(URL.objectify(url1))
        url6b = url6.join(url0)
        url6c = url6.join(url0b)
        url6d = url6.join(None)
        for url6alt in (url6b, url6c, url6d):
            assert url6 == url6alt
        assert url6 == url1
        assert url7 == "http://foo:bar@www.example.com:8080/bar"
        assert url8 == url1
        assert url9 == url7
        assert urlA == "http://foo:bar@www.example.com:8080/caldav.php/someuser/calendar"
        assert urlB == url1
        with pytest.raises(ValueError):
            url1.join("http://www.google.com")

        # 5) all urlparse methods will work.  always.
        assert url1.scheme == "http"
        assert url2.path == "/caldav.php/"
        assert url7.username == "foo"
        assert url5.path == "/bar"
        urlC = URL.objectify("https://www.example.com:443/foo")
        assert urlC.port == 443

        # 6) is_auth returns True if the URL contains a username.
        assert not urlC.is_auth()
        assert url7.is_auth()

        # 7) unauth() strips username/password
        assert url7.unauth() == "http://www.example.com:8080/bar"

        # 8) strip_trailing_slash
        assert URL("http://www.example.com:8080/bar/").strip_trailing_slash() == URL(
            "http://www.example.com:8080/bar"
        )
        assert (
            URL("http://www.example.com:8080/bar/").strip_trailing_slash()
            == URL("http://www.example.com:8080/bar").strip_trailing_slash()
        )

        # 9) canonical
        assert (
            URL("https://www.example.com:443/b%61r/").canonical()
            == URL("//www.example.com/bar/").canonical()
        )

        # 9b) canonical() must strip credentials (§2.5a)
        cred_url = URL("https://user:pass@example.com/cal/")
        canon = cred_url.canonical()
        assert "user" not in str(canon), "canonical() leaked username"
        assert "pass" not in str(canon), "canonical() leaked password"

        # 9c) canonical() must not mutate self (§2.5b):
        #     a URL with no auth — unauth() returns self, canonical() must
        #     still return a fresh object and leave self unchanged.
        plain_url = URL("http://example.com/cal/path/")
        before = str(plain_url)
        _ = plain_url.canonical()
        assert str(plain_url) == before, "canonical() mutated self"

        # 9d) __eq__ calls canonical() — must not mutate self (§2.5b)
        #     A literal '+' in the path would become '%2B' after quote(unquote()),
        #     silently changing what resource subsequent requests target.
        plus_url = URL("http://example.com/cal/foo+bar/")
        before_plus = str(plus_url)
        _ = plus_url == URL("http://example.com/cal/foo+bar/")
        assert str(plus_url) == before_plus, "__eq__ mutated URL containing '+'"

        # 10) pickle
        assert pickle.loads(pickle.dumps(url1)) == url1

    def testFilters(self):
        filter = cdav.Filter().append(
            cdav.CompFilter("VCALENDAR").append(
                cdav.CompFilter("VEVENT").append(
                    cdav.PropFilter("UID").append([cdav.TextMatch("pouet", negate=True)])
                )
            )
        )
        filter_xml = str(filter)
        assert 'name="VCALENDAR"' in filter_xml
        assert 'name="VEVENT"' in filter_xml
        assert 'name="UID"' in filter_xml
        assert "pouet" in filter_xml

        crash = cdav.CompFilter()
        value = None
        try:
            value = str(crash)
        except:
            pass
        if value is not None:
            raise Exception("This should have crashed")

    def test_calendar_comp_class_by_data(self):
        calendar = Calendar()
        for ical, class_ in (
            (ev1, Event),
            (todo, Todo),
            (journal, Journal),
            (None, CalendarObjectResource),
            ("random rantings", CalendarObjectResource),
        ):  ## TODO: freebusy, time zone
            assert calendar._calendar_comp_class_by_data(ical) == class_
            if ical != "random rantings" and ical:
                assert (
                    calendar._calendar_comp_class_by_data(icalendar.Calendar.from_ical(ical))
                    == class_
                )

    def testContextManager(self):
        """
        ref https://github.com/python-caldav/caldav/pull/175
        """
        cal_url = "http://me:hunter2@calendar.example:80/"
        with DAVClient(url=cal_url) as client_ctx_mgr:
            assert isinstance(client_ctx_mgr, DAVClient)

    def testExtractAuth(self):
        """
        ref https://github.com/python-caldav/caldav/issues/289
        """
        cal_url = "http://me:hunter2@calendar.example:80/"
        with DAVClient(url=cal_url) as client:
            assert client.extract_auth_types("Basic\n") == {"basic"}
            assert client.extract_auth_types("Basic") == {"basic"}
            assert client.extract_auth_types('Basic Realm=foo;charset="UTF-8"') == {"basic"}
            assert client.extract_auth_types("Basic,dIGEST Realm=foo") == {
                "basic",
                "digest",
            }
            # §1.8: trailing comma (seen in the wild) must not raise IndexError
            assert client.extract_auth_types("Basic,") == {"basic"}
            assert client.extract_auth_types('Basic realm="x",') == {"basic"}

    def testAutoUrlEcloudWithEmailUsername(self) -> None:
        """
        Test that auto-connect URL construction works correctly for ecloud
        when username is an email address and no URL is provided.

        Bug: When username is "tobixen@e.email" and no URL is provided,
        the auto-connect logic should use the domain from the ecloud hints
        (ecloud.global) rather than treating the username as a URL.

        Expected URL: https://ecloud.global/remote.php/dav

        The bug occurs when RFC6764 discovery is enabled (default behavior):
        1. Line 133-135 sets url = username for discovery
        2. RFC6764 discovery fails for the invalid email-as-domain
        3. Fallback logic (line 166-167) doesn't replace url with domain from hints
           because url is no longer empty
        4. Result: https://tobixen@e.email/remote.php/dav (wrong!)
           Should be: https://ecloud.global/remote.php/dav
        """
        from caldav.compatibility_hints import ecloud
        from caldav.davclient import _auto_url

        # Test with email username and no URL - should use ecloud domain from hints
        # RFC6764 is enabled by default, which triggers the bug
        url, discovered_username = _auto_url(
            url=None,
            username="tobixen@e.email",
            features=ecloud,
            enable_rfc6764=True,  # Default behavior - this triggers the bug
        )

        assert url == "https://ecloud.global/remote.php/dav", (
            f"Expected 'https://ecloud.global/remote.php/dav', got '{url}'"
        )
        assert discovered_username is None

    def testSearcherMethod(self):
        """Test that calendar.searcher() returns a properly configured CalDAVSearcher.

        This tests issue #590 - the new API for creating search objects.
        """
        from caldav.search import CalDAVSearcher

        client = MockedDAVClient(recurring_task_response)
        calendar = Calendar(client, url="/calendar/issue491/")

        # Test basic searcher creation
        searcher = calendar.searcher(event=True)
        assert isinstance(searcher, CalDAVSearcher)
        assert searcher._calendar is calendar
        assert searcher.event is True

        # Test with multiple parameters
        searcher = calendar.searcher(
            todo=True,
            start=datetime(2025, 1, 1),
            end=datetime(2025, 12, 31),
            expand=True,
        )
        assert searcher.todo is True
        assert searcher.start == datetime(2025, 1, 1)
        assert searcher.end == datetime(2025, 12, 31)
        assert searcher.expand is True

        # Test with sort keys
        searcher = calendar.searcher(sort_keys=["due", "priority"], sort_reverse=True)
        assert len(searcher._sort_keys) == 2

        # Test with property filters
        searcher = calendar.searcher(summary="meeting", location="office")
        assert "summary" in searcher._property_filters
        assert "location" in searcher._property_filters

        # Test with no_* filters (undef operator goes to _property_operator, not _property_filters)
        searcher = calendar.searcher(no_summary=True)
        assert searcher._property_operator.get("summary") == "undef"

        # Test that search() works without calendar argument
        # Note: post_filter is a parameter to search(), not the searcher
        mytasks = calendar.searcher(todo=True, expand=False).search(post_filter=True)
        assert len(mytasks) == 1

    def testSearcherWithoutCalendar(self):
        """Test that CalDAVSearcher.search() raises ValueError without calendar."""
        from caldav.search import CalDAVSearcher

        searcher = CalDAVSearcher(event=True)
        with pytest.raises(ValueError, match="No calendar provided"):
            searcher.search()

    def testGetObjectByUidUsesSelfSearch(self):
        """
        get_object_by_uid() must call self.search() (Calendar.search) rather than
        constructing a CalDAVSearcher directly.  This ensures that any
        monkey-patching of Calendar.search - such as the search-cache delay for
        servers with lazy search indexes (purelymail) - is also applied when
        looking up objects by UID.

        See also testObjectByUID in the integration tests for the exact-match
        guarantee.
        """
        uid = "20010712T182145Z-123401@example.com"
        # Build a minimal multistatus response containing ev1
        xml_response = f"""<d:multistatus xmlns:d="DAV:" xmlns:cal="urn:ietf:params:xml:ns:caldav">
  <d:response>
    <d:href>/calendar/ev1.ics</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>{ev1}</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>"""
        client = MockedDAVClient(xml_response)
        calendar = Calendar(client, url="/calendar/")

        # Patch Calendar.search to track calls, while still delegating to
        # the original implementation.
        search_calls = []
        original_search = Calendar.search

        def tracking_search(self_, *args, **kwargs):
            search_calls.append((args, kwargs))
            return original_search(self_, *args, **kwargs)

        Calendar.search = tracking_search
        try:
            result = calendar.get_object_by_uid(uid, comp_class=Event)
            assert result.id == uid
            assert search_calls, "Calendar.search was not called by get_object_by_uid"
        finally:
            Calendar.search = original_search

    def testGetObjectByUidExactMatch(self):
        """
        get_object_by_uid() must return only an object with the exact requested UID,
        even if the server (doing a substring search) returns objects with UIDs
        that merely contain the requested UID as a substring.
        """
        uid_exact = "20010712T182145Z-123401@example.com"
        uid_superstring = "20010712T182145Z-123401@example.com-extra"
        ev_superstring = f"""BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VEVENT
UID:{uid_superstring}
DTSTAMP:20060712T182145Z
DTSTART:20060714T170000Z
DTEND:20060715T040000Z
SUMMARY:Bastille Day Party extra
END:VEVENT
END:VCALENDAR
"""
        # Server returns both the exact-match event AND a superstring-UID event
        # (simulating a server that does substring matching)
        xml_response = f"""<d:multistatus xmlns:d="DAV:" xmlns:cal="urn:ietf:params:xml:ns:caldav">
  <d:response>
    <d:href>/calendar/ev1.ics</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>{ev1}</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
  <d:response>
    <d:href>/calendar/ev_superstring.ics</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>{ev_superstring}</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>"""
        client = MockedDAVClient(xml_response)
        calendar = Calendar(client, url="/calendar/")

        # Only the exact-UID match should be returned
        result = calendar.get_object_by_uid(uid_exact)
        assert result.id == uid_exact

        # Searching for a UID that exists only as a substring of another should fail
        with pytest.raises(error.NotFoundError):
            calendar.get_object_by_uid("20010712T182145Z-123401@example.com-nope")


class TestAsyncGetObjectByUid:
    """Tests for async support in get_object_by_uid and friends (issue #642)."""

    def _make_multistatus(self, ical_data, href="/calendar/ev1.ics"):
        return f"""<d:multistatus xmlns:d="DAV:" xmlns:cal="urn:ietf:params:xml:ns:caldav">
  <d:response>
    <d:href>{href}</d:href>
    <d:propstat>
      <d:prop>
        <cal:calendar-data>{ical_data}</cal:calendar-data>
      </d:prop>
      <d:status>HTTP/1.1 200 OK</d:status>
    </d:propstat>
  </d:response>
</d:multistatus>"""

    def test_get_object_by_uid_returns_coroutine_for_async_client(self):
        """get_object_by_uid() must return a coroutine (not a result) when the
        client is an AsyncDAVClient, so that the caller can await it."""
        import asyncio

        from caldav.async_davclient import AsyncDAVClient

        xml_response = self._make_multistatus(ev1)
        client = MockedDAVClient(xml_response)
        client.__class__ = type("MockedAsyncDAVClient", (MockedDAVClient, AsyncDAVClient), {})
        calendar = Calendar(client, url="/calendar/")
        assert calendar.is_async_client
        uid = "20010712T182145Z-123401@example.com"
        result = calendar.get_object_by_uid(uid)
        # Must be a coroutine, not an Event/CalendarObjectResource
        assert asyncio.iscoroutine(result), (
            f"expected coroutine from async client, got {type(result)}"
        )
        result.close()  # clean up to avoid ResourceWarning

    def test_get_object_by_uid_async_returns_correct_object(self):
        """Awaiting the coroutine from get_object_by_uid() returns the right object."""
        import asyncio

        from caldav.async_davclient import AsyncDAVClient

        client = MockedDAVClient("")
        client.__class__ = type("MockedAsyncDAVClient", (MockedDAVClient, AsyncDAVClient), {})
        calendar = Calendar(client, url="/calendar/")
        uid = "20010712T182145Z-123401@example.com"

        # Build a real Event object that the mocked search will return
        fake_event = Event(client=client, url="/calendar/ev1.ics", data=ev1, parent=calendar)

        # Mock calendar.search as an async function returning our fake event
        async def fake_search(**kwargs):
            return [fake_event]

        calendar.search = fake_search

        obj = asyncio.run(calendar.get_object_by_uid(uid))
        assert obj.id == uid


class TestOrphanedRecurrenceSave:
    """Unit tests for save() behavior with orphaned recurrences (RECURRENCE-ID without master).

    Regression tests for commit 7269f179 (graceful adding of orphaned recurrences).
    """

    _orphan_ical = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example//EN
BEGIN:VEVENT
UID:orphan-test-uid@example.com
DTSTAMP:20200101T000000Z
DTSTART:20200115T100000Z
DTEND:20200115T110000Z
RECURRENCE-ID:20200115T100000Z
SUMMARY:Orphaned recurrence (no master)
END:VEVENT
END:VCALENDAR"""

    def _make_orphan_event(self):
        """Return (event, mock_calendar) with RECURRENCE-ID set and master not found."""
        client = MockedDAVClient("")
        mock_calendar = mock.MagicMock()
        mock_calendar.is_async_client = False
        mock_calendar.url = URL("https://example.com/calendar/")
        mock_calendar.get_event_by_uid.side_effect = error.NotFoundError("master not found")
        event = Event(
            client=client,
            url="/calendar/orphan.ics",
            data=self._orphan_ical,
            parent=mock_calendar,
        )
        return event, mock_calendar

    def test_save_default_raises_when_master_missing(self):
        """save() with the default only_this_recurrence=True raises NotFoundError when master absent."""
        event, _ = self._make_orphan_event()
        with pytest.raises(error.NotFoundError):
            event.save()

    def test_save_none_falls_through_to_put_when_master_missing(self):
        """save(only_this_recurrence=None) calls _create() rather than raising when master absent."""
        event, _ = self._make_orphan_event()
        created = []
        event._create = lambda id=None, path=None, retry_on_failure=True: created.append(True)
        event.save(only_this_recurrence=None)
        assert created, "_create() must be called (PUT as-is) when master not found"

    def test_save_false_bypasses_master_lookup(self):
        """save(only_this_recurrence=False) skips the master lookup entirely and PUTs directly."""
        event, mock_calendar = self._make_orphan_event()
        created = []
        event._create = lambda id=None, path=None, retry_on_failure=True: created.append(True)
        event.save(only_this_recurrence=False)
        mock_calendar.get_event_by_uid.assert_not_called()
        assert created, "_create() must be called when only_this_recurrence=False"

    def test_add_object_orphan_does_not_raise_notfound(self):
        """Calendar.add_object() passes only_this_recurrence=None, so orphaned recurrences succeed."""
        client = MockedDAVClient("")
        calendar = Calendar(client, url="/calendar/")
        calendar.get_event_by_uid = mock.MagicMock(side_effect=error.NotFoundError("no master"))

        created = []
        original_create = CalendarObjectResource._create
        CalendarObjectResource._create = lambda self_, id=None, path=None, retry_on_failure=True: (
            created.append(True)
        )
        try:
            calendar.add_object(Event, self._orphan_ical)
        finally:
            CalendarObjectResource._create = original_create

        assert created, (
            "add_object() with orphaned recurrence must PUT without raising NotFoundError"
        )


class TestAsyncCalendarObjectResource:
    """Tests that CalendarObjectResource methods return coroutines (not None) for async clients.

    These guard against the pattern where a sync method calls self.save() or
    self.parent.some_method() without awaiting, silently discarding the coroutine.
    """

    completed_todo = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:20070313T123432Z-456553@example.com
DTSTAMP:20070313T123432Z
DUE;VALUE=DATE:20070501
SUMMARY:Submit Quebec Income Tax Return for 2006
STATUS:COMPLETED
COMPLETED:20070501T000000Z
END:VTODO
END:VCALENDAR"""

    todo_with_relation = """BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Client//EN
BEGIN:VTODO
UID:20070313T123432Z-456553@example.com
DTSTAMP:20070313T123432Z
DUE;VALUE=DATE:20070501
SUMMARY:Submit Quebec Income Tax Return for 2006
RELATED-TO;RELTYPE=PARENT:parent-uid-001
STATUS:NEEDS-ACTION
END:VTODO
END:VCALENDAR"""

    def _make_async_client_and_calendar(self):
        from caldav.async_davclient import AsyncDAVClient

        client = MockedDAVClient("")
        client.__class__ = type("MockedAsyncDAVClient", (MockedDAVClient, AsyncDAVClient), {})
        calendar = Calendar(client, url="/calendar/")
        return client, calendar

    def test_uncomplete_returns_coroutine_for_async_client(self):
        """uncomplete() must return a coroutine for async clients, not silently discard save()."""
        import asyncio

        client, calendar = self._make_async_client_and_calendar()
        todo = Todo(
            client=client,
            url="/calendar/todo1.ics",
            data=self.completed_todo,
            parent=calendar,
        )
        result = todo.uncomplete()
        assert asyncio.iscoroutine(result), (
            f"expected coroutine from uncomplete(), got {type(result)}"
        )
        result.close()

    def test_uncomplete_async_saves_and_clears_status(self):
        """Awaiting uncomplete() must actually save the object and clear STATUS/COMPLETED."""
        import asyncio

        client, calendar = self._make_async_client_and_calendar()
        todo = Todo(
            client=client,
            url="/calendar/todo1.ics",
            data=self.completed_todo,
            parent=calendar,
        )

        saved = False

        async def fake_async_put(*args, **kwargs):
            nonlocal saved
            saved = True

        todo._async_put = fake_async_put
        asyncio.run(todo.uncomplete())

        assert saved, "uncomplete() did not call _async_put for async client"
        assert todo.icalendar_component.get("STATUS") == "NEEDS-ACTION"
        assert "COMPLETED" not in todo.icalendar_component

    def test_get_relatives_returns_coroutine_for_async_client(self):
        """get_relatives(fetch_objects=True) must return a coroutine for async clients."""
        import asyncio

        client, calendar = self._make_async_client_and_calendar()
        todo = Todo(
            client=client,
            url="/calendar/todo1.ics",
            data=self.todo_with_relation,
            parent=calendar,
        )
        result = todo.get_relatives()
        assert asyncio.iscoroutine(result), (
            f"expected coroutine from get_relatives(), got {type(result)}"
        )
        result.close()

    def test_get_relatives_async_returns_objects(self):
        """Awaiting get_relatives() must return fetched objects, not coroutines."""
        import asyncio

        client, calendar = self._make_async_client_and_calendar()
        todo = Todo(
            client=client,
            url="/calendar/todo1.ics",
            data=self.todo_with_relation,
            parent=calendar,
        )

        parent_todo = Todo(client=client, url="/calendar/parent.ics", data=ev1, parent=calendar)

        async def fake_get_object_by_uid(uid):
            return parent_todo

        calendar.get_object_by_uid = fake_get_object_by_uid

        result = asyncio.run(todo.get_relatives())
        assert "PARENT" in result
        parent_set = result["PARENT"]
        assert len(parent_set) == 1
        obj = next(iter(parent_set))
        assert obj is parent_todo, f"expected the parent todo object, got {obj!r}"

    def test_set_relation_returns_coroutine_for_async_client(self):
        """set_relation() must return a coroutine for async clients, not silently drop save()."""
        import asyncio

        client, calendar = self._make_async_client_and_calendar()
        todo = Todo(
            client=client,
            url="/calendar/todo1.ics",
            data=self.completed_todo,
            parent=calendar,
        )
        other_todo = Todo(
            client=client,
            url="/calendar/todo2.ics",
            data=self.completed_todo,
            parent=calendar,
        )
        # Patch id so set_relation can extract a UID without a full ical parse
        other_todo._id = "some-other-uid"

        result = todo.set_relation(other_todo, reltype="PARENT", set_reverse=False)
        assert asyncio.iscoroutine(result), (
            f"expected coroutine from set_relation(), got {type(result)}"
        )
        result.close()

    def test_accept_invite_returns_coroutine_for_async_client(self):
        """accept_invite() must return a coroutine for async clients."""
        import asyncio

        client, calendar = self._make_async_client_and_calendar()
        event = Event(client=client, url="/calendar/ev1.ics", data=ev1, parent=calendar)
        result = event.accept_invite()
        assert asyncio.iscoroutine(result), (
            f"expected coroutine from accept_invite(), got {type(result)}"
        )
        result.close()

    def test_add_organizer_explicit_arg_is_sync_safe_for_async_client(self):
        """add_organizer(explicit_arg) is pure in-memory: no network call, no await needed.
        It must work correctly even when the client is an async client."""
        from icalendar import vCalAddress

        client, calendar = self._make_async_client_and_calendar()
        event = Event(client=client, url="/calendar/ev1.ics", data=ev1, parent=calendar)
        event.add_organizer("organizer@example.com")
        organizer = event.icalendar_component.get("organizer")
        assert "organizer@example.com" in str(organizer)

    def test_add_organizer_no_arg_returns_coroutine_for_async_client(self):
        """add_organizer() without args must return a coroutine for async clients.

        Bug: today the code calls self.client.principal().get_vcal_address() without
        checking is_async_client first.  On an AsyncDAVClient, principal() is a
        coroutine function, so principal() returns a coroutine object.  Calling
        .get_vcal_address() on that coroutine raises AttributeError instead of
        returning a usable coroutine to the caller.
        """
        import asyncio

        from icalendar import vCalAddress

        client, calendar = self._make_async_client_and_calendar()
        event = Event(client=client, url="/calendar/ev1.ics", data=ev1, parent=calendar)

        async def async_principal():
            p = mock.MagicMock()
            p.get_vcal_address = mock.AsyncMock(return_value=vCalAddress("mailto:me@example.com"))
            return p

        client.principal = async_principal

        result = event.add_organizer()
        assert asyncio.iscoroutine(result), (
            f"expected a coroutine from add_organizer() on async client, got {type(result)}"
        )
        result.close()

    def test_add_organizer_no_arg_async_awaited_sets_organizer(self):
        """Awaiting add_organizer() without args on async client must set ORGANIZER correctly."""
        import asyncio

        from icalendar import vCalAddress

        client, calendar = self._make_async_client_and_calendar()
        event = Event(client=client, url="/calendar/ev1.ics", data=ev1, parent=calendar)

        async def async_principal():
            p = mock.MagicMock()
            p.get_vcal_address = mock.AsyncMock(return_value=vCalAddress("mailto:me@example.com"))
            return p

        client.principal = async_principal

        asyncio.run(event.add_organizer())
        organizer = event.icalendar_component.get("organizer")
        assert str(organizer) == "mailto:me@example.com"

    def test_save_with_invites_returns_coroutine_for_async_client(self):
        """save_with_invites() must return a coroutine for async clients (not silently drop save/organizer)."""
        import asyncio

        from icalendar import vCalAddress

        client, calendar = self._make_async_client_and_calendar()

        async def async_principal():
            p = mock.MagicMock()
            p.get_vcal_address = mock.AsyncMock(return_value=vCalAddress("mailto:me@example.com"))
            return p

        client.principal = async_principal

        result = calendar.save_with_invites(ev1, [])
        assert asyncio.iscoroutine(result), (
            f"expected coroutine from save_with_invites() on async client, got {type(result)}"
        )
        result.close()

    def test_save_with_invites_async_awaited_sets_organizer_and_saves(self):
        """Awaiting save_with_invites() on async client must set ORGANIZER and call put."""
        import asyncio

        from icalendar import vCalAddress

        client, calendar = self._make_async_client_and_calendar()

        async def async_principal():
            p = mock.MagicMock()
            p.get_vcal_address = mock.AsyncMock(return_value=vCalAddress("mailto:me@example.com"))
            return p

        client.principal = async_principal
        saved = False

        async def fake_async_put(*args, **kwargs):
            nonlocal saved
            saved = True
            r = mock.MagicMock()
            r.status = 201
            r.headers = []
            return r

        client.put = fake_async_put

        obj = asyncio.run(calendar.save_with_invites(ev1, []))
        assert saved, "save_with_invites() did not call put for async client"
        org = obj.icalendar_component.get("organizer")
        assert org is not None, "ORGANIZER must be set after awaiting save_with_invites()"
        assert "me@example.com" in str(org)

    def test_principal_freebusy_request_returns_coroutine_for_async_client(self):
        """Principal.freebusy_request() must return a coroutine for async clients."""
        import asyncio
        from datetime import datetime

        client, calendar = self._make_async_client_and_calendar()
        principal = Principal(client=client, url="/principals/me/")

        result = principal.freebusy_request(
            datetime(2024, 1, 1, 10, 0, 0),
            datetime(2024, 1, 1, 12, 0, 0),
            [],
        )
        assert asyncio.iscoroutine(result), (
            f"expected coroutine from Principal.freebusy_request() on async client, got {type(result)}"
        )
        result.close()


class TestFreeBusyScheduleResponse:
    """Unit tests for parsing RFC6638 schedule-response to a freebusy request.

    The XML fixture is taken directly from RFC 6638 Appendix B.5.
    Three attendees are requested; two succeed (with VFREEBUSY calendar-data),
    one fails with "3.7;Invalid calendar user".
    """

    # RFC 6638 §B.5 server response (slightly compacted for readability)
    RFC6638_B5_XML = b"""\
<?xml version="1.0" encoding="utf-8" ?>
<C:schedule-response xmlns:D="DAV:"
       xmlns:C="urn:ietf:params:xml:ns:caldav">
<C:response>
<C:recipient>
<D:href>mailto:wilfredo@example.com</D:href>
</C:recipient>
<C:request-status>2.0;Success</C:request-status>
<C:calendar-data>BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Server//EN
METHOD:REPLY
BEGIN:VFREEBUSY
UID:4FD3AD926350
DTSTAMP:20090602T200733Z
DTSTART:20090602T000000Z
DTEND:20090604T000000Z
ORGANIZER;CN="Cyrus Daboo":mailto:cyrus@example.com
ATTENDEE;CN="Wilfredo Sanchez Vega":mailto:wilfredo@example.com
FREEBUSY;FBTYPE=BUSY:20090602T110000Z/20090602T120000Z
FREEBUSY;FBTYPE=BUSY:20090603T170000Z/20090603T180000Z
END:VFREEBUSY
END:VCALENDAR
</C:calendar-data>
</C:response>
<C:response>
<C:recipient>
<D:href>mailto:bernard@example.net</D:href>
</C:recipient>
<C:request-status>2.0;Success</C:request-status>
<C:calendar-data>BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Example Corp.//CalDAV Server//EN
METHOD:REPLY
BEGIN:VFREEBUSY
UID:4FD3AD926350
DTSTAMP:20090602T200733Z
DTSTART:20090602T000000Z
DTEND:20090604T000000Z
ORGANIZER;CN="Cyrus Daboo":mailto:cyrus@example.com
ATTENDEE;CN="Bernard Desruisseaux":mailto:bernard@example.net
FREEBUSY;FBTYPE=BUSY:20090602T150000Z/20090602T160000Z
FREEBUSY;FBTYPE=BUSY:20090603T090000Z/20090603T100000Z
FREEBUSY;FBTYPE=BUSY:20090603T180000Z/20090603T190000Z
END:VFREEBUSY
END:VCALENDAR
</C:calendar-data>
</C:response>
<C:response>
<C:recipient>
<D:href>mailto:mike@example.org</D:href>
</C:recipient>
<C:request-status>3.7;Invalid calendar user</C:request-status>
</C:response>
</C:schedule-response>"""

    def _make_schedule_response(self):
        """Return a DAVResponse wrapping the RFC 6638 §B.5 XML."""
        from caldav.davclient import DAVResponse

        resp = mock.MagicMock()
        resp.status_code = 200
        resp.reason = "OK"
        resp.headers = {"Content-Type": "application/xml; charset=utf-8"}
        resp.content = self.RFC6638_B5_XML
        return DAVResponse(resp)

    def test_schedule_response_returns_three_recipients(self):
        """Parsing the B.5 response must yield one entry per recipient."""
        response = self._make_schedule_response()
        result = response._parse_scheduling_response_objects(parent=mock.MagicMock())
        assert len(result) == 3

    def test_schedule_response_successful_recipients_have_calendar_data(self):
        """Recipients with 2.0;Success must have calendar-data containing VFREEBUSY."""
        response = self._make_schedule_response()
        result = response._parse_scheduling_response_objects(parent=mock.MagicMock())
        wilfredo = result["mailto:wilfredo@example.com"]
        bernard = result["mailto:bernard@example.net"]
        assert "VFREEBUSY" in wilfredo.data
        assert "VFREEBUSY" in bernard.data
        # Wilfredo has 2 busy slots; Bernard has 3
        assert wilfredo.data.count("\nFREEBUSY") == 2
        assert bernard.data.count("\nFREEBUSY") == 3

    def test_schedule_response_failed_recipient_has_no_calendar_data(self):
        """Recipients with a non-2.x status must have no calendar data"""
        response = self._make_schedule_response()
        result = response._parse_scheduling_response_objects(parent=mock.MagicMock())
        assert result["errors"]["mailto:mike@example.org"] == "3.7;Invalid calendar user"
        assert not result.get("mailto:mike@example.org")


class TestRateLimitHelpers:
    """Unit tests for the shared rate-limit helper functions in caldav.lib.error."""

    def test_parse_retry_after_integer(self):
        assert error.parse_retry_after("30") == 30.0

    def test_parse_retry_after_zero(self):
        assert error.parse_retry_after("0") == 0.0

    def test_parse_retry_after_http_date(self):
        from email.utils import format_datetime

        future = datetime.now(timezone.utc) + timedelta(seconds=60)
        result = error.parse_retry_after(format_datetime(future))
        assert result is not None
        assert 55 <= result <= 65

    def test_parse_retry_after_unparseable(self):
        assert error.parse_retry_after("banana") is None

    def test_parse_retry_after_empty(self):
        assert error.parse_retry_after("") is None

    def test_compute_sleep_server_value_used(self):
        assert error.compute_sleep_seconds(30.0, None, None) == 30.0

    def test_compute_sleep_default_fallback(self):
        assert error.compute_sleep_seconds(None, 5, None) == 5.0

    def test_compute_sleep_server_overrides_default(self):
        # Server-provided value takes priority over default
        assert error.compute_sleep_seconds(10.0, 5, None) == 10.0

    def test_compute_sleep_max_cap_applied(self):
        assert error.compute_sleep_seconds(3600.0, None, 60) == 60.0

    def test_compute_sleep_max_zero_returns_none(self):
        assert error.compute_sleep_seconds(30.0, None, 0) is None

    def test_compute_sleep_no_info_returns_none(self):
        assert error.compute_sleep_seconds(None, None, None) is None

    def test_compute_sleep_zero_seconds_returns_none(self):
        assert error.compute_sleep_seconds(0.0, None, None) is None

    def test_raise_if_rate_limited_429_no_header(self):
        with pytest.raises(error.RateLimitError) as exc_info:
            error.raise_if_rate_limited(429, "http://x/", None)
        assert exc_info.value.retry_after is None
        assert exc_info.value.retry_after_seconds is None

    def test_raise_if_rate_limited_429_with_header(self):
        with pytest.raises(error.RateLimitError) as exc_info:
            error.raise_if_rate_limited(429, "http://x/", "30")
        assert exc_info.value.retry_after == "30"
        assert exc_info.value.retry_after_seconds == 30.0

    def test_raise_if_rate_limited_503_with_header(self):
        with pytest.raises(error.RateLimitError):
            error.raise_if_rate_limited(503, "http://x/", "10")

    def test_raise_if_rate_limited_503_no_header_does_not_raise(self):
        # 503 without Retry-After should pass silently
        error.raise_if_rate_limited(503, "http://x/", None)

    def test_raise_if_rate_limited_200_does_not_raise(self):
        error.raise_if_rate_limited(200, "http://x/", None)


class TestRateLimiting:
    """
    Unit tests for 429/503 rate-limit handling (issue #627).
    No real server communication - uses mock.patch on the session.
    """

    def _make_response(self, status_code, headers=None):
        """Build a minimal mock HTTP response."""
        r = mock.MagicMock()
        r.status_code = status_code
        r.headers = headers or {}
        r.reason = "Too Many Requests" if status_code == 429 else "Service Unavailable"
        return r

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_429_no_retry_after_raises(self, mocked):
        """429 without Retry-After header always raises RateLimitError with retry_after_seconds=None."""
        mocked.return_value = self._make_response(429)
        client = DAVClient(url="http://cal.example.com/")
        with pytest.raises(error.RateLimitError) as exc_info:
            client.request("/")
        assert exc_info.value.retry_after is None
        assert exc_info.value.retry_after_seconds is None

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_429_with_integer_retry_after(self, mocked):
        """429 with integer Retry-After header parses the seconds correctly."""
        mocked.return_value = self._make_response(429, {"Retry-After": "30"})
        client = DAVClient(url="http://cal.example.com/")
        with pytest.raises(error.RateLimitError) as exc_info:
            client.request("/")
        assert exc_info.value.retry_after == "30"
        assert exc_info.value.retry_after_seconds == 30

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_429_with_http_date_retry_after(self, mocked):
        """429 with HTTP-date Retry-After header computes seconds from now."""
        from email.utils import format_datetime

        future = datetime.now(timezone.utc) + timedelta(seconds=60)
        retry_after_str = format_datetime(future)
        mocked.return_value = self._make_response(429, {"Retry-After": retry_after_str})
        client = DAVClient(url="http://cal.example.com/")
        with pytest.raises(error.RateLimitError) as exc_info:
            client.request("/")
        assert exc_info.value.retry_after == retry_after_str
        # Should be close to 60s (allow a few seconds tolerance)
        assert exc_info.value.retry_after_seconds is not None
        assert 55 <= exc_info.value.retry_after_seconds <= 65

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_429_with_unparseable_retry_after(self, mocked):
        """429 with a garbled Retry-After header still raises; retry_after_seconds is None."""
        mocked.return_value = self._make_response(429, {"Retry-After": "banana"})
        client = DAVClient(url="http://cal.example.com/")
        with pytest.raises(error.RateLimitError) as exc_info:
            client.request("/")
        assert exc_info.value.retry_after == "banana"
        assert exc_info.value.retry_after_seconds is None

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_503_without_retry_after_does_not_raise_rate_limit(self, mocked):
        """503 without Retry-After falls through as a normal (non-rate-limit) response."""
        mocked.return_value = self._make_response(503)
        client = DAVClient(url="http://cal.example.com/")
        # Should NOT raise RateLimitError; returns a DAVResponse with status 503
        response = client.request("/")
        assert response.status == 503

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_503_with_retry_after_raises(self, mocked):
        """503 with Retry-After header raises RateLimitError."""
        mocked.return_value = self._make_response(503, {"Retry-After": "10"})
        client = DAVClient(url="http://cal.example.com/")
        with pytest.raises(error.RateLimitError) as exc_info:
            client.request("/")
        assert exc_info.value.retry_after_seconds == 10

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_rate_limit_handle_sleeps_and_retries(self, mocked):
        """With rate_limit_handle=True the client sleeps then retries, returning the second response."""
        ok_response = mock.MagicMock()
        ok_response.status_code = 200
        ok_response.headers = {}
        mocked.side_effect = [
            self._make_response(429, {"Retry-After": "5"}),
            ok_response,
        ]
        client = DAVClient(url="http://cal.example.com/", rate_limit_handle=True)
        with mock.patch("caldav.davclient.time.sleep") as mock_sleep:
            response = client.request("/")
        mock_sleep.assert_called_once_with(5)
        assert response.status == 200
        assert mocked.call_count == 2

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_rate_limit_handle_default_sleep_used_when_no_retry_after(self, mocked):
        """With rate_limit_default_sleep set, that value is used when server omits Retry-After."""
        ok_response = mock.MagicMock()
        ok_response.status_code = 200
        ok_response.headers = {}
        mocked.side_effect = [
            self._make_response(429),
            ok_response,
        ]
        client = DAVClient(
            url="http://cal.example.com/", rate_limit_handle=True, rate_limit_default_sleep=3
        )
        with mock.patch("caldav.davclient.time.sleep") as mock_sleep:
            response = client.request("/")
        mock_sleep.assert_called_once_with(3)
        assert response.status == 200

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_rate_limit_handle_no_sleep_info_raises(self, mocked):
        """rate_limit_handle=True but no Retry-After and no default sleep re-raises RateLimitError."""
        mocked.return_value = self._make_response(429)
        client = DAVClient(url="http://cal.example.com/", rate_limit_handle=True)
        with pytest.raises(error.RateLimitError):
            client.request("/")

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_rate_limit_max_sleep_caps_sleep_time(self, mocked):
        """rate_limit_max_sleep caps the sleep even when server requests longer."""
        ok_response = mock.MagicMock()
        ok_response.status_code = 200
        ok_response.headers = {}
        mocked.side_effect = [
            self._make_response(429, {"Retry-After": "3600"}),
            ok_response,
        ]
        client = DAVClient(
            url="http://cal.example.com/", rate_limit_handle=True, rate_limit_max_sleep=60
        )
        with mock.patch("caldav.davclient.time.sleep") as mock_sleep:
            client.request("/")
        mock_sleep.assert_called_once_with(60)

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_rate_limit_max_sleep_zero_raises(self, mocked):
        """rate_limit_max_sleep=0 means never sleep, always raise."""
        mocked.return_value = self._make_response(429, {"Retry-After": "30"})
        client = DAVClient(
            url="http://cal.example.com/", rate_limit_handle=True, rate_limit_max_sleep=0
        )
        with pytest.raises(error.RateLimitError):
            client.request("/")

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_rate_limit_adaptive_sleep_increases_on_repeated_retries(self, mocked):
        """On repeated 429s the sleep grows: first sleep uses Retry-After, second adds half of already-slept."""
        ok_response = mock.MagicMock()
        ok_response.status_code = 200
        ok_response.headers = {}
        mocked.side_effect = [
            self._make_response(429, {"Retry-After": "4"}),
            self._make_response(429, {"Retry-After": "4"}),
            ok_response,
        ]
        client = DAVClient(url="http://cal.example.com/", rate_limit_handle=True)
        with mock.patch("caldav.davclient.time.sleep") as mock_sleep:
            response = client.request("/")
        assert mock_sleep.call_count == 2
        assert mock_sleep.call_args_list[0] == mock.call(4.0)
        assert mock_sleep.call_args_list[1] == mock.call(6.0)  # 4 + 4/2
        assert response.status == 200
        assert mocked.call_count == 3

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_rate_limit_max_sleep_stops_adaptive_retries(self, mocked):
        """When accumulated sleep exceeds rate_limit_max_sleep, retrying stops."""
        mocked.return_value = self._make_response(429, {"Retry-After": "4"})
        client = DAVClient(
            url="http://cal.example.com/", rate_limit_handle=True, rate_limit_max_sleep=5
        )
        with mock.patch("caldav.davclient.time.sleep"):
            with pytest.raises(error.RateLimitError):
                client.request("/")


class TestAsyncProbeResponseNotReturnedAsReal:
    """§2.15: async _async_request: when the probe GET for issue-#158 workaround does
    not receive a 401+WWW-Authenticate response, the original exception must be re-raised.

    Before the fix, a probe response with status != 401 (e.g. 200 HTML login page) fell
    through to response = DAVResponse(r, self), returning the probe GET response as if
    it were the real request's response — status 200 for a PUT that never happened.
    """

    @pytest.mark.asyncio
    async def test_probe_200_reraises_original_exception(self):
        """If the probe GET returns 200 (not a 401 challenge), the original error must propagate."""
        from unittest.mock import AsyncMock, patch

        from caldav.async_davclient import AsyncDAVClient

        client = AsyncDAVClient(url="http://cal.example.com/", password="secret")

        probe_resp = mock.MagicMock()
        probe_resp.status_code = 200
        probe_resp.reason = "OK"
        probe_resp.headers = {"Content-Type": "text/html"}
        probe_resp.reason_phrase = "OK"

        original_error = ConnectionError("server aborted connection")

        async def mock_request(*args, **kwargs):
            if kwargs.get("method") == "GET" and not kwargs.get("auth"):
                return probe_resp
            raise original_error

        with patch.object(client.session, "request", side_effect=mock_request):
            with pytest.raises((ConnectionError, Exception)):
                await client._async_request("/some/resource", "PUT", "data", {})


class TestRateLimitNoPlusNone:
    """§1.3: rate-limit retry must not raise TypeError when second 429 has no usable Retry-After.

    sleep_seconds += rate_limit_time_slept / 2 executed before the is-None check,
    so None += 2.5 raised TypeError instead of the documented RateLimitError.
    """

    def _make_response(self, status_code, headers=None):
        r = mock.MagicMock()
        r.status_code = status_code
        r.headers = headers or {}
        r.reason = "Too Many Requests"
        return r

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_second_429_without_retry_after_raises_rate_limit_error(self, mocked):
        """Second 429 with Retry-After: 0 (compute_sleep_seconds → None) must raise
        RateLimitError, not TypeError."""
        ok = mock.MagicMock()
        ok.status_code = 200
        ok.headers = {}
        mocked.side_effect = [
            self._make_response(429, {"Retry-After": "5"}),
            self._make_response(429, {"Retry-After": "0"}),  # compute_sleep_seconds → None
        ]
        client = DAVClient(
            url="http://cal.example.com/",
            rate_limit_handle=True,
            rate_limit_default_sleep=None,
        )
        with mock.patch("caldav.davclient.time.sleep"):
            with pytest.raises(error.RateLimitError):
                client.request("/")


class TestDateToUtcConversion:
    """
    RFC 4791 §9.9: time-range start/end MUST be UTC datetime values.
    Plain date objects must be coerced to midnight UTC before use in
    REPORT XML and before being stored on the searcher (for client-side
    filtering).
    """

    def test_to_utc_date_string_with_date_gives_midnight_utc(self):
        """_to_utc_date_string(date) must produce a valid UTC datetime string."""
        from datetime import date

        from caldav.elements.cdav import _to_utc_date_string

        result = _to_utc_date_string(date(2026, 5, 1))
        assert result == "20260501T000000Z"

    def test_to_utc_date_string_with_datetime_unchanged(self):
        """_to_utc_date_string(datetime) must still work correctly."""
        from datetime import datetime, timezone

        from caldav.elements.cdav import _to_utc_date_string

        result = _to_utc_date_string(datetime(2026, 5, 1, 12, 0, 0, tzinfo=timezone.utc))
        assert result == "20260501T120000Z"

    def test_time_range_xml_with_date_produces_utc_attrs(self):
        """TimeRange built with plain date objects must emit UTC datetime attributes."""
        from datetime import date

        from caldav.elements.cdav import TimeRange

        tr = TimeRange(start=date(2026, 5, 1), end=date(2026, 6, 1))
        assert tr.attributes["start"] == "20260501T000000Z"
        assert tr.attributes["end"] == "20260601T000000Z"

    def test_search_with_date_emits_utc_datetime_in_report_xml(self):
        """calendar.search(start=date(...)) must send UTC datetime strings in
        the REPORT body, not bare date strings."""
        from datetime import date

        class CapturingClient(MockedDAVClient):
            def __init__(self):
                super().__init__("<multistatus xmlns='DAV:'/>")
                self.report_bodies = []

            def request(self, url, method="GET", body=None, headers=None):
                if method == "REPORT" and body:
                    self.report_bodies.append(body)
                return super().request(url, method, body, headers)

        client = CapturingClient()
        calendar = Calendar(client, url="/cal/")
        calendar.search(event=True, start=date(2026, 5, 1), end=date(2026, 6, 1))

        assert client.report_bodies, "expected at least one REPORT request"
        body = client.report_bodies[0]
        if isinstance(body, bytes):
            body = body.decode()
        assert "20260501T000000Z" in body, f"UTC start not found in REPORT body:\n{body}"
        assert "20260601T000000Z" in body, f"UTC end not found in REPORT body:\n{body}"
        # Must NOT contain bare date strings without time component
        assert "20260501Z" not in body
        assert "20260601Z" not in body

    def test_searcher_coerces_date_to_datetime(self):
        """calendar.searcher(start=date(...)) must store datetime on the searcher,
        not bare date objects — otherwise icalendar_searcher warns during
        client-side filtering (check_component is called per result object)."""
        from datetime import date, datetime, timezone

        client = MockedDAVClient("<multistatus xmlns='DAV:'/>")
        calendar = Calendar(client, url="/cal/")
        searcher = calendar.searcher(
            event=True,
            start=date(2026, 5, 1),
            end=date(2026, 6, 1),
        )
        assert isinstance(searcher.start, datetime), (
            f"searcher.start should be datetime, got {type(searcher.start)}"
        )
        assert isinstance(searcher.end, datetime), (
            f"searcher.end should be datetime, got {type(searcher.end)}"
        )
        assert searcher.start == datetime(2026, 5, 1, 0, 0, 0, tzinfo=timezone.utc)
        assert searcher.end == datetime(2026, 6, 1, 0, 0, 0, tzinfo=timezone.utc)


class TestExpandConfigSection:
    """Unit tests for caldav.config.expand_config_section."""

    def test_normal_section_returns_single_item(self):
        from caldav.config import expand_config_section

        config = {"default": {"caldav_url": "https://example.com/"}}
        assert expand_config_section(config, "default") == ["default"]

    def test_meta_section_with_contains(self):
        from caldav.config import expand_config_section

        config = {
            "work": {"caldav_url": "https://work.example.com/"},
            "personal": {"caldav_url": "https://personal.example.com/"},
            "all": {"contains": ["work", "personal"]},
        }
        assert expand_config_section(config, "all") == ["work", "personal"]

    def test_star_returns_all_non_disabled_sections(self):
        from caldav.config import expand_config_section

        config = {
            "work": {"caldav_url": "https://work.example.com/"},
            "personal": {"caldav_url": "https://personal.example.com/"},
            "hidden": {"caldav_url": "https://hidden.example.com/", "disable": True},
        }
        result = expand_config_section(config, "*")
        assert set(result) == {"work", "personal"}

    def test_glob_pattern(self):
        from caldav.config import expand_config_section

        config = {
            "work_a": {"caldav_url": "https://a.example.com/"},
            "work_b": {"caldav_url": "https://b.example.com/"},
            "personal": {"caldav_url": "https://c.example.com/"},
        }
        result = expand_config_section(config, "work_*")
        assert set(result) == {"work_a", "work_b"}

    def test_recursive_meta_section(self):
        from caldav.config import expand_config_section

        config = {
            "a": {"caldav_url": "https://a.example.com/"},
            "b": {"caldav_url": "https://b.example.com/"},
            "ab": {"contains": ["a", "b"]},
            "c": {"caldav_url": "https://c.example.com/"},
            "all": {"contains": ["ab", "c"]},
        }
        assert set(expand_config_section(config, "all")) == {"a", "b", "c"}

    def test_missing_section_returns_empty(self):
        """§1.9: expand_config_section(config, "default") when "default" is absent must
        return [] rather than raising KeyError."""
        from caldav.config import expand_config_section

        config = {"work": {"caldav_url": "https://work.example.com/"}}
        # Requesting a section that doesn't exist should return [] (no match), not crash
        assert expand_config_section(config, "default") == []

    def test_disable_respected_for_named_sections(self):
        """§2.17: disable:true must suppress named sections, not just glob '*' results.

        The old code used the literal string 'section' instead of the variable,
        so disable was only effective under the '*' glob path.
        """
        from caldav.config import expand_config_section

        config = {"work": {"caldav_url": "https://work.example.com/", "disable": True}}
        assert expand_config_section(config, "work") == []


class TestConfigSectionInheritance:
    """Unit tests for caldav.config.config_section (inherits key)."""

    def test_inherits_copies_parent_values(self):
        from caldav.config import config_section

        config = {
            "base": {"caldav_url": "https://example.com/", "caldav_username": "alice"},
            "child": {"inherits": "base", "caldav_username": "bob"},
        }
        result = config_section(config, "child")
        assert result["caldav_url"] == "https://example.com/"
        # child's own value overrides parent's
        assert result["caldav_username"] == "bob"

    def test_inherits_does_not_affect_parent(self):
        from caldav.config import config_section

        config = {
            "base": {"caldav_url": "https://example.com/", "caldav_username": "alice"},
            "child": {"inherits": "base", "calendar_name": "Inbox"},
        }
        parent = config_section(config, "base")
        assert "calendar_name" not in parent

    def test_inherits_recursive(self):
        from caldav.config import config_section

        config = {
            "grandparent": {"caldav_url": "https://example.com/"},
            "parent": {"inherits": "grandparent", "caldav_username": "alice"},
            "child": {"inherits": "parent", "caldav_password": "secret"},
        }
        result = config_section(config, "child")
        assert result["caldav_url"] == "https://example.com/"
        assert result["caldav_username"] == "alice"
        assert result["caldav_password"] == "secret"


class TestExpandEnvVars:
    """Unit tests for caldav.config.expand_env_vars."""

    def test_simple_var(self, monkeypatch):
        from caldav.config import expand_env_vars

        monkeypatch.setenv("TEST_CALDAV_URL", "https://env.example.com/")
        assert expand_env_vars("${TEST_CALDAV_URL}") == "https://env.example.com/"

    def test_default_when_missing(self):
        import os

        from caldav.config import expand_env_vars

        os.environ.pop("MISSING_CALDAV_VAR", None)
        assert expand_env_vars("${MISSING_CALDAV_VAR:-fallback}") == "fallback"

    def test_empty_default_when_missing(self):
        import os

        from caldav.config import expand_env_vars

        os.environ.pop("MISSING_CALDAV_VAR", None)
        assert expand_env_vars("${MISSING_CALDAV_VAR}") == ""

    def test_recursive_in_dict(self, monkeypatch):
        from caldav.config import expand_env_vars

        monkeypatch.setenv("TEST_USER", "alice")
        result = expand_env_vars({"caldav_username": "${TEST_USER}"})
        assert result == {"caldav_username": "alice"}

    def test_env_var_in_config_section(self, tmp_path, monkeypatch):
        """end-to-end: env var in config file is expanded before use."""
        import json

        from caldav.config import get_all_file_connection_params

        monkeypatch.setenv("MY_CALDAV_PASS", "s3cr3t")
        config = {
            "default": {
                "caldav_url": "https://example.com/",
                "caldav_username": "alice",
                "caldav_password": "${MY_CALDAV_PASS}",
            }
        }
        config_file = tmp_path / "calendar.conf"
        config_file.write_text(json.dumps(config))
        results = get_all_file_connection_params(str(config_file))
        assert results[0]["password"] == "s3cr3t"


class TestGetAllFileConnectionParams:
    """Unit tests for caldav.config.get_all_file_connection_params."""

    def test_single_section_returns_one_dict(self, tmp_path):
        import json

        from caldav.config import get_all_file_connection_params

        config = {
            "default": {
                "caldav_url": "https://example.com/dav/",
                "caldav_username": "user",
                "caldav_password": "pass",
            }
        }
        config_file = tmp_path / "calendar.conf"
        config_file.write_text(json.dumps(config))
        results = get_all_file_connection_params(str(config_file), "default")
        assert len(results) == 1
        assert results[0]["url"] == "https://example.com/dav/"
        assert results[0]["username"] == "user"

    def test_calendar_name_extracted_from_section(self, tmp_path):
        import json

        from caldav.config import get_all_file_connection_params

        config = {
            "default": {
                "caldav_url": "https://example.com/dav/",
                "caldav_username": "user",
                "calendar_name": "My Calendar",
            }
        }
        config_file = tmp_path / "calendar.conf"
        config_file.write_text(json.dumps(config))
        results = get_all_file_connection_params(str(config_file), "default")
        assert len(results) == 1
        assert results[0]["calendar_name"] == "My Calendar"

    def test_calendar_url_extracted_from_section(self, tmp_path):
        import json

        from caldav.config import get_all_file_connection_params

        config = {
            "default": {
                "caldav_url": "https://example.com/dav/",
                "caldav_username": "user",
                "calendar_url": "/dav/user/mycalendar/",
            }
        }
        config_file = tmp_path / "calendar.conf"
        config_file.write_text(json.dumps(config))
        results = get_all_file_connection_params(str(config_file), "default")
        assert len(results) == 1
        assert results[0]["calendar_url"] == "/dav/user/mycalendar/"

    def test_section_with_features_but_no_url(self, tmp_path):
        """A section without caldav_url is usable when it has features —
        the client constructor resolves the URL from auto-connect.url hints."""
        import json

        from caldav.config import get_all_file_connection_params

        config = {
            "ecloud": {
                "caldav_username": "user@e.email",
                "caldav_password": "pass",
                "features": "ecloud",
            }
        }
        config_file = tmp_path / "calendar.conf"
        config_file.write_text(json.dumps(config))
        results = get_all_file_connection_params(str(config_file), "ecloud")
        assert len(results) == 1
        assert results[0]["username"] == "user@e.email"
        assert results[0]["features"]

    def test_get_connection_params_features_but_no_url(self, tmp_path):
        """Same as above, but through get_connection_params — the code path
        used by get_davclient(config_section=...)."""
        import json

        from caldav.config import get_connection_params

        config = {
            "ecloud": {
                "caldav_username": "user@e.email",
                "caldav_password": "pass",
                "features": "ecloud",
            }
        }
        config_file = tmp_path / "calendar.conf"
        config_file.write_text(json.dumps(config))
        params = get_connection_params(
            config_file=str(config_file), config_section="ecloud", environment=False
        )
        assert params is not None
        assert params["username"] == "user@e.email"
        assert params["features"]

    def test_meta_section_returns_multiple_dicts(self, tmp_path):
        import json

        from caldav.config import get_all_file_connection_params

        config = {
            "work": {
                "caldav_url": "https://work.example.com/dav/",
                "caldav_username": "wuser",
            },
            "personal": {
                "caldav_url": "https://personal.example.com/dav/",
                "caldav_username": "puser",
            },
            "all": {"contains": ["work", "personal"]},
        }
        config_file = tmp_path / "calendar.conf"
        config_file.write_text(json.dumps(config))
        results = get_all_file_connection_params(str(config_file), "all")
        assert len(results) == 2
        urls = {r["url"] for r in results}
        assert urls == {
            "https://work.example.com/dav/",
            "https://personal.example.com/dav/",
        }


class TestExplicitParamsMerge:
    """§2.18: get_connection_params explicit kwargs must be merged with env/file config.

    The old code only returned explicit_params when 'url' or 'features' was present;
    params like password-only were silently discarded when an env/file source was found.
    """

    def test_explicit_password_merged_with_env_url(self, monkeypatch):
        """get_connection_params(password='secret') with CALDAV_URL in env must include the password."""
        from caldav.config import get_connection_params

        monkeypatch.setenv("CALDAV_URL", "https://env.example.com/")
        monkeypatch.setenv("CALDAV_USERNAME", "envuser")
        # Unset file config to avoid config-file interference
        monkeypatch.delenv("CALDAV_CONFIG_FILE", raising=False)
        result = get_connection_params(password="secret", check_config_file=False)
        assert result is not None
        assert result.get("password") == "secret"
        assert result.get("url") == "https://env.example.com/"

    def test_explicit_none_does_not_clobber_env_url(self, monkeypatch):
        """Gate finding F8: a kwarg that is explicitly None is "not supplied",
        not "unset it".

        The common CLI wrapper -- get_davclient(url=args.url,
        username=args.user, password=args.password) where the user only gave
        --password -- overlaid url=None on top of the winning source and
        wiped CALDAV_URL."""
        from caldav.config import get_connection_params

        monkeypatch.setenv("CALDAV_URL", "https://env.example.com/")
        monkeypatch.setenv("CALDAV_USERNAME", "envuser")
        monkeypatch.delenv("CALDAV_CONFIG_FILE", raising=False)
        result = get_connection_params(
            url=None, username=None, password="secret", check_config_file=False
        )
        assert result is not None
        assert result.get("url") == "https://env.example.com/"
        assert result.get("username") == "envuser"
        assert result.get("password") == "secret"

    def test_empty_string_username_is_still_explicit(self, monkeypatch):
        """An empty username is meaningful (servers with no auth) and must
        not be discarded along with the Nones."""
        from caldav.config import get_connection_params

        monkeypatch.setenv("CALDAV_URL", "https://env.example.com/")
        monkeypatch.setenv("CALDAV_USERNAME", "envuser")
        monkeypatch.delenv("CALDAV_CONFIG_FILE", raising=False)
        result = get_connection_params(username="", check_config_file=False)
        assert result is not None
        assert result.get("username") == ""

    def test_explicit_params_merged_with_test_server_config(self, monkeypatch):
        """Gate finding F8: the testconfig branch returned the test-server
        config verbatim, dropping the explicit kwargs entirely."""
        from caldav import config as config_module
        from caldav.config import get_connection_params

        monkeypatch.setattr(
            config_module,
            "_get_test_server_config",
            lambda *a, **kw: {"url": "https://testserver.example.com/", "username": "testuser"},
        )
        result = get_connection_params(testconfig=True, password="secret")
        assert result is not None
        assert result.get("url") == "https://testserver.example.com/"
        assert result.get("password") == "secret"


class TestResolveFeaturesMutation:
    """§2.19: resolve_features and testing.py server classes must deepcopy hint dicts.

    Returning or shallow-copying a module-level dict then mutating a nested key
    permanently corrupts the module-level dict for all subsequent users.
    """

    def test_resolve_features_string_returns_independent_copy(self):
        """resolve_features('xandikos') must return a deep copy, not the module object."""
        from caldav import compatibility_hints as hints
        from caldav.config import resolve_features

        original_domain = hints.xandikos.get("auto-connect.url", {}).get("domain", "<sentinel>")
        result = resolve_features("xandikos")
        # Mutate the returned copy
        if "auto-connect.url" in result and isinstance(result["auto-connect.url"], dict):
            result["auto-connect.url"]["domain"] = "MUTATED:9999"
        # Original must be unchanged
        assert hints.xandikos.get("auto-connect.url", {}).get("domain") == original_domain


class TestResolveProperties:
    """Tests for _resolve_properties unbound variable bug (issue #647 / calendar-cli #114)."""

    def _make_calendar(self, path="/calendar/"):
        client = DAVClient(url="https://example.com")
        return Calendar(client=client, url=f"https://example.com{path}")

    def test_resolve_properties_empty_dict_production_mode(self):
        """In PRODUCTION mode, error.assert_ only logs; _resolve_properties must
        not crash with UnboundLocalError when properties dict is empty."""
        cal = self._make_calendar()
        with mock.patch.object(error, "debugmode", "PRODUCTION"):
            result = cal._resolve_properties({})
        assert result == {}

    def test_resolve_properties_unmatched_paths_production_mode(self):
        """Same but with a non-empty properties dict where path does not match."""
        cal = self._make_calendar("/calendar/")
        with mock.patch.object(error, "debugmode", "PRODUCTION"):
            result = cal._resolve_properties(
                {"/other/path/": {"foo": "bar"}, "/yet/another/": {"baz": "qux"}}
            )
        assert result == {}


class TestAddOrganizer:
    """Unit tests for CalendarObjectResource.add_organizer() (issue #524)."""

    _ev = """\
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//Test//EN
BEGIN:VEVENT
UID:test-add-organizer@example.com
DTSTAMP:20240101T000000Z
DTSTART:20240601T100000Z
DTEND:20240601T110000Z
SUMMARY:Test event
END:VEVENT
END:VCALENDAR
"""

    def _make_event(self):
        return Event(data=self._ev)

    def test_add_organizer_email_string(self):
        """Passing a plain email string sets the ORGANIZER field."""
        ev = self._make_event()
        ev.add_organizer("organizer@example.com")
        organizer = ev.icalendar_component.get("organizer")
        assert organizer is not None
        assert "organizer@example.com" in str(organizer)

    def test_add_organizer_mailto_string(self):
        """Passing a mailto: URI sets the ORGANIZER field."""
        ev = self._make_event()
        ev.add_organizer("mailto:organizer@example.com")
        organizer = ev.icalendar_component.get("organizer")
        assert str(organizer) == "mailto:organizer@example.com"

    def test_add_organizer_vcal_address(self):
        """Passing a vCalAddress directly sets the ORGANIZER field."""
        from icalendar import vCalAddress

        ev = self._make_event()
        addr = vCalAddress("mailto:organizer@example.com")
        ev.add_organizer(addr)
        organizer = ev.icalendar_component.get("organizer")
        assert str(organizer) == "mailto:organizer@example.com"

    def test_add_organizer_replaces_existing(self):
        """Calling add_organizer twice replaces the first value, no duplicate."""
        ev = self._make_event()
        ev.add_organizer("first@example.com")
        ev.add_organizer("second@example.com")
        comp = ev.icalendar_component
        ## icalendar stores repeated properties as a list; ORGANIZER should be
        ## a single value, not a list.
        organizer = comp.get("organizer")
        assert not isinstance(organizer, list), "ORGANIZER should not be duplicated"
        assert "second@example.com" in str(organizer)

    def test_add_organizer_no_arg_uses_principal(self):
        """Calling add_organizer() without arguments uses the current principal."""
        from icalendar import vCalAddress

        ev = self._make_event()
        mock_client = mock.MagicMock()
        mock_principal = mock.MagicMock()
        mock_principal.get_vcal_address.return_value = vCalAddress("mailto:me@example.com")
        mock_client.principal.return_value = mock_principal
        ev.client = mock_client
        ev.add_organizer()
        organizer = ev.icalendar_component.get("organizer")
        assert str(organizer) == "mailto:me@example.com"

    def test_add_organizer_no_arg_no_client_raises(self):
        """Calling add_organizer() without arguments and no client raises ValueError."""
        ev = self._make_event()
        ev.client = None
        with pytest.raises(ValueError):
            ev.add_organizer()

    def test_add_organizer_principal_object(self):
        """Passing a Principal object directly calls get_vcal_address() on it."""
        from icalendar import vCalAddress

        ev = self._make_event()
        mock_principal = mock.MagicMock(spec=Principal)
        mock_principal.get_vcal_address.return_value = vCalAddress("mailto:organizer@example.com")
        ev.add_organizer(mock_principal)
        organizer = ev.icalendar_component.get("organizer")
        assert str(organizer) == "mailto:organizer@example.com"
        mock_principal.get_vcal_address.assert_called_once()


class TestChangeAttendeeStatusFallback:
    """Unit tests for change_attendee_status() fallback when calendar_user_address_set() is unavailable.

    Covers issue https://github.com/python-caldav/caldav/issues/399: accept_invite() fails on servers
    that do not expose the calendar-user-address-set property (RFC6638 §2.4.1).
    """

    _invite = """\
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//Test//EN
METHOD:REQUEST
BEGIN:VEVENT
UID:test-invite-399@example.com
DTSTAMP:20240101T000000Z
DTSTART:20240601T100000Z
DTEND:20240601T110000Z
SUMMARY:Test invite
ORGANIZER:mailto:organizer@example.com
ATTENDEE;PARTSTAT=NEEDS-ACTION:mailto:attendee@example.com
END:VEVENT
END:VCALENDAR
"""

    def _make_event_with_mock_client(self, username):
        from caldav.collection import Principal
        from caldav.lib import error as caldav_error

        ev = Event(data=self._invite)
        mock_client = mock.MagicMock()
        mock_client.username = username
        mock_principal = mock.MagicMock(spec=Principal)
        mock_principal.calendar_user_address_set.side_effect = caldav_error.NotFoundError(
            "calendar-user-address-set not supported"
        )
        mock_client.principal.return_value = mock_principal
        ev.client = mock_client
        return ev

    def test_change_attendee_status_falls_back_to_email_username(self):
        """When calendar_user_address_set() raises NotFoundError and username is an email,
        change_attendee_status() should use the username as the attendee address."""
        ev = self._make_event_with_mock_client("attendee@example.com")
        ev.change_attendee_status(partstat="ACCEPTED")
        attendee = ev.icalendar_component["attendee"]
        assert attendee.params.get("PARTSTAT") == "ACCEPTED"

    def test_change_attendee_status_raises_when_username_not_email(self):
        """When calendar_user_address_set() raises NotFoundError and username is not an email,
        change_attendee_status() should re-raise NotFoundError with a descriptive message."""
        from caldav.lib import error as caldav_error

        ev = self._make_event_with_mock_client("just_a_username")
        with pytest.raises(caldav_error.NotFoundError):
            ev.change_attendee_status(partstat="ACCEPTED")


class TestAddAttendee:
    """§1.6: add_attendee() crashes with UnboundLocalError on uppercase MAILTO: scheme.

    RFC 3986 §3.1 specifies URI schemes are case-insensitive, so "MAILTO:user@example.com"
    is valid and common in real-world iCalendar data.  The old code only matched lowercase
    "mailto:" — uppercase fell through all string branches, leaving attendee_obj unassigned.
    """

    _base_event = """\
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//Test//EN
BEGIN:VEVENT
UID:test-add-attendee@example.com
DTSTAMP:20240101T000000Z
DTSTART:20240601T100000Z
DTEND:20240601T110000Z
SUMMARY:Test event
END:VEVENT
END:VCALENDAR
"""

    def test_add_attendee_uppercase_mailto(self):
        """add_attendee('MAILTO:user@example.com') must not raise UnboundLocalError."""
        ev = Event(data=self._base_event)
        ev.add_attendee("MAILTO:user@example.com")
        attendee = ev.icalendar_component["attendee"]
        assert "user@example.com" in str(attendee).lower()

    def test_add_attendee_mixed_case_mailto(self):
        """Mixed-case scheme variants like 'Mailto:' must also work."""
        ev = Event(data=self._base_event)
        ev.add_attendee("Mailto:user@example.com")
        attendee = ev.icalendar_component["attendee"]
        assert "user@example.com" in str(attendee).lower()


class TestChangeAttendeeStatusNoAttendees:
    """§1.7: change_attendee_status() raises bare KeyError when event has no ATTENDEE property.

    ical_obj["attendee"] raises KeyError when the key is absent; the NotFoundError-catching
    loop in the Principal branch never sees it, so the "Principal is not invited" message
    is unreachable and callers get an unexpected KeyError instead.

    Also: the not-found message contained a literal '%s' placeholder that was never
    substituted.
    """

    _event_no_attendees = """\
BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Test//Test//EN
BEGIN:VEVENT
UID:test-no-attendees@example.com
DTSTAMP:20240101T000000Z
DTSTART:20240601T100000Z
DTEND:20240601T110000Z
SUMMARY:Event with no attendees
END:VEVENT
END:VCALENDAR
"""

    def test_change_attendee_status_no_attendees_raises_not_found(self):
        """Calling change_attendee_status on an event with no ATTENDEE must raise
        NotFoundError, not KeyError."""
        ev = Event(data=self._event_no_attendees)
        with pytest.raises(error.NotFoundError):
            ev.change_attendee_status("mailto:nobody@example.com", partstat="ACCEPTED")

    def test_change_attendee_status_error_message_contains_attendee(self):
        """The not-found error message must contain the attendee address, not a literal '%s'."""
        ev = Event(data=self._event_no_attendees)
        with pytest.raises(error.NotFoundError) as exc_info:
            ev.change_attendee_status("mailto:nobody@example.com", partstat="ACCEPTED")
        assert "%s" not in str(exc_info.value)
        assert "nobody@example.com" in str(exc_info.value)


class TestFeatureSetCopyFeatureSet:
    """§1.10 + §1.11: FeatureSet.copyFeatureSet() correctness bugs.

    §1.10: Merging a plain-string feature over an existing string-valued feature raised
    bare AssertionError because the 'support' not in server_node guard prevented the
    update branch from running.

    §1.11: An unknown feature name produced a UserWarning but was still stored in
    _server_features; a later collapse()/is_supported() then hit a message-less
    AssertionError far from the originating config.  Unknown features must be skipped
    (continue after warning) so bad keys never contaminate the feature set.
    """

    def test_string_feature_can_be_overridden(self):
        """copyFeatureSet must accept a string value that overrides an existing string."""
        from caldav.compatibility_hints import FeatureSet

        fs = FeatureSet({"scheduling": "unsupported"})
        fs.copyFeatureSet({"scheduling": "fragile"})
        assert fs.is_supported("scheduling") is False  # fragile → False per is_supported semantics

    def test_string_feature_full_override(self):
        """Overriding 'unsupported' with 'full' must make is_supported return True."""
        from caldav.compatibility_hints import FeatureSet

        fs = FeatureSet({"scheduling": "unsupported"})
        fs.copyFeatureSet({"scheduling": "full"})
        assert fs.is_supported("scheduling") is True

    def test_unknown_feature_warns_and_does_not_store(self):
        """An unknown feature name must emit UserWarning and must NOT be stored."""
        import warnings

        from caldav.compatibility_hints import FeatureSet

        fs = FeatureSet({})
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            fs.copyFeatureSet({"totally_nonexistent_feature_xyz": "full"})

        assert any("totally_nonexistent_feature_xyz" in str(warning.message) for warning in w)
        # The bad key must NOT be in the internal feature dict
        assert "totally_nonexistent_feature_xyz" not in fs._server_features


class TestXMLEntityHardening:
    """§3.2: XML parser must not expand entity references from untrusted server data.

    etree.XMLParser without resolve_entities=False expands inline DOCTYPE
    entities, allowing a malicious server to inject arbitrary text into
    parsed values.  With resolve_entities=False the entity reference is
    left as-is (text becomes None for element content).
    """

    def test_xml_entity_not_expanded(self):
        """Entity defined in DOCTYPE must NOT be expanded into element text."""
        xml = b"""<?xml version="1.0"?>
<!DOCTYPE foo [<!ENTITY xxe "INJECTED">]>
<multistatus xmlns="DAV:">
  <response>
    <href>/</href>
    <propstat>
      <prop><displayname>&xxe;</displayname></prop>
      <status>HTTP/1.1 200 OK</status>
    </propstat>
  </response>
</multistatus>"""
        resp = MockedDAVResponse(xml)
        assert resp.tree is not None
        displayname_el = resp.tree.find(".//{DAV:}displayname")
        assert displayname_el is not None
        assert displayname_el.text != "INJECTED", (
            "XML entity was expanded — resolve_entities=False is missing from the parser"
        )


class TestDAVClientCredentialPrecedence:
    """§1.2: DAVClient credential handling bugs.

    - URL with username but no password (user@host) crashed with TypeError inside
      urllib.parse.unquote(None).
    - URL credentials had higher precedence than explicit kwargs; async client was
      the opposite (explicit kwargs win).  Now sync matches async: explicit kwargs win.
    """

    def test_url_with_user_but_no_password_does_not_crash(self):
        """DAVClient(url='https://user@host/', password='p') must not raise TypeError."""
        client = DAVClient(url="https://user@cal.example.com/dav/", password="secret")
        assert client.username == "user"
        assert client.password == b"secret"

    def test_explicit_kwargs_take_precedence_over_url_credentials(self):
        """Explicit username/password kwargs must override credentials embedded in the URL."""
        client = DAVClient(
            url="https://urluser:urlpass@cal.example.com/dav/",
            username="kwarguser",
            password="kwargpass",
        )
        assert client.username == "kwarguser"
        assert client.password == b"kwargpass"

    def test_explicit_username_does_not_borrow_url_password(self):
        """Gate finding F6: credentials are a pair, not two independent fields.

        Merging them field by field produced ``username="alice"`` with
        ``password="hunter2"`` — alice's login shipping bob's password."""
        client = DAVClient(
            url="https://bob:hunter2@cal.example.com/dav/",
            username="alice",
        )
        assert client.username == "alice"
        assert client.password is None

    def test_explicit_password_still_pairs_with_the_url_username(self):
        """Overriding only the password keeps the pair coherent: the username
        still comes from the URL, so there is no account mismatch."""
        client = DAVClient(
            url="https://bob:hunter2@cal.example.com/dav/",
            password="s3cret",
        )
        assert client.username == "bob"
        assert client.password == b"s3cret"


class TestPropstatStatusValidation:
    """Gate finding F7: a failing propstat status must raise, not vanish.

    Deduplicating the propstat loops dropped the per-propstat
    ``validate_status()`` call, so a ``500``/``403``/``507`` propstat yielded
    a silently-empty value instead of a ``ResponseError`` -- and the calendar
    was then dropped from ``get_calendars()`` with only a log line.
    ``_validate_status`` raises unconditionally; it is not an assert, so
    ``python -O`` does not disable it either.
    """

    XML = """
<multistatus xmlns="DAV:">
  <response>
    <href>/dav/calendars/user/broken/</href>
    <propstat>
      <prop><displayname/></prop>
      <status>HTTP/1.1 500 Internal Server Error</status>
    </propstat>
  </response>
</multistatus>
"""

    def test_server_error_propstat_raises(self):
        with pytest.raises(error.ResponseError):
            MockedDAVResponse(self.XML).expand_simple_props(props=[dav.DisplayName()])

    def test_insufficient_storage_propstat_raises(self):
        xml = self.XML.replace("500 Internal Server Error", "507 Insufficient Storage")
        with pytest.raises(error.ResponseError):
            MockedDAVResponse(xml).expand_simple_props(props=[dav.DisplayName()])

    def test_404_propstat_is_still_a_missing_property(self):
        """The 404 quirk must survive: a 404 propstat means "not set here",
        not "the request failed"."""
        xml = self.XML.replace("500 Internal Server Error", "404 Not Found")
        result = MockedDAVResponse(xml).expand_simple_props(props=[dav.DisplayName()])
        assert result == {"/dav/calendars/user/broken/": {"{DAV:}displayname": None}}


class TestAsyncDAVClientCredentialPairing:
    """Gate finding F6, async twin: same field-by-field merge, same result."""

    def test_explicit_username_does_not_borrow_url_password(self):
        from caldav.async_davclient import AsyncDAVClient

        client = AsyncDAVClient(
            url="https://bob:hunter2@cal.example.com/dav/",
            username="alice",
        )
        assert client.username == "alice"
        assert client.password is None

    def test_explicit_password_still_pairs_with_the_url_username(self):
        from caldav.async_davclient import AsyncDAVClient

        client = AsyncDAVClient(
            url="https://bob:hunter2@cal.example.com/dav/",
            password="s3cret",
        )
        assert client.username == "bob"
        assert client.password == "s3cret"


class TestPostPutRedirect:
    """§1.1: 302 response to PUT must update event.url from Location header.

    Bug: `[x[1] for x in r.headers if x[0] == "location"]` iterates the
    headers dict yielding key *strings*, so x[0] is the first character of
    each header name — never "location".  The list is always empty and any
    302 raises IndexError.
    """

    @mock.patch("caldav.davclient.requests.Session.request")
    def test_302_put_updates_url_from_location_header(self, mocked):
        try:
            from niquests.structures import CaseInsensitiveDict
        except ImportError:
            from requests.structures import CaseInsensitiveDict

        new_url = "http://cal.example.com/cal/new-location.ics"
        resp = mock.MagicMock()
        resp.status_code = 302
        resp.headers = CaseInsensitiveDict({"Location": new_url})
        resp.reason = "Found"
        resp.content = b""
        mocked.return_value = resp

        client = DAVClient(url="http://cal.example.com/")
        cal = Calendar(client=client, url="http://cal.example.com/cal/")
        event = Event(
            client=client,
            url="http://cal.example.com/cal/event.ics",
            data=ev1,
            parent=cal,
        )
        event.save()
        assert str(event.url) == new_url


class TestWarnUnreadableDisplayName:
    """§5 (DRY): the shared helper backing the sync/async name-matching loops.

    Warn unless we positively know the server can't read DAV:displayname via
    PROPFIND (propfind.displayname non-supported); warn when the feature is
    supported or when there is no feature matrix to consult.
    """

    @staticmethod
    def _client(features):
        client = mock.MagicMock()
        client.features = features
        return client

    def test_warns_when_feature_supported(self, caplog):
        from caldav.base_client import _warn_unreadable_display_name
        from caldav.compatibility_hints import FeatureSet

        cal = mock.MagicMock()
        cal.url = "http://cal.example.com/cal/"
        with caplog.at_level("WARNING", logger="caldav"):
            _warn_unreadable_display_name(
                self._client(FeatureSet()), cal, "Work", Exception("boom")
            )
        assert any("Could not read display name" in r.message for r in caplog.records)

    def test_silent_when_feature_unsupported(self, caplog):
        from caldav.base_client import _warn_unreadable_display_name
        from caldav.compatibility_hints import FeatureSet

        features = FeatureSet({"propfind.displayname": {"support": "unsupported"}})
        with caplog.at_level("WARNING", logger="caldav"):
            _warn_unreadable_display_name(
                self._client(features), mock.MagicMock(), "Work", Exception("boom")
            )
        assert not caplog.records

    def test_silent_when_parent_propfind_unsupported(self, caplog):
        from caldav.base_client import _warn_unreadable_display_name
        from caldav.compatibility_hints import FeatureSet

        # propfind.displayname falls back to the propfind parent when not probed
        features = FeatureSet({"propfind": {"support": "unsupported"}})
        with caplog.at_level("WARNING", logger="caldav"):
            _warn_unreadable_display_name(
                self._client(features), mock.MagicMock(), "Work", Exception("boom")
            )
        assert not caplog.records

    def test_warns_when_no_feature_matrix(self, caplog):
        from caldav.base_client import _warn_unreadable_display_name

        client = mock.MagicMock()
        client.features = None
        with caplog.at_level("WARNING", logger="caldav"):
            _warn_unreadable_display_name(client, mock.MagicMock(), "Work", Exception("boom"))
        assert any("Could not read display name" in r.message for r in caplog.records)


class TestRecurringCompleteHelpers:
    """Pure (no-I/O) unit tests for the recurring-task completion helpers.

    These exercise the icalendar-mutation logic shared by the sync and async
    ``complete()`` paths without touching a server.
    ref https://github.com/python-caldav/caldav code-review §5.6
    """

    def _make_todo(self, data: str = todo6) -> Todo:
        client = MockedDAVClient("")
        cal_url = "https://somwhere.in.the.universe.example/some/caldav/root/cal/"
        calendar = Calendar(client, url=cal_url)
        return Todo(client, data=data, parent=calendar, url=cal_url + "t.ics")

    def test_prepare_thisandfuture_advances_series(self) -> None:
        todo = self._make_todo()
        before = len(todo.icalendar_instance.subcomponents)
        todo._prepare_recurring_thisandfuture(datetime(2026, 6, 14, tzinfo=timezone.utc))
        subs = todo.icalendar_instance.subcomponents
        ## a completed recurrence + a new THISANDFUTURE instance were added
        assert len(subs) == before + 2
        last = subs[-1]
        assert last["RECURRENCE-ID"].params.get("RANGE") == "THISANDFUTURE"
        ## one of the recurrences is now marked COMPLETED
        assert any(str(s.get("STATUS")) == "COMPLETED" for s in subs)

    def test_build_safe_completed_returns_completed_copy(self) -> None:
        todo = self._make_todo()
        orig_dtstart = todo.icalendar_component["DTSTART"].dt
        completed = todo._build_recurring_safe_completed(datetime(2026, 6, 14, tzinfo=timezone.utc))
        assert completed is not None
        ## the standalone copy is completed and no longer recurring
        assert str(completed.icalendar_component["STATUS"]) == "COMPLETED"
        assert "RRULE" not in completed.icalendar_component
        ## the master task advanced to its next occurrence and stays recurring
        assert todo.icalendar_component["DTSTART"].dt > orig_dtstart
        assert "RRULE" in todo.icalendar_component

    def test_build_safe_completed_none_when_count_one(self) -> None:
        ## A recurring task with COUNT=1 is not really recurring
        todo = self._make_todo()
        todo.icalendar_component["RRULE"]["COUNT"] = [1]
        assert (
            todo._build_recurring_safe_completed(datetime(2026, 6, 14, tzinfo=timezone.utc)) is None
        )

    def test_safe_completion_issues_two_puts(self, monkeypatch: Any) -> None:
        """The standalone completed copy must not be PUT twice.

        The old async twin had drifted into saving the completed copy once
        as still-pending and again as completed (3 PUTs total for the
        operation).  Completing in memory first means one PUT per object.
        """
        saves: list[Todo] = []

        def fake_save(self: Todo, *a: Any, **k: Any) -> Todo:
            saves.append(self)
            return self

        monkeypatch.setattr(Todo, "save", fake_save)
        todo = self._make_todo()
        todo._complete_recurring_safe(datetime(2026, 6, 14, tzinfo=timezone.utc))
        ## one PUT for the standalone completed copy, one for the advanced master
        assert len(saves) == 2


class TestAdoptCanonicalUrl:
    """Gate finding F4: after creating a calendar on a server where
    ``create-calendar.stable-url`` is unsupported, the canonical URL is
    discovered by display name.  When two calendars share that name the
    docstring promises the requested URL is kept -- adopting one of them at
    random can re-point a freshly created calendar at a *pre-existing*
    unrelated calendar, so every later ``add_event()``, ``search()`` and
    ``delete()`` would hit the wrong calendar and the new one would be
    orphaned."""

    REQUESTED = "https://cal.example.com/dav/requested-id/"

    def _make_calendar(self, *relocated_urls: str) -> Calendar:
        client = mock.Mock(spec=DAVClient)
        client.url = URL("https://cal.example.com/")
        calendar = Calendar(client=client, url=self.REQUESTED)

        others = []
        for url in relocated_urls:
            other = mock.Mock()
            other.url = URL(url)
            other.get_display_name.return_value = "My Calendar"
            other.get_display_name.side_effect = None
            others.append(other)

        parent = mock.Mock()
        parent.calendars.return_value = others
        calendar.parent = parent
        return calendar

    def test_single_match_is_adopted(self) -> None:
        calendar = self._make_calendar("https://cal.example.com/dav/canonical/")
        calendar._adopt_canonical_url("My Calendar")
        assert str(calendar.url) == "https://cal.example.com/dav/canonical/"

    def test_ambiguous_name_keeps_requested_url(self) -> None:
        calendar = self._make_calendar(
            "https://cal.example.com/dav/canonical/",
            "https://cal.example.com/dav/some-old-calendar/",
        )
        calendar._adopt_canonical_url("My Calendar")
        assert str(calendar.url) == self.REQUESTED

    def _make_async_calendar(self, *relocated_urls: str) -> Calendar:
        calendar = self._make_calendar(*relocated_urls)
        others = calendar.parent.calendars.return_value
        for other in others:
            other.get_display_name = mock.AsyncMock(return_value="My Calendar")
        calendar.parent.calendars = mock.AsyncMock(return_value=others)
        return calendar

    def test_async_single_match_is_adopted(self) -> None:
        import asyncio

        calendar = self._make_async_calendar("https://cal.example.com/dav/canonical/")
        asyncio.run(calendar._async_adopt_canonical_url("My Calendar"))
        assert str(calendar.url) == "https://cal.example.com/dav/canonical/"

    def test_async_ambiguous_name_keeps_requested_url(self) -> None:
        import asyncio

        calendar = self._make_async_calendar(
            "https://cal.example.com/dav/canonical/",
            "https://cal.example.com/dav/some-old-calendar/",
        )
        asyncio.run(calendar._async_adopt_canonical_url("My Calendar"))
        assert str(calendar.url) == self.REQUESTED
