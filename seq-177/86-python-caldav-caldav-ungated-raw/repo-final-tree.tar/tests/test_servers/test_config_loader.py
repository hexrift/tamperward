"""Tests for config_loader module."""

from pathlib import Path

import pytest

from .config_loader import ConfigParseError, load_test_server_config


class TestLoadTestServerConfig:
    """Tests for load_test_server_config function."""

    def test_valid_yaml_config(self, tmp_path: Path) -> None:
        """Test loading a valid YAML config file."""
        config_file = tmp_path / "test_servers.yaml"
        config_file.write_text("""
test-servers:
  radicale:
    type: embedded
    enabled: true
""")
        cfg = load_test_server_config(str(config_file))
        assert "radicale" in cfg
        assert cfg["radicale"]["type"] == "embedded"

    def test_valid_json_config(self, tmp_path: Path) -> None:
        """Test loading a valid JSON config file."""
        config_file = tmp_path / "test_servers.json"
        config_file.write_text('{"test-servers": {"radicale": {"type": "embedded"}}}')
        cfg = load_test_server_config(str(config_file))
        assert "radicale" in cfg
        assert cfg["radicale"]["type"] == "embedded"

    def test_invalid_yaml_raises_error(self, tmp_path: Path) -> None:
        """Test that invalid YAML raises ConfigParseError."""
        config_file = tmp_path / "test_servers.yaml"
        config_file.write_text("""
test-servers:
  radicale:
    type: embedded
    invalid yaml: [unclosed bracket
""")
        with pytest.raises(ConfigParseError) as exc_info:
            load_test_server_config(str(config_file))
        assert "could not be parsed" in str(exc_info.value)
        assert str(config_file) in str(exc_info.value)

    def test_invalid_json_and_yaml_raises_error(self, tmp_path: Path) -> None:
        """Test that content invalid as both JSON and YAML raises ConfigParseError."""
        config_file = tmp_path / "test_servers.json"
        # This is invalid for both JSON and YAML parsers
        config_file.write_text("{{{{invalid syntax}}}}")
        with pytest.raises(ConfigParseError) as exc_info:
            load_test_server_config(str(config_file))
        assert "could not be parsed" in str(exc_info.value)

    def test_nonexistent_explicit_config_falls_back(self, tmp_path: Path, monkeypatch) -> None:
        """Test that nonexistent explicit config falls back to default locations."""
        # Temporarily change to a directory without any config files
        # and set HOME to temp dir to avoid finding real user configs
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("HOME", str(tmp_path))
        cfg = load_test_server_config("/nonexistent/path/test_servers.yaml")
        # Should return empty dict when no config found in any location
        assert cfg == {}

    def test_flat_yaml_config(self, tmp_path: Path) -> None:
        """Test loading a YAML config without test-servers wrapper."""
        config_file = tmp_path / "test_servers.yaml"
        config_file.write_text("""
radicale:
    type: embedded
    enabled: true
purelymail:
    type: external
    enabled: true
    features: purelymail
""")
        cfg = load_test_server_config(str(config_file))
        assert "radicale" in cfg
        assert "purelymail" in cfg
        assert cfg["purelymail"]["features"] == "purelymail"

    def test_empty_yaml_raises_error(self, tmp_path: Path) -> None:
        """Test that an empty YAML file raises ConfigParseError."""
        config_file = tmp_path / "test_servers.yaml"
        config_file.write_text("")
        with pytest.raises(ConfigParseError) as exc_info:
            load_test_server_config(str(config_file))
        assert "could not be parsed" in str(exc_info.value)

    def test_rfc6638_users_preserved_alongside_test_servers(self, tmp_path: Path) -> None:
        """rfc6638_users at top level is preserved when test-servers is unwrapped."""
        config_file = tmp_path / "test_servers.yaml"
        config_file.write_text("""
test-servers:
  radicale:
    type: embedded
    enabled: true

rfc6638_users:
  - url: http://localhost:8802/dav/calendars/user/user1
    username: user1
    password: x
  - url: http://localhost:8802/dav/calendars/user/user2
    username: user2
    password: x
""")
        cfg = load_test_server_config(str(config_file))
        assert "radicale" in cfg
        assert "rfc6638_users" in cfg
        assert len(cfg["rfc6638_users"]) == 2
        assert cfg["rfc6638_users"][0]["username"] == "user1"

    def test_rfc6638_users_only_config(self, tmp_path: Path) -> None:
        """Config with only rfc6638_users (no test-servers) works correctly."""
        config_file = tmp_path / "test_servers.yaml"
        config_file.write_text("""
rfc6638_users:
  - url: http://localhost:8802/dav/calendars/user/user1
    username: user1
    password: x
""")
        cfg = load_test_server_config(str(config_file))
        assert "rfc6638_users" in cfg
        assert cfg["rfc6638_users"][0]["url"] == "http://localhost:8802/dav/calendars/user/user1"


class TestEnabledFalseDisablesRegisteredServer:
    """Gate finding F16: `enabled: false` was a no-op for docker servers.

    ``auto_discover()`` registers every ``docker-test-servers/*`` directory
    before ``load_from_config()`` runs, and the ``enabled`` check only skipped
    the *config entry* -- the already-registered server stayed enabled.  So a
    user who copied the example file and had Docker got every server run
    anyway, the opposite of what the file says.
    """

    def _registry_with_registered_server(self):
        from .base import TestServer
        from .registry import ServerRegistry

        class _FakeDocker(TestServer):
            server_type = "docker"

            def start(self) -> None: ...

            def stop(self) -> None: ...

            def is_running(self) -> bool:
                return True

            def is_accessible(self) -> bool:
                return True

            @property
            def url(self) -> str:
                return "http://localhost:8800/"

        registry = ServerRegistry()
        registry.register(_FakeDocker({"name": "baikal", "host": "localhost", "port": 8800}))
        return registry

    def test_enabled_false_disables_an_autodiscovered_server(self, monkeypatch) -> None:
        monkeypatch.delenv("PYTHON_CALDAV_TEST_DOCKER", raising=False)
        registry = self._registry_with_registered_server()
        assert [s.name for s in registry.enabled_servers()] == ["baikal"]

        registry.load_from_config({"baikal": {"type": "docker", "enabled": False}})

        assert registry.enabled_servers() == []

    def test_enabled_true_leaves_it_alone(self, monkeypatch) -> None:
        monkeypatch.delenv("PYTHON_CALDAV_TEST_DOCKER", raising=False)
        registry = self._registry_with_registered_server()

        registry.load_from_config({"baikal": {"type": "docker", "enabled": True}})

        assert [s.name for s in registry.enabled_servers()] == ["baikal"]
