# SPDX-FileCopyrightText: 2022-2026 Espressif Systems (Shanghai) CO LTD
# SPDX-License-Identifier: Apache-2.0

import os
import shutil
import typing as t
from pathlib import Path

import pytest
from jinja2 import Environment, FileSystemLoader
from ruamel.yaml import YAML

from idf_component_manager.root_components.install import install_root_components
from idf_component_tools.config import root_managed_components_dir

from .integration_test_helpers import create_component, generate_from_template
from .integration_test_helpers import idf_version as system_idf_version


@pytest.fixture(scope='session', autouse=True)
def fixed_console_width():
    """Pin the virtual terminal width so Rich never soft-wraps subprocess output.

    Integration tests capture ``idf.py`` output over a pipe, so neither ``idf.py``
    (rich-click error panels), the component manager (Rich ``notice``/``error``
    messages), nor the ``cmake`` subprocess it spawns sees a TTY. They all fall
    back to 80 columns and wrap long lines (absolute ``tmp_path`` paths, CMake
    ``FATAL_ERROR`` text), splitting tokens across line boundaries and breaking
    substring assertions. ``COLUMNS`` is inherited by the ``idf.py``/``cmake``
    subprocesses, so setting it here makes the width deterministic for all of
    them. Mirrors the ``fixed_console_width`` fixture in ``tests/conftest.py``.
    """
    previous = os.environ.get('COLUMNS')
    os.environ['COLUMNS'] = '200'
    try:
        yield
    finally:
        if previous is None:
            os.environ.pop('COLUMNS', None)
        else:
            os.environ['COLUMNS'] = previous


@pytest.fixture  # fake fixture since can't specify `indirect` for only one fixture
def result(request):
    return getattr(request, 'param')


@pytest.fixture(scope='function')
def project(request, tmpdir_factory):
    project_path = str(tmpdir_factory.mktemp('project'))
    file_loader = FileSystemLoader(os.path.join(os.path.dirname(__file__), 'fixtures', 'templates'))
    env = Environment(loader=file_loader)

    fixture_project_dir = request.param.get('fixture_project_dir')
    if fixture_project_dir:
        shutil.copytree(fixture_project_dir, project_path, dirs_exist_ok=True)
        yield os.path.abspath(project_path)
        return

    env_build_system_version = os.getenv('IDF_COMPONENT_TESTS_BUILD_SYSTEM_VERSION', '1')
    build_system_version = int(request.param.get('build_system_version', env_build_system_version))

    if build_system_version == 1:
        template = env.get_template('CMakeLists.txt')
    elif build_system_version == 2:
        template = env.get_template('CMakeLists_v2.txt')
    else:
        raise ValueError(f'Unsupported build_system_version: {build_system_version}')

    generate_from_template(os.path.join(project_path, 'CMakeLists.txt'), template=template)

    # create idf root dependencies
    root_dependencies = request.param.get('root_dependencies', {})
    root_snapshot = None
    if root_dependencies:
        # Write root dependencies to IDF_PATH/tools/idf_extra_components.yml.
        # Configure consumes preinstalled root-managed components from
        # root_managed_components_dir().
        idf_extra_path = os.path.join(
            os.environ.get('IDF_PATH', ''), 'tools', 'idf_extra_components.yml'
        )
        root_snapshot = Snapshot([idf_extra_path, str(root_managed_components_dir())])
        os.makedirs(os.path.dirname(idf_extra_path), exist_ok=True)
        with open(idf_extra_path, 'w') as fw:
            YAML().dump({'dependencies': root_dependencies}, fw)

        install_root_components()

    os.makedirs(root_managed_components_dir(), exist_ok=True)

    # create project components
    components = request.param.get('components', {'main': {}})
    for component in components.keys():
        create_component(project_path, component, components[component], env)
    yield os.path.abspath(project_path)

    if root_snapshot:
        root_snapshot.revert()


class Snapshot:
    def __init__(self, paths: t.Union[t.List[str], str]) -> None:
        self.files: t.Dict[str, t.Optional[bytes]] = {}

        if isinstance(paths, str):
            paths = [paths]

        for path in [os.path.realpath(os.path.expanduser(p)) for p in paths]:
            self.files.update(self._record(path))

    def _record(self, path, res=None):
        if res is None:
            res = {}

        if os.path.isfile(path):  # if it's an existing file, record the content
            try:
                with open(path, 'rb') as fr:
                    res.update({path: fr.read()})
            except PermissionError:
                pass
        elif os.path.isdir(path):  # if it's an existing dir, recursively record the content
            if not os.listdir(path):
                res.update({path: None})
            else:
                for item in os.listdir(path):
                    res.update(self._record(os.path.join(path, item), res))
        else:  # not exists
            res.update({path: None})

        return res

    def revert(self):
        for path, content in self.files.items():
            if content is not None:
                if not os.path.isdir(os.path.dirname(path)):
                    os.makedirs(os.path.dirname(path))
                with open(path, 'wb+') as fw:
                    fw.write(content)
            else:
                if os.path.isdir(path):
                    shutil.rmtree(path)
                elif os.path.isfile(path):
                    os.remove(path)
                else:
                    pass


@pytest.fixture(autouse=True)
def content_snapshot(request):
    snapshot_marker = request.node.get_closest_marker('snapshot')
    if not snapshot_marker:
        yield
    else:
        snapshot = Snapshot(snapshot_marker.args)
        yield
        snapshot.revert()


@pytest.fixture()
def fixtures_path():
    return Path(os.path.join(os.path.dirname(__file__), 'fixtures'))


def pytest_configure(config):
    for name, description in {
        'snapshot': 'snapshot the specified files/folders and revert the content after test case'
    }.items():
        config.addinivalue_line('markers', f'{name}: {description}')


@pytest.fixture(scope='session')
def idf_version():
    return system_idf_version()


@pytest.fixture
def debug_mode(monkeypatch):
    monkeypatch.setenv('IDF_COMPONENT_DEBUG_MODE', '1')
