# SPDX-FileCopyrightText: 2025 Espressif Systems (Shanghai) CO LTD
# SPDX-License-Identifier: Apache-2.0
import os
from pathlib import Path

import pytest
from ruamel.yaml import YAML

from idf_component_tools.semver.base import Version
from integration_tests.integration_test_helpers import fixtures_path, project_action

idf_version = Version.coerce(os.getenv('ESP_IDF_VERSION'))


@pytest.mark.parametrize(
    'project',
    [
        {
            'components': {
                'main': {
                    'dependencies': {
                        'cmp': {
                            'override_path': fixtures_path(
                                'components', 'cmp_with_kconfig_var', 'cmp'
                            ),
                        },
                    },
                },
            },
        },
    ],
    indirect=True,
)
def test_prepare_dep_dirs_with_kconfig(project):
    # Create a mock sdkconfig file
    (Path(project) / 'sdkconfig.default').write_text('CONFIG_ESP_BOARD_DEV_AUDIO_CODEC_SUPPORT=y')

    project_action(
        project,
        'reconfigure',
    )

    # Verify that valid Kconfig options are resolved correctly
    lock = YAML().load(Path(project) / 'dependencies.lock')
    assert 'cmp' in lock['dependencies']
    assert 'espressif/esp_codec_dev' in lock['dependencies']
    assert (
        '$CONFIG{ESP_BOARD_DEV_AUDIO_CODEC_SUPPORT} == True'
        in lock['dependencies']['cmp']['dependencies'][0]['matches'][0]['if']
    )
    assert 'service' in lock['dependencies']['espressif/esp_codec_dev']['source']['type']
