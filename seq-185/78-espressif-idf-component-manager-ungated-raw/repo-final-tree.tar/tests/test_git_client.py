# SPDX-FileCopyrightText: 2022-2026 Espressif Systems (Shanghai) CO LTD
# SPDX-License-Identifier: Apache-2.0

import os
import subprocess

import pytest

from idf_component_tools.errors import GitError
from idf_component_tools.git_client import GitClient, clean_tag_version


@pytest.fixture()
def git_repository(tmpdir_factory):
    temp_dir = tmpdir_factory.mktemp('git_repo')
    subprocess.check_output(['git', 'init', temp_dir.strpath])

    subprocess.check_output(['git', 'config', 'user.email', 'test@test.com'], cwd=temp_dir.strpath)
    subprocess.check_output(['git', 'config', 'user.name', 'Test Test'], cwd=temp_dir.strpath)

    subprocess.check_output(['git', 'checkout', '-b', 'default'], cwd=temp_dir.strpath)

    f = temp_dir.mkdir('component1').join('test_file')
    f.write('component1')

    subprocess.check_output(['git', 'add', '*'], cwd=temp_dir.strpath)
    subprocess.check_output(['git', 'commit', '-m', '"Init commit"'], cwd=temp_dir.strpath)

    return temp_dir


@pytest.fixture()
def git_repository_with_two_branches(git_repository):
    main_commit_id = subprocess.check_output(
        ['git', 'rev-parse', 'default'], cwd=git_repository.strpath
    ).strip()

    subprocess.check_output(['git', 'checkout', '-b', 'new_branch'], cwd=git_repository.strpath)

    f = git_repository.mkdir('component2').join('test_file')
    f.write('component2')

    subprocess.check_output(['git', 'add', '*'], cwd=git_repository.strpath)
    subprocess.check_output(['git', 'commit', '-m', '"Add new branch"'], cwd=git_repository.strpath)

    branch_commit_id = subprocess.check_output(
        ['git', 'rev-parse', 'new_branch'], cwd=git_repository.strpath
    ).strip()
    subprocess.check_output(['git', 'checkout', 'default'], cwd=git_repository.strpath)

    return {
        'path': git_repository.strpath,
        'default_head': main_commit_id.decode('utf-8'),
        'new_branch_head': branch_commit_id.decode('utf-8'),
    }


def test_bare_repository_in_cache(tmpdir_factory):
    client = GitClient()
    git_repo = 'test_repo'
    checkout_path = tmpdir_factory.mktemp('checkout_folder').strpath
    cache_path = tmpdir_factory.mktemp('cache_folder').strpath
    try:
        client.prepare_ref(
            repo=git_repo, bare_path=cache_path, checkout_path=checkout_path, with_submodules=True
        )
    except GitError:
        config_file = os.path.join(cache_path, 'config')

        with open(config_file, encoding='utf-8') as f:
            config = f.read()
            assert 'bare = true' in config


def test_bare_repository_with_safe_bare_repository_explicit(
    git_repository_with_two_branches, tmpdir_factory, monkeypatch
):
    git_repo = git_repository_with_two_branches['path']

    monkeypatch.setenv('GIT_CONFIG_COUNT', '1')
    monkeypatch.setenv('GIT_CONFIG_KEY_0', 'safe.bareRepository')
    monkeypatch.setenv('GIT_CONFIG_VALUE_0', 'explicit')

    client = GitClient()
    commit_id = client.prepare_ref(
        repo=git_repo,
        bare_path=tmpdir_factory.mktemp('cache_folder').strpath,
        checkout_path=tmpdir_factory.mktemp('checkout_folder').strpath,
        with_submodules=True,
    )

    assert commit_id == git_repository_with_two_branches['default_head']


def test_bare_repo_recovery_when_origin_remote_missing(
    git_repository_with_two_branches, tmpdir_factory
):
    """Simulate a cache directory left over from a previous run that
    initialized the bare repo but failed before adding the ``origin`` remote
    (e.g. because of ``safe.bareRepository=explicit``). The next run must
    recover by adding the missing remote, not crash with
    ``git config --get remote.origin.url`` exit code 1.
    """
    git_repo = git_repository_with_two_branches['path']
    bare_path = tmpdir_factory.mktemp('cache_folder').strpath

    # Hand-create a bare repo with no `origin` remote configured.
    subprocess.check_output(['git', 'init', '--bare', bare_path])

    client = GitClient()
    commit_id = client.prepare_ref(
        repo=git_repo,
        bare_path=bare_path,
        checkout_path=tmpdir_factory.mktemp('checkout_folder').strpath,
        with_submodules=True,
    )

    assert commit_id == git_repository_with_two_branches['default_head']


def test_bare_repo_recovery_when_cache_dir_not_a_repo(
    git_repository_with_two_branches, tmpdir_factory
):
    """If the cache directory contains junk (non-empty but not a bare repo),
    it should be wiped and recreated rather than treated as a valid repo.
    """
    git_repo = git_repository_with_two_branches['path']
    bare_path = tmpdir_factory.mktemp('cache_folder').strpath

    # Drop a stray file so `os.listdir(bare_path)` is non-empty but the
    # directory is not a bare repository.
    with open(os.path.join(bare_path, 'leftover.txt'), 'w') as f:
        f.write('garbage')

    client = GitClient()
    commit_id = client.prepare_ref(
        repo=git_repo,
        bare_path=bare_path,
        checkout_path=tmpdir_factory.mktemp('checkout_folder').strpath,
        with_submodules=True,
    )

    assert commit_id == git_repository_with_two_branches['default_head']


def test_working_with_git_without_branch(git_repository_with_two_branches, tmpdir_factory):
    client = GitClient()
    git_repo = git_repository_with_two_branches['path']
    checkout_path = tmpdir_factory.mktemp('checkout_folder').strpath
    cache_path = tmpdir_factory.mktemp('cache_folder').strpath
    commit_id = client.prepare_ref(
        repo=git_repo, bare_path=cache_path, checkout_path=checkout_path, with_submodules=True
    )
    assert commit_id == git_repository_with_two_branches['default_head']


def test_working_with_git_with_branch(git_repository_with_two_branches, tmpdir_factory):
    client = GitClient()
    git_repo = git_repository_with_two_branches['path']
    checkout_path = tmpdir_factory.mktemp('checkout_folder').strpath
    cache_path = tmpdir_factory.mktemp('cache_folder').strpath
    commit_id = client.prepare_ref(
        repo=git_repo,
        bare_path=cache_path,
        checkout_path=checkout_path,
        ref='new_branch',
        with_submodules=True,
        selected_paths=['component2'],
    )
    assert commit_id == git_repository_with_two_branches['new_branch_head']


def test_git_branch_does_not_exist(git_repository_with_two_branches, tmpdir_factory):
    client = GitClient()
    git_repo = git_repository_with_two_branches['path']
    checkout_path = tmpdir_factory.mktemp('checkout_folder').strpath
    cache_path = tmpdir_factory.mktemp('cache_folder').strpath
    with pytest.raises(GitError, match='Git reference "branch_not_exists" doesn\'t exist *'):
        client.prepare_ref(
            repo=git_repo,
            bare_path=cache_path,
            checkout_path=checkout_path,
            ref='branch_not_exists',
            with_submodules=True,
            selected_paths=['component2'],
        )


def test_git_path_does_not_exist(git_repository_with_two_branches, tmpdir_factory):
    client = GitClient()
    git_repo = git_repository_with_two_branches['path']
    checkout_path = tmpdir_factory.mktemp('checkout_folder').strpath
    cache_path = tmpdir_factory.mktemp('cache_folder').strpath
    with pytest.raises(
        GitError, match=r"pathspec 'path_not_exists' did not match any file\(s\) known to git"
    ):
        client.prepare_ref(
            repo=git_repo,
            bare_path=cache_path,
            checkout_path=checkout_path,
            ref='new_branch',
            with_submodules=True,
            selected_paths=['path_not_exists'],
        )


@pytest.mark.parametrize(
    'input_str, expected_output',
    [
        ('v1.2.3', '1.2.3'),
        ('1.2.3.4', '1.2.3~4'),
        ('v1.2.3.4', '1.2.3~4'),
        ('v1.2.3.4-rc1', '1.2.3~4-rc1'),
        ('v1.2.3.4-rc1+123', '1.2.3~4-rc1+123'),
        ('abc', 'abc'),
    ],
)
def test_clean_tag_version(input_str, expected_output):
    assert clean_tag_version(input_str) == expected_output


def test_successful_git_stderr_logged_as_debug(git_repository, recording_log):
    """Git commands that succeed but write to stderr should log at DEBUG, not WARNING."""
    client = GitClient()
    git_repo = git_repository.strpath

    # 'git status' with a path to a nonexistent file still succeeds but warns on stderr
    # Instead, use a command that reliably produces stderr on success:
    # 'git tag -d' on a nonexistent tag fails, so we use a different approach.
    # Create a second branch to make 'git checkout' produce stderr info.
    subprocess.check_output(['git', 'checkout', '-b', 'other'], cwd=git_repo)
    subprocess.check_output(['git', 'checkout', 'default'], cwd=git_repo)

    # 'git branch -v' writes to stdout only, so mock Popen to control stderr
    from unittest.mock import MagicMock, patch

    mock_process = MagicMock()
    mock_process.communicate.return_value = (b'mock stdout\n', b'informational stderr message\n')
    mock_process.returncode = 0

    with patch('subprocess.Popen', return_value=mock_process):
        result = client.run(['status'], cwd=git_repo)

    assert result == 'mock stdout\n'
    # Verify stderr was NOT logged at warning/error level
    warning_records = [r for r in recording_log.records if r.level in ('warning', 'error')]
    stderr_warnings = [r for r in warning_records if 'informational stderr message' in r.message]
    assert len(stderr_warnings) == 0, 'Git stderr on success should not be logged as WARNING'


def test_get_tag_version(git_repository):
    client = GitClient()
    git_repo = git_repository.strpath

    # Create a lightweight tag
    client.run(['tag', 'v1.2.3'], cwd=git_repo)
    assert str(client.get_tag_version(cwd=git_repo)) == '1.2.3'

    # Remove the tag
    client.run(['tag', '-d', 'v1.2.3'], cwd=git_repo)

    # Create an annotated tag
    client.run(['tag', '-a', 'v1.2.4', '-m', 'Test tag'], cwd=git_repo)
    assert str(client.get_tag_version(cwd=git_repo)) == '1.2.4'

    # Remove the tag
    client.run(['tag', '-d', 'v1.2.4'], cwd=git_repo)

    # Not a tag raises an error
    with pytest.raises(GitError, match='Not a tagged commit'):
        client.get_tag_version(cwd=git_repo)
