# SPDX-FileCopyrightText: 2022-2026 Espressif Systems (Shanghai) CO LTD
# SPDX-License-Identifier: Apache-2.0
from textwrap import dedent

from idf_component_manager.version_solver.mixology.package import Package


def test_no_version_matching_constraint(source, check_solver_result):
    source.root_dep(Package('foo'), '^1.0')

    source.add(Package('foo'), '2.0.0')
    source.add(Package('foo'), '2.1.3')

    error = """\
    Version solving failed:
        - no versions of foo match ^1.0
        - project depends on foo (^1.0)
    Result: Because project depends on foo (^1.0) which doesn't match any versions, version solving failed."""

    check_solver_result(
        source,
        error=dedent(error),
    )


def test_no_version_that_matches_combined_constraints(source, check_solver_result):
    source.root_dep(Package('foo'), '1.0.0')
    source.root_dep(Package('bar'), '1.0.0')

    source.add(Package('foo'), '1.0.0', deps={Package('shared'): '>=2.0.0,<3.0.0'})
    source.add(Package('bar'), '1.0.0', deps={Package('shared'): '>=2.9.0,<4.0.0'})
    source.add(Package('shared'), '2.5.0')
    source.add(Package('shared'), '3.5.0')

    error = """\
    Version solving failed:
        - bar (1.0.0) depends on shared (>=2.9.0,<4.0.0)
        - foo (1.0.0) depends on shared (>=2.0.0,<3.0.0)
        - no versions of shared match >=2.9.0,<3.0.0
        - project depends on foo (1.0.0)
        - project depends on bar (1.0.0)
    Result: Because project depends on both foo (1.0.0) and bar (1.0.0), version solving failed."""

    check_solver_result(source, error=dedent(error))


def test_disjoint_constraints(source, check_solver_result):
    source.root_dep(Package('foo'), '1.0.0')
    source.root_dep(Package('bar'), '1.0.0')

    source.add(Package('foo'), '1.0.0', deps={Package('shared'): '<=2.0.0'})
    source.add(Package('bar'), '1.0.0', deps={Package('shared'): '>3.0.0'})
    source.add(Package('shared'), '2.0.0')
    source.add(Package('shared'), '4.0.0')

    error = """\
    Version solving failed:
        - bar (1.0.0) depends on shared (>3.0.0)
        - foo (1.0.0) depends on shared (<=2.0.0)
        - project depends on foo (1.0.0)
        - project depends on bar (1.0.0)
    Result: Because project depends on both foo (1.0.0) and bar (1.0.0), version solving failed."""

    check_solver_result(source, error=dedent(error))


def test_disjoint_root_constraints(source, check_solver_result):
    source.root_dep(Package('foo'), '1.0.0')
    source.root_dep(Package('foo'), '2.0.0')

    source.add(Package('foo'), '1.0.0')
    source.add(Package('foo'), '2.0.0')

    error = """\
    Version solving failed:
        - project depends on foo (1.0.0)
        - project depends on foo (2.0.0)
    Result: Because project depends on both foo (1.0.0) and foo (2.0.0), version solving failed."""

    check_solver_result(source, error=dedent(error))


def test_no_valid_solution(source, check_solver_result):
    source.root_dep(Package('a'), '*')
    source.root_dep(Package('b'), '*')

    source.add(Package('a'), '1.0.0', deps={Package('b'): '1.0.0'})
    source.add(Package('a'), '2.0.0', deps={Package('b'): '2.0.0'})

    source.add(Package('b'), '1.0.0', deps={Package('a'): '2.0.0'})
    source.add(Package('b'), '2.0.0', deps={Package('a'): '1.0.0'})

    error = """\
    Version solving failed:
        - no versions of b match >=0.0.0,<1.0.0 || >1.0.0,<2.0.0 || >2.0.0
        - b (1.0.0) depends on a (2.0.0)
        - a (2.0.0) depends on b (2.0.0)
        - a (1.0.0) depends on b (1.0.0)
        - b (2.0.0) depends on a (1.0.0)
        - project depends on b (*)
    Result: Because project depends on b (*), version solving failed."""

    check_solver_result(source, error=dedent(error), tries=2)


def test_dependency_on_package_itself(source, check_solver_result):
    source.root_dep(Package('foo'), '~=2.0')

    source.add(Package('foo'), '2.3.1', deps={Package('foo'): '1.0.0'})
    source.add(Package('foo'), '1.0.0')

    error = """\
    Version solving failed:
        - no versions of foo match >=2.0.0,<2.3.1 || >2.3.1,<3.0.0
        - foo (2.3.1) self depends on foo (1.0.0)
        - project depends on foo (~=2.0)
    Result: Because project depends on foo (~=2.0), version solving failed."""
    check_solver_result(source, error=dedent(error), tries=1)


def test_diamond_conflict_through_shared_dependency(source, check_solver_result):
    source.root_dep(Package('a'), '*')
    source.root_dep(Package('b'), '*')

    source.add(Package('a'), '1.0.0', deps={Package('c'): '1.0.0', Package('d'): '1.0.0'})
    source.add(Package('a'), '2.0.0', deps={Package('c'): '2.0.0', Package('d'): '2.0.0'})
    source.add(Package('b'), '1.0.0', deps={Package('c'): '1.0.0', Package('d'): '2.0.0'})
    source.add(Package('b'), '2.0.0', deps={Package('c'): '2.0.0', Package('d'): '1.0.0'})
    source.add(Package('c'), '1.0.0', deps={Package('e'): '1.0.0'})
    source.add(Package('c'), '2.0.0', deps={Package('e'): '2.0.0'})
    source.add(Package('d'), '1.0.0', deps={Package('e'): '2.0.0'})
    source.add(Package('d'), '2.0.0', deps={Package('e'): '1.0.0'})
    source.add(Package('e'), '1.0.0')
    source.add(Package('e'), '2.0.0')

    check_solver_result(
        source,
        error=[
            'Version solving failed:',
            'a (1.0.0) depends on c (1.0.0)',
            'a (1.0.0) depends on d (1.0.0)',
            'a (2.0.0) depends on c (2.0.0)',
            'a (2.0.0) depends on d (2.0.0)',
            'b (1.0.0) depends on c (1.0.0)',
            'b (1.0.0) depends on d (2.0.0)',
            'b (2.0.0) depends on c (2.0.0)',
            'b (2.0.0) depends on d (1.0.0)',
            'Result: Because project depends on both a (*) and b (*), version solving failed.',
        ],
        tries=2,
    )
