# moreorless

This is a thin wrapper around `difflib.unified_diff` that Does The Right Thing
for "No newline at eof".  The args are also simplified compared to `difflib`:

```py
moreorless.unified_diff(
    astr: str,
    bstr: str,
    filename: str,
    n: int = 3,
) -> str:
    ...

# raises moreorless.patch.PatchException
moreorless.patch.apply_single_file(
    contents: str,
    patch: str,
    allow_offsets: bool = True,
) -> str:
    ...

# uses click to write to stdout with colors
moreorless.click.echo_color_unified_diff(
    astr: str,
    bstr: str,
    filename: str,
    n: int = 3
) -> None:
    ...

# if you want to use unified_diff yourself first (e.g. in another process)
moreorless.click.echo_color_precomputed_diff(
    diff: str,
) -> None:
    ...

# if you want to produce a combined (merge) diff:
moreorless.combined.combined_diff(
    [astr, bstr], [cstr]
) -> str:
    ...
```

# Version Compat

This library is compatible with Python 3.9+, but should be linted under the
newest stable version.

# Versioning

This library follows [meanver](https://meanver.org/), which basically means
[semver](https://semver.org/) along with a promise to rename when the major
version changes.

Install the optional `cli` extra if you want the colored diff helpers:

```bash
pip install moreorless[cli]
```

# License

moreorless is copyright [Tim Hatch](http://timhatch.com/), and licensed under
the MIT license.  I am providing code in this repository to you under an open
source license.  This is my personal repository; the license you receive to
my code is from me and not from my employer. See the `LICENSE` file for details.
