import inspect
from collections.abc import Mapping

from .reducers import dot_reducer, path_reducer, tuple_reducer, underscore_reducer
from .splitters import dot_splitter, path_splitter, tuple_splitter, underscore_splitter

REDUCER_DICT = {
    "tuple": tuple_reducer,
    "path": path_reducer,
    "dot": dot_reducer,
    "underscore": underscore_reducer,
}

SPLITTER_DICT = {
    "tuple": tuple_splitter,
    "path": path_splitter,
    "dot": dot_splitter,
    "underscore": underscore_splitter,
}


def flatten(
    d,
    reducer="tuple",
    inverse=False,
    max_flatten_depth=None,
    enumerate_types=(),
    keep_empty_types=(),
):
    """Flatten `Mapping` object.

    Parameters
    ----------
    d : dict-like object
        The dict that will be flattened.
    reducer : {'tuple', 'path', 'underscore', 'dot', Callable}
        The key joining method. If a `Callable` is given, the `Callable` will be
        used to reduce.
        'tuple': The resulting key will be tuple of the original keys.
        'path': Use `os.path.join` to join keys.
        'underscore': Use underscores to join keys.
        'dot': Use dots to join keys.
    inverse : bool
        Whether you want invert the resulting key and value.
    max_flatten_depth : Optional[int]
        Maximum depth to merge.
    enumerate_types : Sequence[type]
        Flatten these types using `enumerate`.
        For example, if we set `enumerate_types` to ``(list,)``,
        `list` indices become keys: ``{'a': ['b', 'c']}`` -> ``{('a', 0): 'b', ('a', 1): 'c'}``.
    keep_empty_types : Sequence[type]
        By default, ``flatten({1: 2, 3: {}})`` will give you ``{(1,): 2}``, that is, the key ``3``
        will disappear.
        This is also applied for the types in `enumerate_types`, that is,
        ``flatten({1: 2, 3: []}, enumerate_types=(list,))`` will give you ``{(1,): 2}``.
        If you want to keep those empty values, you can specify the types in `keep_empty_types`:

        >>> flatten({1: 2, 3: {}}, keep_empty_types=(dict,))
        {(1,): 2, (3,): {}}

    Returns
    -------
    flat_dict : dict
    """
    enumerate_types = tuple(enumerate_types)
    flattenable_types = (Mapping,) + enumerate_types
    if not isinstance(d, flattenable_types):
        raise ValueError(
            "argument type %s is not in the flattenalbe types %s"
            % (type(d), flattenable_types)
        )

    # check max_flatten_depth
    if max_flatten_depth is not None and max_flatten_depth < 1:
        raise ValueError("max_flatten_depth should not be less than 1.")

    if isinstance(reducer, str):
        reducer = REDUCER_DICT[reducer]
    reducer_accepts_parent_obj = len(inspect.signature(reducer).parameters) == 3
    flat_dict = {}

    def _flatten(_d, depth, parent=None):
        key_value_iterable = (
            enumerate(_d) if isinstance(_d, enumerate_types) else _d.items()
        )
        has_item = False
        for key, value in key_value_iterable:
            has_item = True
            if reducer_accepts_parent_obj:
                flat_key = reducer(parent, key, _d)
            else:
                flat_key = reducer(parent, key)
            if isinstance(value, flattenable_types) and (
                max_flatten_depth is None or depth < max_flatten_depth
            ):
                # recursively build the result
                has_child = _flatten(value, depth=depth + 1, parent=flat_key)
                if has_child or not isinstance(value, keep_empty_types):
                    # ignore the key in this level because it already has child key
                    # or its value is empty
                    continue

            # add an item to the result
            if inverse:
                flat_key, value = value, flat_key
            if flat_key in flat_dict:
                raise ValueError("duplicated key '{}'".format(flat_key))
            flat_dict[flat_key] = value

        return has_item

    _flatten(d, depth=1)
    return flat_dict


def nested_set_dict(
    d, keys, value, *, full_key=None, internal_ids=None, leaf_origins=None,
    allow_non_leaf_values=False,
):
    """Set a value to a sequence of nested keys.

    Parameters
    ----------
    d : Mapping
    keys : Sequence[str]
    value : Any
    full_key : Any
        The original flat key that produced `keys`, used for error messages.
    internal_ids : set
        ids of dicts created internally as intermediate containers, so they
        can be distinguished from dicts that were set as leaf values.
    leaf_origins : Mapping
        Maps id(leaf_value) to the flat key that set it, for error messages.
    allow_non_leaf_values : bool
        If True, allow writing nested keys into a location that was already
        set to a (dict-valued) leaf, mutating it. If False, this raises
        ValueError instead.
    """
    assert keys
    key = keys[0]
    if len(keys) == 1:
        if key in d:
            raise ValueError("duplicated key '{}'".format(key))
        d[key] = value
        if leaf_origins is not None:
            leaf_origins[id(value)] = full_key
        return
    if key in d:
        child = d[key]
        is_internal = isinstance(child, dict) and (
            internal_ids is not None and id(child) in internal_ids
        )
        if not is_internal:
            if not allow_non_leaf_values:
                origin_key = leaf_origins.get(id(child)) if leaf_origins else None
                raise ValueError(
                    "cannot unflatten {!r}: {!r} already has a leaf value, and "
                    "writing into it mutates that value; pass "
                    "allow_non_leaf_values=True to allow this".format(
                        full_key, origin_key
                    )
                )
            if not isinstance(child, dict):
                raise ValueError(
                    "cannot unflatten {!r}: {!r} is not a dict-like value".format(
                        full_key, key
                    )
                )
    else:
        child = d.setdefault(key, {})
        if internal_ids is not None:
            internal_ids.add(id(child))
    nested_set_dict(
        child,
        keys[1:],
        value,
        full_key=full_key,
        internal_ids=internal_ids,
        leaf_origins=leaf_origins,
        allow_non_leaf_values=allow_non_leaf_values,
    )


def unflatten(d, splitter="tuple", inverse=False, allow_non_leaf_values=False):
    """Unflatten dict-like object.

    Parameters
    ----------
    d : dict-like object
        The dict that will be unflattened.
    splitter : {'tuple', 'path', 'underscore', 'dot', Callable}
        The key splitting method. If a Callable is given, the Callable will be
        used to split `d`.
        'tuple': Use each element in the tuple key as the key of the unflattened dict.
        'path': Use `pathlib.Path.parts` to split keys.
        'underscore': Use underscores to split keys.
        'dot': Use dots to split keys.
    inverse : bool
        Whether you want to invert the key and value before flattening.
    allow_non_leaf_values : bool
        If a flat key maps to a dict-like leaf value, and another flat key
        would nest further keys inside that value, this is normally an
        error since it would silently mutate the leaf value. Set this to
        True to allow it instead.

    Returns
    -------
    unflattened_dict : dict
    """
    if isinstance(splitter, str):
        splitter = SPLITTER_DICT[splitter]

    unflattened_dict = {}
    internal_ids = set()
    leaf_origins = {}
    for flat_key, value in d.items():
        if inverse:
            flat_key, value = value, flat_key
        key_tuple = splitter(flat_key)
        nested_set_dict(
            unflattened_dict,
            key_tuple,
            value,
            full_key=flat_key,
            internal_ids=internal_ids,
            leaf_origins=leaf_origins,
            allow_non_leaf_values=allow_non_leaf_values,
        )

    return unflattened_dict
