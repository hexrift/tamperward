# (C) Copyright 2021 ECMWF.
#
# This software is licensed under the terms of the Apache Licence Version 2.0
# which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
# In applying this licence, ECMWF does not waive the privileges and immunities
# granted to it by virtue of its status as an intergovernmental organisation
# nor does it submit to any jurisdiction.
#

import pytest
import requests


def _network_available():
    try:
        r = requests.head(
            "http://get.ecmwf.int/test-data/metview/gallery/temp.bufr", timeout=5
        )
        return r.status_code != 403
    except requests.exceptions.RequestException:
        return False


NETWORK_AVAILABLE = _network_available()


def pytest_configure(config):
    config.addinivalue_line(
        "markers", "network: test needs outbound access to external test hosts"
    )


def pytest_collection_modifyitems(config, items):
    if NETWORK_AVAILABLE:
        return
    skip_marker = pytest.mark.skip(
        reason="requires outbound network access to get.ecmwf.int/httpbin.org, "
        "unavailable in this environment"
    )
    for item in items:
        if "network" in item.keywords:
            item.add_marker(skip_marker)
