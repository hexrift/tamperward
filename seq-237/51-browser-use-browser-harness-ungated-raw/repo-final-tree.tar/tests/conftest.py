import base64
import io
import os
import tempfile

# Tests must not touch the real user's config dir (module-level code in
# browser_harness._ipc resolves and creates it on import). Point BH_HOME at
# an isolated, writable directory before any browser_harness module loads.
os.environ.setdefault("BH_HOME", tempfile.mkdtemp(prefix="browser-harness-tests-"))

import pytest
from PIL import Image


def make_png(width, height):
    buf = io.BytesIO()
    Image.new("RGB", (width, height), "white").save(buf, format="PNG")
    return base64.b64encode(buf.getvalue()).decode()


@pytest.fixture
def fake_png():
    return make_png
